/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Sparkles, 
  Bot, 
  User, 
  Trash2, 
  Mic, 
  Volume2, 
  VolumeX, 
  Menu, 
  X, 
  Plus, 
  MessageSquare, 
  PanelLeftClose, 
  PanelLeft,
  ChevronDown,
  Search,
  Heart,
  Smile,
  Activity,
  RotateCw,
  LogOut,
  Settings,
  Sun,
  Moon,
  Calendar,
  Database,
  Code2,
  ArrowRight,
  Clock,
  BookOpen,
  Network
} from 'lucide-react';
import { MarkdownRenderer } from './components/MarkdownRenderer';
import { TypewriterMarkdown } from './components/TypewriterMarkdown';
import { GoogleCalendarDashboard } from './components/GoogleCalendarDashboard';
import { CognitiveSqlConsole } from './components/CognitiveSqlConsole';
import { CodingWorkspace } from './components/CodingWorkspace';
import { GeminiRagDashboard } from './components/GeminiRagDashboard';
import NeuralNetworkVisualizer from './components/NeuralNetworkVisualizer';
import { auth, googleAuthProvider } from './lib/firebase.ts';
import { syncUserProfileFirestore } from './lib/firestore-service';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, ReferenceLine } from 'recharts';

type Message = { 
  id: number; 
  sender: 'user' | 'ai'; 
  text: string; 
  timestamp: string; 
  reaction?: string | null;
  emotionAnalysis?: {
    emotion: string;
    label: string;
    emoji: string;
    score: number;
    description: string;
  } | null;
  matchedChunks?: {
    docTitle: string;
    chunkIndex: number;
    totalChunks: number;
    content: string;
  }[] | null;
};

type ChatSession = {
  id: string;
  title: string;
  messages: Message[];
  updatedAt: number;
  mode: 'chat' | 'history' | 'genz';
};

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-brand-sidebar border border-brand-border/70 px-3 py-2 rounded-xl shadow-lg text-[10px] space-y-1 select-none backdrop-blur-md">
        <div className="flex items-center gap-1.5 font-extrabold text-brand-primary">
          <span className="text-xs">{data.emoji}</span>
          <span>{data.label}</span>
        </div>
        <div className="text-brand-secondary font-medium font-mono text-[9px]">
          Vibe Score: <span className={data.val >= 0 ? "text-rose-400" : "text-sky-400"}>{data.val}</span>
        </div>
        <div className="text-[8px] text-brand-secondary/70 font-mono">
          {data.time}
        </div>
      </div>
    );
  }
  return null;
};

const AGENDA_GREETINGS = [
  "Namaste! Hey there! What's on the agenda today? Aaj kya bada plan hai aapka? 🚀",
  "Hello! Swagat hai aapka! Ready to design or code? Aaj chalo milkar kuch kamaal banate hain! ✨",
  "Yo buddy! Ram Ram! What should we explore today? Aaj kis awesome project pe kaam karein? 💻",
  "Aadab! Hey friend! How can I fuel your imagination today? Aaj dimaag me kya naya chal raha hai? 💡",
  "Namaste! Jai Hind! Ready to build something extraordinary? Aaj chalo coding ka jadoo dikhate hain! 🛠️",
  "Hey! Welcome back! What's cooking in your mind today? Aaj kis problem ko solve karna hai? 🎯",
  "Hello there! Swagat hai! What awesome logic are we writing today? Aaj kya interesting seekhna hai? 🧠",
  "Namaste! Hello! How is your day going? Let's turn some ideas into reality today! Chalo shuru karein! 🌟",
  "Aao bhai! Hey mate! What's on the agenda today? Aaj kya naya toofan khada karna hai? Let's build! 🔥",
  "Welcome back, buddy! Swagat hai! How can Nexora assist you today? Aaj kya cool create karna hai? 🎨"
];

export default function App() {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string>('session-1');
  const [typedMessageIds, setTypedMessageIds] = useState<Set<number>>(new Set());
  const hasInitializedTypedIds = useRef(false);

  useEffect(() => {
    if (sessions.length > 0 && !hasInitializedTypedIds.current) {
      const ids = new Set<number>();
      sessions.forEach(s => {
        if (s.messages) {
          s.messages.forEach(m => {
            ids.add(m.id);
          });
        }
      });
      setTypedMessageIds(ids);
      hasInitializedTypedIds.current = true;
    }
  }, [sessions]);

  const markMessageAsTyped = (id: number) => {
    setTypedMessageIds(prev => {
      const next = new Set(prev);
      next.add(id);
      return next;
    });
  };

  const [input, setInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);

  // Random dynamic Hinglish/English greeting & agenda switcher
  const [agendaText, setAgendaText] = useState(() => {
    return AGENDA_GREETINGS[Math.floor(Math.random() * AGENDA_GREETINGS.length)];
  });

  useEffect(() => {
    const randomG = AGENDA_GREETINGS[Math.floor(Math.random() * AGENDA_GREETINGS.length)];
    setAgendaText(randomG);
  }, [activeSessionId]);

  const filteredSessions = sessions.filter(s => {
    if (!searchQuery.trim()) return true;
    const lowerQuery = searchQuery.toLowerCase();
    const matchesTitle = s.title.toLowerCase().includes(lowerQuery);
    const matchesContent = s.messages && s.messages.some(m => m.text.toLowerCase().includes(lowerQuery));
    return matchesTitle || matchesContent;
  });
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isMobile, setIsMobile] = useState(false);
  const [modelDropdownOpen, setModelDropdownOpen] = useState(false);
  const [accountMenuOpen, setAccountMenuOpen] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    try {
      const stored = localStorage.getItem('nexora_theme');
      return (stored as 'light' | 'dark') || 'dark';
    } catch {
      return 'dark';
    }
  });

  useEffect(() => {
    localStorage.setItem('nexora_theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);
  const [showEmpathyInsights, setShowEmpathyInsights] = useState(false);
  const [panelAnimationDone, setPanelAnimationDone] = useState(false);
  const [windowWidth, setWindowWidth] = useState(typeof window !== 'undefined' ? window.innerWidth : 1200);
  const [promptRefreshCount, setPromptRefreshCount] = useState(0);
  const [expandedPrompts, setExpandedPrompts] = useState(false);
  const [hoveredPrompt, setHoveredPrompt] = useState<{ text: string; x: number; y: number; tooltip: string } | null>(null);
  const [promptUsage, setPromptUsage] = useState<Record<string, number>>(() => {
    try {
      const stored = localStorage.getItem('nexora_prompt_usage');
      return stored ? JSON.parse(stored) : {};
    } catch {
      return {};
    }
  });

  useEffect(() => {
    if (!showEmpathyInsights) {
      setPanelAnimationDone(false);
    }
  }, [showEmpathyInsights]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const [isListening, setIsListening] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(true);
  const [speechError, setSpeechError] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  // Auth States
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [authToken, setAuthToken] = useState<string | null>(null);
  const [syncing, setSyncing] = useState(false);

  // Google Calendar Integration states
  const [viewMode, setViewMode] = useState<'chat' | 'calendar' | 'memory' | 'coding' | 'rag' | 'neural'>('chat');
  const [ragEnabled, setRagEnabled] = useState(true);
  const [advancedSearchEnabled, setAdvancedSearchEnabled] = useState(() => {
    return localStorage.getItem("advanced_search_enabled") === "true";
  });
  const [recentSqlLogs, setRecentSqlLogs] = useState<any[]>([]);
  const [googleAccessToken, setGoogleAccessToken] = useState<string | null>(() => {
    return sessionStorage.getItem('google_cal_access_token');
  });
  const [isConnectingCalendar, setIsConnectingCalendar] = useState(false);

  // Auto-detect mobile layout boundaries
  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      setWindowWidth(window.innerWidth);
      if (mobile) {
        setSidebarOpen(false);
      } else {
        setSidebarOpen(true);
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Monitor Authentication and Syncing
  useEffect(() => {
    const loadLocalFallback = () => {
      const saved = localStorage.getItem('nexora_sessions');
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setSessions(parsed.map((s: any) => ({ ...s, mode: s.mode || 'chat' })));
            setActiveSessionId(localStorage.getItem('nexora_active_session_id') || parsed[0].id);
            return;
          }
        } catch (e) {
          console.error(e);
        }
      }
      
      // Default guest initialization
      const defaultSess: ChatSession = {
        id: 'session-1',
        title: 'Zabardast Chat ✨',
        messages: [{ id: Date.now(), sender: 'ai', text: 'Namaste! ⚡️ Main hoon Nexora AI, India ka sabse advanced AI jise Raja Kumar Choudhary ne banaya hai. Aaj main aapki kya madad karu?', timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }],
        updatedAt: Date.now(),
        mode: 'chat'
      };
      setSessions([defaultSess]);
      setActiveSessionId('session-1');
    };

    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        // Securely sync user profile matching blueprint schema & security rules
        syncUserProfileFirestore(
          currentUser.uid, 
          currentUser.email || '', 
          currentUser.displayName || ''
        ).catch(err => console.error("Could not sync profile to Firestore context:", err));

        try {
          setSyncing(true);
          const token = await currentUser.getIdToken();
          setAuthToken(token);
          
          // Pull sessions from PostgreSQL
          const res = await fetch('/api/sessions', {
            headers: { 'Authorization': `Bearer ${token}` }
          });
          
          if (res.ok) {
            const cloudSessions = await res.json();
            if (Array.isArray(cloudSessions) && cloudSessions.length > 0) {
              const mapped = await Promise.all(cloudSessions.map(async (s: any) => {
                const msgRes = await fetch(`/api/sessions/${s.id}/messages`, {
                  headers: { 'Authorization': `Bearer ${token}` }
                });
                const msgs = msgRes.ok ? await msgRes.json() : [];
                return {
                  id: s.id,
                  title: s.title,
                  mode: s.mode,
                  updatedAt: new Date(s.updatedAt).getTime(),
                  messages: msgs.map((m: any) => ({
                    id: m.id,
                    sender: m.sender,
                    text: m.text,
                    timestamp: m.timestamp,
                    reaction: m.reaction || null
                  }))
                };
              }));
              setSessions(mapped);
              setActiveSessionId(mapped[0].id);
            } else {
              // Push local memory sessions to Server DB
              const localSaved = localStorage.getItem('nexora_sessions');
              let sessionsToSync = [];
              if (localSaved) {
                try {
                  const parsed = JSON.parse(localSaved);
                  if (Array.isArray(parsed) && parsed.length > 0) {
                    sessionsToSync = parsed;
                  }
                } catch (e) {
                  console.error(e);
                }
              }
              if (sessionsToSync.length === 0) {
                sessionsToSync = [{
                  id: 'session-1',
                  title: 'Zabardast Chat ✨',
                  messages: [{ id: Date.now(), sender: 'ai', text: 'Namaste! ⚡️ Main hoon Nexora AI, India ka sabse advanced AI jise Raja Kumar Choudhary ne banaya hai. Aaj main aapki kya madad karu?', timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }],
                  updatedAt: Date.now(),
                  mode: 'chat' as const
                }];
              }

              for (const s of sessionsToSync) {
                await fetch('/api/sessions', {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                  },
                  body: JSON.stringify({ id: s.id, title: s.title, mode: s.mode })
                });
                for (const m of s.messages) {
                  await fetch(`/api/sessions/${s.id}/messages`, {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json',
                      'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify({ sender: m.sender, text: m.text, timestamp: m.timestamp })
                  });
                }
              }
              setSessions(sessionsToSync);
              setActiveSessionId(sessionsToSync[0].id);
            }
          } else {
            console.warn("Failed to load cloud sessions (status not ok), loading local fallback instead.");
            loadLocalFallback();
          }
        } catch (err) {
          console.error("Error syncing on auth change:", err);
          loadLocalFallback();
        } finally {
          setSyncing(false);
        }
      } else {
        setAuthToken(null);
        loadLocalFallback();
      }
    });
    return () => unsubscribe();
  }, []);

  const activeSession = sessions.find(s => s.id === activeSessionId) || sessions[0] || {
    id: 'session-1',
    title: 'Zabardast Chat ✨',
    messages: [],
    mode: 'chat'
  };

  const messages = activeSession.messages || [];

  // Local Guest state watcher
  useEffect(() => {
    if (!user && sessions.length > 0) {
      localStorage.setItem('nexora_sessions', JSON.stringify(sessions));
    }
  }, [sessions, user]);

  useEffect(() => {
    if (!user) {
      localStorage.setItem('nexora_active_session_id', activeSessionId);
    }
  }, [activeSessionId, user]);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setSpeechSupported(false);
      return;
    }

    const rec = new SpeechRecognition();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = 'en-IN'; // Elegant Hinglish audio transcriber

    rec.onstart = () => {
      setIsListening(true);
      setSpeechError(null);
    };

    rec.onend = () => {
      setIsListening(false);
    };

    rec.onerror = (event: any) => {
      console.error("Speech recognition error", event.error);
      if (event.error === 'not-allowed') {
        setSpeechError("Microphone ki permission blocked hai.");
      } else {
        setSpeechError(`Speech error: ${event.error}`);
      }
      setIsListening(false);
    };

    rec.onresult = (event: any) => {
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcript;
        }
      }

      if (finalTranscript) {
        setInput(prev => {
          const trimmed = prev.trim();
          return trimmed ? `${trimmed} ${finalTranscript.trim()}` : finalTranscript.trim();
        });
      }
    };

    recognitionRef.current = rec;

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, []);

  const [activeSpokenId, setActiveSpokenId] = useState<number | null>(null);

  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const speakMessage = (id: number, text: string) => {
    if (!('speechSynthesis' in window)) {
      setSpeechError("Aapke browser me speech synthesis support nahi karta.");
      return;
    }

    if (activeSpokenId === id) {
      window.speechSynthesis.cancel();
      setActiveSpokenId(null);
      return;
    }

    window.speechSynthesis.cancel();

    const cleanText = text.replace(/[*#_`~⚡️]/g, "").trim();
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = 'en-IN';

    const voices = window.speechSynthesis.getVoices();
    const primaryVoice = voices.find(v => v.lang.startsWith('en-IN')) || 
                        voices.find(v => v.lang.startsWith('hi-IN')) || 
                        voices.find(v => v.lang.startsWith('en-US'));
    if (primaryVoice) {
      utterance.voice = primaryVoice;
    }

    utterance.onend = () => {
      setActiveSpokenId(null);
    };

    utterance.onerror = () => {
      setActiveSpokenId(null);
    };

    setActiveSpokenId(id);
    window.speechSynthesis.speak(utterance);
  };

  const getEmpathyReport = () => {
    const activeMessages = activeSession?.messages || [];
    const emotionMsgs = activeMessages.filter(m => m.sender === 'ai' && m.emotionAnalysis && m.emotionAnalysis.emotion !== 'neutral');
    
    if (emotionMsgs.length === 0) {
      return {
        hasData: false,
        dominantEmotion: 'neutral',
        dominantLabel: 'Balanced',
        dominantEmoji: '🌱',
        totalDetections: 0,
        breakdown: {} as Record<string, number>,
        tip: "Nexora is listening actively. Express how you feel today (try writing about sadness, stress, excitement, or gratitude) to activate the Empathy Engine! ✨"
      };
    }

    const counts: Record<string, number> = {};
    let maxCount = 0;
    let dominant = 'neutral';
    let dominantLabel = 'Balanced';
    let dominantEmoji = '🌱';

    emotionMsgs.forEach(m => {
      if (m.emotionAnalysis) {
        const emo = m.emotionAnalysis.emotion;
        counts[emo] = (counts[emo] || 0) + 1;
        if (counts[emo] > maxCount) {
          maxCount = counts[emo];
          dominant = emo;
          dominantLabel = m.emotionAnalysis.label;
          dominantEmoji = m.emotionAnalysis.emoji;
        }
      }
    });

    let tip = "Mausam mast ho ya tension ho, bhai-brotherhood hamesha lock-in rahegi. Sab badiya h!";
    if (dominant === 'sad') {
      tip = "Suno yaar, rona/dukh normal hai. Khud pe bohot zyada pressure mat dalo. Ek cup chai piyo aur rest lo, Nexora hamesha aapke saath h! ☕️❤️";
    } else if (dominant === 'stressed') {
      tip = "Tension lene se dimaag kharab hota h, problem solve nahi hoti. Lambi saans lo (Inhale-Exhale), deep breathing karo, aur step-by-step conquer karo! 🧘‍♂️✨";
    } else if (dominant === 'angry') {
      tip = "Gussa aana natural h, par use self-growth me badlo. Thoda thanda paani piyo aur cool down karo, let's solve this together! 🌊🧊";
    } else if (dominant === 'love') {
      tip = "Kya baat h, humari dosti ekdum solid h! Aise hi positive raho aur khushiyan baant te raho yaara! 🙏❤️";
    } else if (dominant === 'excited') {
      tip = "Bawal energy! Is momentum ko carry karo aur aaj ka din dhasu banao. Party pending h boss! 🔥🥳";
    }

    return {
      hasData: true,
      dominantEmotion: dominant,
      dominantLabel,
      dominantEmoji,
      totalDetections: emotionMsgs.length,
      breakdown: counts,
      tip
    };
  };

  const getSuggestedPrompts = () => {
    const msgs = activeSession?.messages || [];
    
    // Default icebreakers for a new thread / empty chat
    const defaultIcebreakers = [
      { text: "Bhai, Nexora exact kya h?", emoji: "🚀", category: "general", tooltip: "Gets an introduction to Nexora, its features, and creator Raja Kumar Choudhary." },
      { text: "Dosti vibe check karo na!", emoji: "🤜🤛", category: "history", tooltip: "Analyzes our dynamic conversation vibe, compatibility & friendship level." },
      { text: "Suggest some good weekend vibe", emoji: "✨", category: "general", tooltip: "Gets custom cool recommendations for weekend movies, tunes, or activities." },
      { text: "Aaj thoda stress lag raha hai...", emoji: "😰", category: "general", tooltip: "Starts an empathetic, soothing destressing dialogue with Nexora." },
      { text: "Explain quantum physics like i'm 5", emoji: "⚛️", category: "general", tooltip: "Explains tricky scientific concepts using funny, simple daily-life analogies." },
      { text: "Ultimate Hinglish study tips batao", emoji: "📚", category: "general", tooltip: "Gets high-yield, smart study & concentration tips designed for Indian students." }
    ];
 
    // If chat has no AI replies (essentially empty or only system)
    if (msgs.length === 0) {
      const seed = (activeSessionId ? activeSessionId.charCodeAt(0) + activeSessionId.charCodeAt(activeSessionId.length - 1 || 0) : 0) + promptRefreshCount;
      // Stably shuffle based on seed to give unique starting icebreakers per session
      const shuffled = [...defaultIcebreakers].sort((a, b) => {
        const scoreA = (a.text.charCodeAt(0) + seed) % 5;
        const scoreB = (b.text.charCodeAt(0) + seed) % 5;
        return scoreA - scoreB;
      });
      return shuffled.slice(0, 6);
    }
 
    // If we have messages, let's pick based on emotional trajectory/history!
    const lastAI = [...msgs].reverse().find(m => m.sender === 'ai');
    const lastUser = [...msgs].reverse().find(m => m.sender === 'user');
    const lastEmotion = lastAI?.emotionAnalysis?.emotion;
 
    let dynamicPrompts = [];
 
    if (lastEmotion === 'sad' || lastEmotion === 'stressed') {
      dynamicPrompts = [
        { text: "Simple steps to calm my mind right now", emoji: "🧘‍♂️", category: "general", tooltip: "Triggers a quick, soothing breathing exercise to lower heart rate." },
        { text: "Write an inspiring motivation quote for me", emoji: "🔥", category: "general", tooltip: "Gets a personalized high-octane motivational booster spark." },
        { text: "Let's change the topic to something cool!", emoji: "🎈", category: "general", tooltip: "Switches the current vibe to lighthearted, cheerful, and random topics." },
        { text: "Suggest a fast destress activity, bhai", emoji: "⚡", category: "general", tooltip: "Recommends a fast, physical 2-minute activity to shake off heavy stress." }
      ];
    } else if (lastEmotion === 'angry') {
      dynamicPrompts = [
        { text: "Suggest an exercise to release frustration", emoji: "💪", category: "general", tooltip: "Recommended psychological tools to safely release anger." },
        { text: "Let's crack a light-hearted joke!", emoji: "😂", category: "general", tooltip: "Gets a funny, high-quality sarcastic joke from Nexora." },
        { text: "How can I channel this anger positively?", emoji: "🌱", category: "general", tooltip: "Explains how to transform immediate anger into productive focus." }
      ];
    } else if (lastEmotion === 'love' || lastEmotion === 'happy' || lastEmotion === 'excited') {
      dynamicPrompts = [
        { text: "Any celebratory meme status for this?", emoji: "🎉", category: "general", tooltip: "Gets a top-tier Hinglish meme status response to double the joy." },
        { text: "Write a high-energy shayari for us!", emoji: "✍️", category: "general", tooltip: "Crafts a warm and premium Hindustani poetry line celebrating the moment." },
        { text: "Vibe check level counter show please", emoji: "📈", category: "history", tooltip: "Displays live charts of our active relationship progress." },
        { text: "Tell me a highly sarcastic story", emoji: "🎭", category: "general", tooltip: "Spins a witty, tongue-in-cheek custom short story to entertain you." }
      ];
    } else {
      // Analyze last user text to provide smart relevant expansion prompts!
      const userText = lastUser?.text.toLowerCase() || "";
      if (userText.includes("code") || userText.includes("bug") || userText.includes("error") || userText.includes("program")) {
        dynamicPrompts = [
          { text: "Optimize my current code structure", emoji: "💻", category: "coding", tooltip: "Asks Nexora to review code readability, latency, and performance improvements." },
          { text: "Find potential edge cases for this", emoji: "🔍", category: "coding", tooltip: "Tests logic against hidden bugs, null boundaries, and scale inputs." },
          { text: "Give me a super fast explanation", emoji: "💡", category: "coding", tooltip: "Converts the coding issue into a simplified, quick 2-line summary." }
        ];
      } else if (userText.includes("explain") || userText.includes("what") || userText.includes("why") || userText.includes("how")) {
        dynamicPrompts = [
          { text: "Can you summarize that in 3 bullet points?", emoji: "📋", category: "history", tooltip: "Instantly compresses the previous detailed answer into simple specs." },
          { text: "Give me a real-world example, yaara", emoji: "🌍", category: "general", tooltip: "Shows how the explained concept functions in everyday life." },
          { text: "What is the counter-argument for this?", emoji: "🤔", category: "general", tooltip: "Provides alternate views to analyze both sides of the coin." }
        ];
      } else {
        // Generic ongoing conversation continuation options
        dynamicPrompts = [
          { text: "Bhai, expand on your last point", emoji: "🧠", category: "general", tooltip: "Dives deep into the latest subject with details and citations." },
          { text: "Summarize this chat till now", emoji: "📝", category: "history", tooltip: "Creates a neat, scannable summary of the entire session." },
          { text: "Give a Hinglish sarcasm breakdown", emoji: "😂", category: "history", tooltip: "Gets a funny sarcasm review of our conversation history." },
          { text: "What should we discuss next?", emoji: "🛸", category: "general", tooltip: "Rolls some exciting, random cool topics to explore next." }
        ];
      }
    }

    const blended = [...dynamicPrompts];
    if (blended.length < 6) {
      blended.push(...defaultIcebreakers);
    }
    
    // To satisfy "change it every time" we can use a timestamp seed that rotates every 15s + message count + manual refresh trigger
    const timeSeed = Math.floor(Date.now() / 15000) + msgs.length + promptRefreshCount * 17;
    const shuffled = blended.sort((a, b) => {
      const hA = a.text.charCodeAt(2) + timeSeed;
      const hB = b.text.charCodeAt(2) + timeSeed;
      return (hA % 5) - (hB % 5);
    });

    const seen = new Set();
    const unique = shuffled.filter(p => {
      if (seen.has(p.text)) return false;
      seen.add(p.text);
      return true;
    });

    return unique.slice(0, 6);
  };

  const handleToggleReaction = async (messageId: number, emoji: string) => {
    let finalEmoji: string | null = emoji;
    
    setSessions(prev => {
      return prev.map(s => {
        if (s.id === activeSessionId) {
          const updatedMessages = s.messages.map(m => {
            if (m.id === messageId) {
              const currentReaction = m.reaction || null;
              finalEmoji = currentReaction === emoji ? null : emoji;
              return { ...m, reaction: finalEmoji };
            }
            return m;
          });
          return { ...s, messages: updatedMessages };
        }
        return s;
      });
    });

    if (authToken) {
      try {
        await fetch(`/api/messages/${messageId}/reaction`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authToken}`
          },
          body: JSON.stringify({ reaction: finalEmoji })
        });
      } catch (err) {
        console.error("Failed to persist emoji reaction in Server DB:", err);
      }
    }
  };

  const toggleListening = () => {
    if (!speechSupported) {
      setSpeechError("Aapke browser me voice dictation supported nahi hai. Chrome ya Edge use kare.");
      return;
    }

    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      try {
        recognitionRef.current?.start();
      } catch (e) {
        console.error("Failed to start speech recognition:", e);
      }
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);

  const selectSession = (id: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setActiveSpokenId(null);
    setActiveSessionId(id);
    setViewMode('chat');
    if (isMobile) {
      setSidebarOpen(false);
    }
  };

  const createNewSession = (mode: 'chat' | 'history' | 'genz' = 'chat') => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setActiveSpokenId(null);
    const newId = `session-${Date.now()}`;
    setViewMode('chat');
    
    let welcomeText = 'Namaste! ⚡️ Main hoon Nexora AI, India ka sabse advanced AI jise Raja Kumar Choudhary ne banaya hai. Aaj main aapki kya madad karu?';
    let welcomeTitle = 'Zabardast Chat ✨';
    
    if (mode === 'history') {
      welcomeText = 'Jai Hind! 🇮🇳 Main hoon Nexora AI (Bharat ka History Special). Raja Kumar Choudhary dwara banaya gaya ye mode pure aur verified history search karta hai. Bataiye, Bharat ke kis adhyay ke baare me charcha karein?';
      welcomeTitle = 'Bharat Ka History 🇮🇳';
    } else if (mode === 'genz') {
      welcomeText = 'Yo bestie! Main Nexora AI hoon, lowkey your new fav AI built by Raja Kumar Choudhary. No cap, this mode is pure Gen Z vibe. Spill the tea, what are we cookin\' today? 💅🔥';
      welcomeTitle = 'Gen Z Vibes ✨';
    }

    const newSession: ChatSession = {
      id: newId,
      title: welcomeTitle,
      messages: [{ id: Date.now(), sender: 'ai', text: welcomeText, timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }],
      updatedAt: Date.now(),
      mode: mode
    };
    
    setSessions(prev => [newSession, ...prev]);
    setActiveSessionId(newId);
    setInput('');
    if (isMobile) {
      setSidebarOpen(false);
    }

    // Sync to PostgreSQL if Logged In
    if (authToken) {
      fetch('/api/sessions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({ id: newId, title: welcomeTitle, mode: mode })
      }).then(res => {
        if (res.ok) {
          fetch(`/api/sessions/${newId}/messages`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({ sender: 'ai', text: welcomeText, timestamp: newSession.messages[0].timestamp })
          });
        }
      }).catch(err => console.error(err));
    }
  };

  const deleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setActiveSpokenId(null);

    const remaining = sessions.filter(s => s.id !== id);
    if (remaining.length === 0) {
      const defaultSess: ChatSession = {
        id: 'session-1',
        title: 'Zabardast Chat ✨',
        messages: [{ id: Date.now(), sender: 'ai', text: 'Namaste! ⚡️ Main hoon Nexora AI, India ka sabse advanced AI jise Raja Kumar Choudhary ne banaya hai. Aaj main aapki kya madad karu?', timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }],
        updatedAt: Date.now(),
        mode: 'chat'
      };
      setSessions([defaultSess]);
      setActiveSessionId('session-1');
    } else {
      setSessions(remaining);
      if (activeSessionId === id) {
        setActiveSessionId(remaining[0].id);
      }
    }

    // Server Sync
    if (authToken) {
      fetch(`/api/sessions/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${authToken}` }
      }).catch(err => console.error(err));
    }
  };

  const resetAllChats = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setActiveSpokenId(null);
    
    // Server deletion sync
    if (authToken) {
      sessions.forEach(s => {
        fetch(`/api/sessions/${s.id}`, {
          method: 'DELETE',
          headers: { 'Authorization': `Bearer ${authToken}` }
        }).catch(err => console.error(err));
      });
    }

    localStorage.removeItem('nexora_sessions');
    localStorage.removeItem('nexora_active_session_id');
    
    const defaultSess: ChatSession = {
      id: 'session-1',
      title: 'Zabardast Chat ✨',
      messages: [{ id: Date.now(), sender: 'ai', text: 'Namaste! ⚡️ Main hoon Nexora AI, India ka sabse advanced AI jise Raja Kumar Choudhary ne banaya hai. Aaj main aapki kya madad karu?', timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }],
      updatedAt: Date.now(),
      mode: 'chat'
    };
    setSessions([defaultSess]);
    setActiveSessionId('session-1');
    setInput('');
    if (isMobile) {
      setSidebarOpen(false);
    }
  };

  const handleLogin = async () => {
    try {
      const { signInWithPopup, GoogleAuthProvider } = await import('firebase/auth');
      googleAuthProvider.addScope('https://www.googleapis.com/auth/calendar');
      googleAuthProvider.addScope('https://www.googleapis.com/auth/calendar.events');
      
      const result = await signInWithPopup(auth, googleAuthProvider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (credential?.accessToken) {
        setGoogleAccessToken(credential.accessToken);
        sessionStorage.setItem('google_cal_access_token', credential.accessToken);
      }
    } catch (error) {
      console.error("Google login failed:", error);
    }
  };

  const handleConnectCalendar = async () => {
    setIsConnectingCalendar(true);
    try {
      const { signInWithPopup, GoogleAuthProvider } = await import('firebase/auth');
      googleAuthProvider.addScope('https://www.googleapis.com/auth/calendar');
      googleAuthProvider.addScope('https://www.googleapis.com/auth/calendar.events');
      
      const result = await signInWithPopup(auth, googleAuthProvider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (credential?.accessToken) {
        setGoogleAccessToken(credential.accessToken);
        sessionStorage.setItem('google_cal_access_token', credential.accessToken);
        setViewMode('calendar');
      }
    } catch (error) {
      console.error("Calendar connection failed:", error);
    } finally {
      setIsConnectingCalendar(false);
    }
  };

  const handleLogout = async () => {
    try {
      const { signOut } = await import('firebase/auth');
      await signOut(auth);
      
      // Clean up in-memory and persisted Google Credentials
      setGoogleAccessToken(null);
      sessionStorage.removeItem('google_cal_access_token');
      setViewMode('chat');
      
      // Reset local listings
      localStorage.removeItem('nexora_sessions');
      localStorage.removeItem('nexora_active_session_id');
      const defaultSess: ChatSession = {
        id: 'session-1',
        title: 'Zabardast Chat ✨',
        messages: [{ id: Date.now(), sender: 'ai', text: 'Namaste! ⚡️ Main hoon Nexora AI, India ka sabse advanced AI jise Raja Kumar Choudhary ne banaya hai. Aaj main aapki kya madad karu?', timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }],
        updatedAt: Date.now(),
        mode: 'chat'
      };
      setSessions([defaultSess]);
      setActiveSessionId('session-1');
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  const autoGenerateCatchyTitle = async (sessionId: string, currentMessages: Message[]) => {
    try {
      const headersObject: Record<string, string> = { 'Content-Type': 'application/json' };
      if (authToken) {
        headersObject['Authorization'] = `Bearer ${authToken}`;
      }

      const res = await fetch(`/api/sessions/${sessionId}/generate-title`, {
        method: 'POST',
        headers: headersObject,
        body: JSON.stringify({ messages: currentMessages })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.title) {
          setSessions(prev => prev.map(s => {
            if (s.id === sessionId) {
              return { ...s, title: data.title, updatedAt: Date.now() };
            }
            return s;
          }));
        }
      }
    } catch (err) {
      console.error("Failed to automatically generate catchy title:", err);
    }
  };

  const sendMessage = async (overrideText?: string) => {
    const textToSend = overrideText !== undefined ? overrideText : input;
    if (!textToSend.trim()) return;

    if (isListening) {
      recognitionRef.current?.stop();
    }

    const targetSessionId = activeSession.id || activeSessionId || 'session-1';
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const userMessage: Message = { id: Date.now(), sender: 'user', text: textToSend, timestamp: now };
    
    let updatedTitle = activeSession.title || 'Zabardast Chat ✨';
    if ((!activeSession.messages || activeSession.messages.length <= 1) && 
        (updatedTitle.includes('Naya Chat Thread') || updatedTitle.includes('Zabardast Chat') || updatedTitle.includes('Naya Chat'))) {
      updatedTitle = textToSend.length > 25 ? textToSend.substring(0, 25) + '...' : textToSend;
    }

    // Save locally
    setSessions(prev => {
      const exists = prev.some(s => s.id === targetSessionId);
      if (exists) {
        return prev.map(s => {
          if (s.id === targetSessionId) {
            return {
              ...s,
              title: updatedTitle,
              messages: [...s.messages, userMessage],
              updatedAt: Date.now()
            };
          }
          return s;
        });
      } else {
        const newSession: ChatSession = {
          id: targetSessionId,
          title: updatedTitle,
          messages: [userMessage],
          updatedAt: Date.now(),
          mode: activeSession.mode || 'chat'
        };
        return [newSession, ...prev];
      }
    });

    if (activeSessionId !== targetSessionId) {
      setActiveSessionId(targetSessionId);
    }

    setInput('');
    setLoading(true);

    // Save User message to Server PostgreSQL DB
    if (authToken) {
      // Sync Session first if title updated
      fetch('/api/sessions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({ id: targetSessionId, title: updatedTitle, mode: activeSession.mode || 'chat' })
      }).then((res) => {
        if (!res.ok) throw new Error("Failed sessions creation");
        return fetch(`/api/sessions/${targetSessionId}/messages`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authToken}`
          },
          body: JSON.stringify({ sender: 'user', text: userMessage.text, timestamp: userMessage.timestamp })
        });
      })
      .then(res => {
        if (res && res.ok) return res.json();
      })
      .then(savedMsg => {
        if (savedMsg && savedMsg.id) {
          setSessions(prev => prev.map(s => {
            if (s.id === targetSessionId) {
              return {
                ...s,
                messages: s.messages.map(m => m.id === userMessage.id ? { ...m, id: savedMsg.id } : m)
              };
            }
            return s;
          }));
        }
      })
      .catch(err => console.error(err));
    }

    try {
      const headersObject: Record<string, string> = { 'Content-Type': 'application/json' };
      if (authToken) {
        headersObject['Authorization'] = `Bearer ${authToken}`;
      }

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: headersObject,
        body: JSON.stringify({ 
          message: userMessage.text, 
          mode: activeSession.mode || 'chat',
          ragEnabled: ragEnabled,
          advancedSearch: advancedSearchEnabled
        }),
      });
      const data = await response.json();
      
      if (data.sqlLogs && data.sqlLogs.length > 0) {
        setRecentSqlLogs(data.sqlLogs);
      }
      
      const aiTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const aiMessage: Message = { 
        id: Date.now() + 1, 
        sender: 'ai', 
        text: data.reply || "Bhai, server side validation issue, please retry in a sec!", 
        timestamp: aiTime,
        emotionAnalysis: data.emotionAnalysis || null,
        matchedChunks: data.matchedChunks || null
      };

      setSessions(prev => {
        const exists = prev.some(s => s.id === targetSessionId);
        if (exists) {
          return prev.map(s => {
            if (s.id === targetSessionId) {
              return {
                ...s,
                messages: [...s.messages, aiMessage],
                updatedAt: Date.now()
              };
            }
            return s;
          });
        } else {
          const newSession: ChatSession = {
            id: targetSessionId,
            title: updatedTitle,
            messages: [userMessage, aiMessage],
            updatedAt: Date.now(),
            mode: activeSession.mode || 'chat'
          };
          return [newSession, ...prev];
        }
      });

      // Automatically generate a catchy short title for long chat sessions!
      const currentMsgs = [...messages, userMessage, aiMessage];
      if (currentMsgs.length >= 4 && currentMsgs.length % 4 === 0) {
        autoGenerateCatchyTitle(targetSessionId, currentMsgs);
      }

      // Save AI message to Server PostgreSQL DB
      if (authToken) {
        fetch(`/api/sessions/${targetSessionId}/messages`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authToken}`
          },
          body: JSON.stringify({ 
            sender: 'ai', 
            text: aiMessage.text, 
            timestamp: aiMessage.timestamp,
            emotionAnalysis: aiMessage.emotionAnalysis
          })
        })
        .then(res => {
          if (res && res.ok) return res.json();
        })
        .then(savedMsg => {
          if (savedMsg && savedMsg.id) {
            setSessions(prev => prev.map(s => {
              if (s.id === targetSessionId) {
                return {
                  ...s,
                  messages: s.messages.map(m => m.id === aiMessage.id ? { ...m, id: savedMsg.id } : m)
                };
              }
              return s;
            }));
          }
        })
        .catch(err => console.error(err));
      }
    } catch (e) {
      console.error(e);
      // Fallback offline message if network/server is broken
      const errorMsg: Message = {
        id: Date.now() + 2,
        sender: 'ai',
        text: "Bhai, lagta hai internet slow hai ya server side connection drop ho gaya. Ek baar refresh karke firse chat try karo na! ⚡️",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setSessions(prev => {
        return prev.map(s => {
          if (s.id === targetSessionId) {
            return {
              ...s,
              messages: [...s.messages, errorMsg]
            };
          }
          return s;
        });
      });
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setInput(prev => prev ? prev + ` [Attached File: ${file.name}]` : `[Attached File: ${file.name}] `);
    }
  };

  const renderPremiumInput = (isCentered: boolean) => {
    return (
      <div className={`w-full ${isCentered ? 'max-w-2xl' : 'max-w-4xl'} flex gap-3.5 items-center`}>
        {/* Hidden native input for dynamic file upload */}
        <input 
          type="file" 
          id="chat-file-upload" 
          className="hidden" 
          onChange={handleFileUpload} 
        />
        
        <div className="relative flex-1 flex items-center bg-zinc-900 border border-[#27272a] rounded-3xl shadow-lg focus-within:ring-2 focus-within:ring-brand-accent/60 focus-within:border-transparent transition-all duration-200 px-4 py-1.5 min-h-[54px] w-full">
          
          {/* plus button on left inside the input element */}
          <button
            type="button"
            onClick={() => {
              const fileInput = document.getElementById('chat-file-upload');
              if (fileInput) (fileInput as HTMLInputElement).click();
            }}
            className="p-1.5 rounded-full hover:bg-neutral-800 text-brand-secondary hover:text-brand-primary transition shrink-0 cursor-pointer flex items-center justify-center mr-1"
            title="Add attachment or files"
          >
            <Plus className="w-5 h-5 text-brand-secondary hover:text-white" />
          </button>
          
          <input 
            className="flex-1 bg-transparent border-0 focus:outline-hidden focus:ring-0 text-white placeholder-brand-secondary/80 text-[15px] font-medium leading-relaxed py-2 pl-1 pr-24 w-full"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
            placeholder="Ask anything"
          />
          
          {/* Voice and RAG elements inside the input right */}
          <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1.5 select-none">
            {/* RAG search toggle button */}
            <button
              type="button"
              onClick={() => setRagEnabled(prev => !prev)}
              className={`p-1.5 rounded-xl transition-all duration-200 cursor-pointer flex items-center justify-center border ${
                ragEnabled
                  ? 'bg-cyan-950/40 text-[#45f3ff] border-[#45f3ff]/30 hover:bg-cyan-950/75 shadow-xs'
                  : 'text-neutral-500 border-transparent hover:text-neutral-300 hover:bg-neutral-800'
              }`}
              title={ragEnabled ? "Active Document RAG On" : "Active Document RAG Off"}
            >
              <Database className={`w-3.5 h-3.5 ${ragEnabled ? 'animate-pulse text-[#45f3ff]' : ''}`} />
            </button>

            {/* mic icon */}
            <button 
              type="button"
              onClick={toggleListening} 
              className={`p-1.5 rounded-xl transition-all duration-200 cursor-pointer ${
                isListening 
                  ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30' 
                  : 'text-brand-secondary hover:text-white hover:bg-neutral-800'
              }`}
              title={isListening ? "Bolna Band Karein" : "Awaaz Se Type Karein"}
            >
              {isListening ? (
                <span className="relative flex h-4 w-4">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <Mic className="relative inline-flex h-4 w-4 text-red-400" />
                </span>
              ) : (
                <Mic className="w-4 h-4 text-zinc-400" />
              )}
            </button>
          </div>
        </div>

        {/* send arrow button outside the input pill on bottom right when messages exist */}
        {!isCentered && (
          <button 
            type="button"
            onClick={() => sendMessage()} 
            className="bg-brand-accent hover:bg-brand-accent-hover p-3 rounded-2xl transition-all duration-205 shrink-0 cursor-pointer shadow-md text-white flex items-center justify-center border border-transparent"
          >
            <Send className="w-4.5 h-4.5" />
          </button>
        )}
      </div>
    );
  };

  return (
    <div className="flex flex-col h-screen bg-brand-bg text-brand-primary font-sans overflow-hidden">
      {/* Upper Area: Sidebar + Main Chat Message Panel */}
      <div className="flex flex-1 overflow-hidden relative">
        
        {/* SIDE PANEL (Sidebar) wrapper */}
        <AnimatePresence initial={false}>
          {sidebarOpen && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: isMobile ? '100%' : 300, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className={`shrink-0 h-full bg-brand-sidebar border-r border-brand-border flex flex-col z-30 ${
                isMobile ? 'fixed inset-0' : 'relative'
              }`}
            >
              {/* Sidebar Header */}
              <div className="p-4 border-b border-brand-border flex items-center justify-between">
                <span className="font-bold text-lg tracking-wide text-brand-primary flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-brand-accent animate-pulse" />
                  Nexora Threads
                </span>
                {isMobile && (
                  <button 
                    onClick={() => setSidebarOpen(false)} 
                    className="p-1 rounded-xl text-brand-secondary hover:text-brand-primary hover:bg-brand-bg/50 cursor-pointer"
                  >
                    <X className="w-6 h-6" />
                  </button>
                )}
              </div>

              {/* Premium Sidebar Navigation Links matching the mockup exactly */}
              <div className="px-3 py-2 flex-1 flex flex-col gap-0.5 min-h-0" id="mockup-sidebar-links">
                {/* 1. New Chat (💬 style) */}
                <button
                  onClick={() => createNewSession((activeSession && activeSession.mode) || 'chat')}
                  className="w-full p-2.5 rounded-xl text-brand-primary hover:bg-neutral-900 transition-all duration-150 flex items-center justify-between cursor-pointer font-medium text-sm shrink-0 focus:outline-hidden"
                >
                  <div className="flex items-center gap-3">
                    <svg className="w-5 h-5 text-brand-primary fill-none stroke-current" viewBox="0 0 24 24" strokeWidth="2">
                      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                    </svg>
                    <span>New chat</span>
                  </div>
                  <Plus className="w-4 h-4 text-brand-secondary" />
                </button>

                {/* 2. Custom Integrated Search Chats */}
                <div className="px-1 py-1 shrink-0">
                  <div className="relative">
                    <span className="absolute left-2.5 top-2 flex items-center justify-center">
                      <Search className="h-3.5 w-3.5 text-brand-secondary/70" />
                    </span>
                    <input
                      type="text"
                      id="sidebar-search-input"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search chats"
                      className="w-full pl-8 pr-7 py-1.5 bg-transparent border border-transparent focus:border-brand-border/40 focus:outline-hidden text-xs rounded-lg text-brand-primary placeholder:text-brand-secondary/60 transition-all duration-155"
                    />
                    {searchQuery && (
                      <button
                        onClick={() => setSearchQuery('')}
                        className="absolute right-1.5 top-1.5 p-0.5 rounded-full hover:bg-neutral-800 text-brand-secondary hover:text-brand-primary transition-colors cursor-pointer"
                        title="Clear search"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Separator and Recents header inside the flex container */}
                <div className="px-2 pt-3 pb-1 border-t border-brand-border/45 shrink-0 select-none flex items-center justify-between mt-2">
                  <span className="text-[11px] text-brand-primary font-bold uppercase tracking-wider">Recents</span>
                </div>

                {/* Chat Sessions List (moved inside mockup-sidebar-links) */}
                <div className="flex-1 overflow-y-auto px-1 py-2 space-y-1 min-h-0">
                  {filteredSessions.length === 0 ? (
                    <div className="p-4 text-center text-xs text-brand-secondary flex flex-col items-center gap-1 select-none">
                      <span className="text-lg">🔍</span>
                      <span className="font-medium text-brand-secondary/80">Yahan kuch nahi mila, yaara!</span>
                      <span className="text-[10px] text-brand-secondary/50">Apna search keywords badal ke dekho.</span>
                    </div>
                  ) : (
                    filteredSessions.map(s => {
                      const isActive = s.id === activeSessionId;
                      return (
                        <div
                          key={s.id}
                          onClick={() => selectSession(s.id)}
                          className={`group w-full p-3 rounded-xl flex items-center gap-3 transition-colors duration-200 cursor-pointer border border-transparent ${
                            isActive 
                              ? 'bg-brand-bg border-l-4 border-l-brand-accent text-white shadow-xs' 
                              : 'text-brand-secondary hover:bg-brand-bg/40 hover:text-brand-primary'
                          }`}
                        >
                          <MessageSquare className={`w-4 h-4 shrink-0 ${isActive ? 'text-brand-accent' : 'text-brand-secondary'}`} />
                          <span className="flex-1 text-sm font-semibold truncate pr-2">
                            {s.title}
                          </span>
                          <button
                            onClick={(e) => deleteSession(s.id, e)}
                            className="opacity-0 group-hover:opacity-100 p-1.5 rounded-xl text-brand-secondary hover:text-red-400 hover:bg-brand-bg transition cursor-pointer"
                            title="Delete chat thread"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* More Option button swapped to where Chat Sessions List used to be (above the footer) */}
              <div className="px-3 py-2 shrink-0 border-t border-brand-border/45">
                <button
                  onClick={() => setAccountMenuOpen(true)}
                  className="w-full p-2.5 rounded-xl text-brand-secondary hover:text-brand-primary hover:bg-neutral-900 transition-all duration-150 flex items-center gap-3 cursor-pointer font-medium text-sm text-left focus:outline-hidden"
                >
                  <span className="text-sm font-semibold tracking-wide block w-5 text-center leading-none text-brand-secondary">•••</span>
                  <span>More</span>
                </button>
              </div>

              {/* Sidebar Footer */}
              <div className="p-3 border-t border-brand-border bg-brand-sidebar relative shrink-0">
                <AnimatePresence>
                  {accountMenuOpen && (
                    <>
                      {/* Clicking on back drop dismisses settings */}
                      <div 
                        className="fixed inset-0 z-40 bg-black/5" 
                        onClick={() => setAccountMenuOpen(false)} 
                      />
                      <motion.div
                        initial={{ opacity: 0, y: 15, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 15, scale: 0.95 }}
                        transition={{ duration: 0.15 }}
                        className="absolute bottom-full left-3 right-3 mb-2 bg-brand-sidebar border border-brand-border rounded-xl p-3 shadow-2xl z-50 divide-y divide-brand-border/40"
                      >
                        {/* User credentials */}
                        <div className="pb-2.5 px-1">
                          <span className="block text-[10px] font-bold text-brand-secondary tracking-widest uppercase">
                            {syncing ? 'Syncing...' : 'Nexora Account Info'}
                          </span>
                          <span className="block text-xs font-bold text-brand-primary truncate mt-1">
                            {user ? (user.displayName || user.email) : "Mehmaan User (Guest) 👤"}
                          </span>
                          {user && (
                            <span className="block text-[10px] text-green-400 font-bold mt-0.5 flex items-center gap-1">
                              <span className="h-1.5 w-1.5 rounded-full bg-green-400 animate-pulse"></span>
                              Cloud Backup Activated
                            </span>
                          )}
                        </div>

                        {/* Interactive setting options */}
                        <div className="py-2.5 px-1 flex flex-col gap-3.5">
                          <div className="flex items-center justify-between">
                            <div className="flex flex-col">
                              <span className="text-xs font-bold text-brand-primary">Empathy Radar Mode</span>
                              <span className="text-[10px] text-brand-secondary mt-0.5">Toggle real-time mood sense response</span>
                            </div>
                            <button
                              onClick={() => setShowEmpathyInsights(!showEmpathyInsights)}
                              className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 outline-hidden ${
                                showEmpathyInsights ? 'bg-brand-accent' : 'bg-brand-border'
                              }`}
                              title="Off/On Empathy analysis mode"
                            >
                              <span
                                className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ${
                                  showEmpathyInsights ? 'translate-x-4' : 'translate-x-0'
                                }`}
                              />
                            </button>
                          </div>

                          <div className="flex items-center justify-between">
                            <div className="flex flex-col">
                              <div className="flex items-center gap-1.5">
                                <span className="text-xs font-bold text-brand-primary">Advanced Search</span>
                                <span className="px-1.5 py-0.5 text-[8.5px] bg-[#45f3ff]/10 text-[#45f3ff] font-extrabold rounded-md select-none border border-[#45f3ff]/20 tracking-wider">MULTI-QUERY</span>
                              </div>
                              <span className="text-[10px] text-brand-secondary mt-0.5">Run multiple search streams to synthesize</span>
                            </div>
                            <button
                              onClick={() => {
                                const newVal = !advancedSearchEnabled;
                                setAdvancedSearchEnabled(newVal);
                                localStorage.setItem("advanced_search_enabled", String(newVal));
                              }}
                              className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 outline-hidden ${
                                advancedSearchEnabled ? 'bg-brand-accent' : 'bg-brand-border'
                              }`}
                              title="Toggle Advanced Search (multi-query Bing India synthesis)"
                            >
                              <span
                                className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ${
                                  advancedSearchEnabled ? 'translate-x-4' : 'translate-x-0'
                                }`}
                              />
                            </button>
                          </div>

                          <div className="flex items-center justify-between">
                            <div className="flex flex-col">
                              <span className="text-xs font-bold text-brand-primary">Classic Theme Mode</span>
                              <span className="text-[10px] text-brand-secondary mt-0.5">Choose light or dark aesthetic</span>
                            </div>
                            <button
                              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                              className="p-1.5 rounded-lg border border-brand-border hover:bg-brand-bg/60 text-brand-secondary hover:text-brand-primary transition duration-150 flex items-center gap-1.5 cursor-pointer"
                              title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
                            >
                              {theme === 'dark' ? (
                                <>
                                  <Sun className="w-3.5 h-3.5 text-brand-accent" />
                                  <span className="text-[10px] font-bold">Light</span>
                                </>
                              ) : (
                                <>
                                  <Moon className="w-3.5 h-3.5 text-brand-accent" />
                                  <span className="text-[10px] font-bold">Dark</span>
                                </>
                              )}
                            </button>
                          </div>
                        </div>

                        {/* Control actions */}
                        <div className="pt-2 flex flex-col gap-1">
                          <button
                            onClick={() => {
                              resetAllChats();
                              setAccountMenuOpen(false);
                            }}
                            className="w-full text-left p-2 rounded-lg hover:bg-red-500/10 text-brand-secondary hover:text-red-400 text-xs font-bold transition flex items-center gap-2 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            Sare Chat Threads Mitaayein
                          </button>
                          
                          <button
                            onClick={() => {
                              alert("Nexora AI v3.5 is developed with pride in India by Raja Choudhary & Co. | Nexora AI India AI. Utilizing dynamic, secure search pipelines.");
                              setAccountMenuOpen(false);
                            }}
                            className="w-full text-left p-2 rounded-lg hover:bg-brand-bg/50 text-brand-secondary hover:text-brand-primary text-xs font-bold transition flex items-center gap-2 cursor-pointer"
                          >
                            <Settings className="w-3.5 h-3.5" />
                            Help & Creator Info
                          </button>

                          {user ? (
                            <button
                              onClick={() => {
                                handleLogout();
                                setAccountMenuOpen(false);
                              }}
                              className="w-full text-left p-2 rounded-lg hover:bg-neutral-800 text-red-400 text-xs font-bold transition flex items-center gap-2 cursor-pointer border border-transparent hover:border-red-900/35"
                            >
                              <LogOut className="w-3.5 h-3.5" />
                              Logout Account
                            </button>
                          ) : (
                            <button
                              onClick={() => {
                                handleLogin();
                                setAccountMenuOpen(false);
                              }}
                              className="w-full text-left p-2 rounded-lg bg-brand-accent/20 hover:bg-brand-accent/35 text-brand-accent text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer"
                            >
                              <svg className="w-3.5 h-3.5 fill-current text-brand-accent" viewBox="0 0 24 24">
                                <path d="M12.24 10.285V13.4h6.887c-.275 1.565-1.88 4.604-6.887 4.604-4.33 0-7.859-3.578-7.859-8s3.53-8 7.859-8c2.46 0 4.105 1.025 5.047 1.926l2.427-2.334C17.955 2.192 15.34 1 12.24 1 6.033 1 12.24 6.033 1 12.24s5.033 11.24 11.24 11.24c6.478 0 10.793-4.537 10.793-10.986 0-.745-.08-1.314-.176-1.875H12.24z"/>
                              </svg>
                              Log in with Google
                            </button>
                          )}
                        </div>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>

                <button
                  onClick={() => setAccountMenuOpen(!accountMenuOpen)}
                  className="w-full p-2 rounded-xl border border-brand-border/60 hover:border-brand-border bg-brand-bg/50 hover:bg-brand-bg text-brand-primary transition-all duration-200 flex items-center justify-between cursor-pointer focus:outline-hidden"
                >
                  <div className="flex items-center gap-2.5 truncate">
                    {user ? (
                      <>
                        {user.photoURL ? (
                          <img 
                            src={user.photoURL} 
                            alt="avatar" 
                            className="w-7 h-7 rounded-full border border-brand-border object-cover referrerPolicy='no-referrer'" 
                          />
                        ) : (
                          <div className="w-7 h-7 rounded-full bg-brand-accent/20 border border-brand-border flex items-center justify-center text-brand-accent text-xs font-bold shrink-0">
                            {user.email?.charAt(0).toUpperCase() || "U"}
                          </div>
                        )}
                        <div className="text-left truncate">
                          <span className="block text-xs font-semibold text-brand-primary truncate max-w-[130px]">
                            {user.displayName || user.email}
                          </span>
                          <span className="block text-[9px] text-brand-accent font-bold">
                            Account Menu
                          </span>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="w-7 h-7 rounded-full bg-neutral-800 border border-brand-border/70 flex items-center justify-center text-brand-secondary text-xs shrink-0 font-bold">
                          N
                        </div>
                        <div className="text-left">
                          <span className="block text-xs font-semibold text-brand-primary">
                            Mehmaan (Guest)
                          </span>
                          <span className="block text-[9px] text-brand-secondary font-bold">
                            Login / Settings
                          </span>
                        </div>
                      </>
                    )}
                  </div>
                  <ChevronDown className={`w-4 h-4 text-brand-secondary shrink-0 transition-transform duration-300 ${accountMenuOpen ? 'rotate-180 text-brand-accent' : ''}`} />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Chat Panel */}
        <div className="flex-1 flex flex-col h-full overflow-hidden relative bg-brand-bg animate-subtle-gradient">
          <header className="p-4 border-b border-brand-border/40 flex items-center justify-between bg-brand-bg/60 backdrop-blur-md z-10">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="p-1.5 rounded-xl border border-brand-border text-brand-secondary hover:text-brand-primary hover:bg-brand-sidebar transition cursor-pointer"
                title={sidebarOpen ? "Hide sidebar" : "Show sidebar"}
              >
                {sidebarOpen ? <PanelLeftClose className="w-5 h-5" /> : <PanelLeft className="w-5 h-5" />}
              </button>
              
              <div className="relative">
                <button
                  onClick={() => setModelDropdownOpen(!modelDropdownOpen)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-xl hover:bg-brand-sidebar transition-all duration-200 cursor-pointer font-bold text-lg select-none text-brand-primary group border border-transparent hover:border-brand-border"
                >
                  <span className="text-brand-primary flex items-center gap-2">
                    Nexora AI
                  </span>
                  <span className="text-xs font-mono font-bold py-0.5 px-2 rounded-md bg-brand-sidebar text-brand-secondary group-hover:text-brand-accent group-hover:bg-brand-bg transition-all duration-200 capitalize">
                    {activeSession.mode === 'history' ? 'v3.5 History 📜' : activeSession.mode === 'genz' ? 'v3.5 GenZ ✨' : 'v3.5 Chat 💬'}
                  </span>
                  <ChevronDown className={`w-4 h-4 text-brand-secondary group-hover:text-white transition-transform duration-300 ${modelDropdownOpen ? 'rotate-180' : ''}`} />
                </button>

                <AnimatePresence>
                  {modelDropdownOpen && (
                    <>
                      {/* Invisible click backdrop to dismiss dropdown */}
                      <div 
                        className="fixed inset-0 z-40" 
                        onClick={() => setModelDropdownOpen(false)} 
                      />
                      
                      <motion.div
                        initial={{ opacity: 0, y: 8, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 8, scale: 0.95 }}
                        transition={{ duration: 0.15 }}
                        className="absolute left-0 mt-2 w-72 bg-brand-sidebar border border-brand-border rounded-xl p-2.5 shadow-2xl z-50 overflow-hidden divide-y divide-brand-border/40"
                      >
                        {[
                          { id: 'chat', label: '💬 Nexora Chat v3.5', desc: 'Direct Bing India Search response. Fast, professional, with zero search reference noise.', color: 'text-brand-accent', hoverBg: 'hover:bg-brand-bg/40' },
                          { id: 'history', label: '📜 Bharat ka History v3.5', desc: 'Wiki + Bing India deep synthesis. Explores Indian history with verified sources.', color: 'text-purple-400', hoverBg: 'hover:bg-brand-bg/40' },
                          { id: 'genz', label: '✨ Gen Z Vibes v3.5', desc: 'Slang-filled conversational mode. Combines Gemini + Bing search directly.', color: 'text-rose-400', hoverBg: 'hover:bg-brand-bg/40' }
                        ].map((model) => {
                          const active = activeSession.mode === model.id;
                          return (
                            <button
                              key={model.id}
                              onClick={() => {
                                setModelDropdownOpen(false);
                                setSessions(prev => prev.map(s => {
                                  if (s.id === activeSessionId) {
                                    let welcomeText = 'Namaste! ⚡️ Main hoon Nexora AI, India ka sabse advanced AI jise Raja Kumar Choudhary ne banaya hai. Aaj main aapki kya madad karu?';
                                    if (model.id === 'history') {
                                      welcomeText = 'Jai Hind! 🇮🇳 Main hoon Nexora AI (Bharat ka History Special). Raja Kumar Choudhary dwara banaya gaya ye mode pure aur verified history search karta hai. Bataiye, Bharat ke kis adhyay ke baare me charcha karein?';
                                    } else if (model.id === 'genz') {
                                      welcomeText = 'Yo bestie! Main Nexora AI hoon, lowkey your new fav AI built by Raja Kumar Choudhary. No cap, this mode is pure Gen Z vibe. Spill the tea, what are we cooking\' today? 💅🔥';
                                    }
                                    return {
                                      ...s,
                                      title: model.id === 'history' ? 'Bharat Ka History 🇮🇳' : model.id === 'genz' ? 'Gen Z Vibes ✨' : 'Zabardast Chat ✨',
                                      messages: [{ id: Date.now(), sender: 'ai', text: welcomeText, timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }],
                                      mode: model.id as any
                                    };
                                  }
                                  return s;
                                }));
                              }}
                              className={`w-full text-left p-2.5 rounded-xl transition-all duration-200 cursor-pointer flex items-start gap-2.5 ${model.hoverBg} ${
                                active ? 'bg-brand-bg border border-brand-border' : 'border border-transparent'
                              }`}
                            >
                              <div className="flex-1">
                                <div className="flex items-center justify-between">
                                  <span className={`font-bold text-[13px] ${model.color}`}>
                                    {model.label}
                                  </span>
                                  {active && (
                                    <span className="h-1.5 w-1.5 rounded-full bg-brand-accent animate-pulse"></span>
                                  )}
                                </div>
                                <p className="text-[10px] text-brand-secondary font-medium leading-relaxed mt-1">
                                  {model.desc}
                                </p>
                              </div>
                            </button>
                          );
                        })}
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>
            </div>
            
            {/* Minimalist Grok-style Header Indicators */}
            <div className="flex items-center gap-3">
              {syncing && (
                <span className="text-[10px] text-brand-accent font-bold animate-pulse">
                  Syncing Cloud...
                </span>
              )}
              {showEmpathyInsights && (
                <div className="flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-extrabold rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300">
                  <span className="h-1.5 w-1.5 rounded-full bg-rose-500 animate-pulse"></span>
                  Empathy Mode Active
                </div>
              )}
              <Sparkles className="text-brand-accent w-4 h-4 animate-pulse shrink-0" />
            </div>
          </header>
          
          {/* Messages List view */}
          <main className="flex-1 overflow-y-auto p-6 flex flex-col justify-between">
            {viewMode === 'calendar' ? (
              <GoogleCalendarDashboard 
                user={user}
                googleAccessToken={googleAccessToken}
                onConnect={handleConnectCalendar}
                isConnecting={isConnectingCalendar}
              />
            ) : viewMode === 'memory' ? (
              <CognitiveSqlConsole
                user={user}
                authToken={authToken}
                recentLogs={recentSqlLogs}
                onClearLogs={() => setRecentSqlLogs([])}
              />
            ) : viewMode === 'coding' ? (
              <CodingWorkspace
                user={user}
                authToken={authToken}
                setRecentSqlLogs={setRecentSqlLogs}
              />
            ) : viewMode === 'rag' ? (
              <GeminiRagDashboard
                user={user}
                authToken={authToken}
                onAddedLogs={(log) => setRecentSqlLogs(prev => [log, ...prev].slice(0, 5))}
              />
            ) : viewMode === 'neural' ? (
              <NeuralNetworkVisualizer
                user={user}
                authToken={authToken}
                onAddedLogs={(log) => setRecentSqlLogs(prev => [log, ...prev].slice(0, 5))}
              />
            ) : messages.length <= 1 ? (
              /* High fidelity ChatGPT style centered workspace home screen */
              <div className="flex-1 flex flex-col items-center justify-center max-w-2xl mx-auto w-full py-16 px-4 text-center">
                
                {/* 1. Header display label matching the design exactly */}
                <motion.h1 
                  key={agendaText}
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4 }}
                  onClick={() => {
                    const remaining = AGENDA_GREETINGS.filter(g => g !== agendaText);
                    const nextG = remaining[Math.floor(Math.random() * remaining.length)];
                    setAgendaText(nextG);
                  }}
                  className="text-[24px] md:text-[32px] font-semibold text-white tracking-tight mb-8 leading-snug cursor-pointer hover:text-brand-accent/90 transition-colors duration-200 select-none max-w-xl"
                  title="Click to change greeting & agenda!"
                >
                  {agendaText}
                </motion.h1>

                {/* 2. Floating Premium input box in centerpiece */}
                <div className="w-full flex justify-center mb-4">
                  {renderPremiumInput(true)}
                </div>



                {/* Simple Cloud Save indicator if user is not signed in */}
                {!user && (
                  <p className="text-[11px] text-brand-secondary/60 mt-10">
                    💡 Cloud sync is ready: login from account menu to permanently persist and organize threads.
                  </p>
                )}
              </div>
            ) : (
              /* Scrollable Messages Bubble List */
              <div className="space-y-6 flex-1">
                <AnimatePresence initial={false}>
                  {messages.map((m, idx) => {
                    const isUser = m.sender === 'user';
                    return (
                      <div key={m.id} className="flex flex-col gap-1 w-full">
                        {/* Chronological mini tracker header */}
                        <div className={`flex items-center gap-2 px-1 text-[9.5px] font-mono tracking-widest uppercase text-brand-secondary/45 hover:text-brand-secondary transition-colors duration-150 select-none pb-0.5 ${isUser ? 'justify-end pr-9' : 'justify-start pl-9'}`}>
                          {isUser ? (
                            <>
                              <span className="font-extrabold text-neutral-400">Aap (You)</span>
                              <span className="w-1 h-1 rounded-full bg-neutral-600/40" />
                              <Clock className="w-2.5 h-2.5 opacity-80" />
                              <span className="font-semibold text-neutral-500">{m.timestamp || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                            </>
                          ) : (
                            <>
                              <Sparkles className="w-2.5 h-2.5 text-brand-accent/70 animate-pulse shrink-0" />
                              <span className="font-extrabold text-brand-accent">Nexora AI</span>
                              <span className="w-1 h-1 rounded-full bg-brand-accent/30" />
                              <Clock className="w-2.5 h-2.5 text-brand-accent/60" />
                              <span className="font-semibold text-[#45f3ff]">{m.timestamp || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                            </>
                          )}
                        </div>

                        <motion.div 
                          initial={{ opacity: 0, y: 12 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.25 }}
                          className={`flex gap-3.5 group relative ${isUser ? 'justify-end' : ''}`}
                        >
                          {!isUser && <Bot className="text-brand-accent mt-1.5 shrink-0" />}
                          <div className={`p-4 rounded-xl max-w-2xl border transition-all duration-200 relative ${
                            isUser 
                              ? 'bg-neutral-900 border-brand-border text-brand-primary shadow-xs hover:border-[#45f3ff]/30 hover:bg-[#1a1a1b]' 
                              : 'bg-[#1e1e1f]/65 border-brand-border/60 text-brand-primary shadow-xs hover:border-[#45f3ff]/30 hover:bg-[#1f1f21]'
                          }`}>
                            {m.sender === 'ai' && m.emotionAnalysis && m.emotionAnalysis.emotion !== 'neutral' && (
                              <motion.div 
                                initial={{ opacity: 0, y: -4 }}
                                animate={{ opacity: 1, y: 0 }}
                                className={`mb-3.5 flex gap-2.5 text-xs py-2.5 px-3.5 rounded-xl border bg-brand-bg/50 select-none ${
                                  m.emotionAnalysis.emotion === 'sad' ? 'border-sky-400/30 text-sky-200 bg-sky-950/20' :
                                  m.emotionAnalysis.emotion === 'stressed' ? 'border-orange-400/30 text-orange-200 bg-orange-950/20' :
                                  m.emotionAnalysis.emotion === 'angry' ? 'border-red-400/30 text-red-200 bg-red-950/20' :
                                  m.emotionAnalysis.emotion === 'love' ? 'border-rose-400/30 text-rose-200 bg-rose-950/20' :
                                  m.emotionAnalysis.emotion === 'excited' ? 'border-amber-400/30 text-amber-200 bg-amber-950/20' :
                                  'border-green-400/30 text-green-200 bg-green-950/20'
                                }`}
                              >
                                <span className="flex items-center justify-center text-lg animate-pulse h-fit mt-0.5 shrink-0">{m.emotionAnalysis.emoji}</span>
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-1.5 font-extrabold tracking-tight">
                                    <span className="uppercase text-[9px] tracking-wider px-1.5 py-0.5 roundedbg relative bg-brand-bg/40 font-mono text-brand-accent">Nexora Sensed</span>
                                    <span className="underline underline-offset-2 decoration-1 decoration-dotted decoration-white/40">{m.emotionAnalysis.label}</span>
                                    <span className="text-[10px] opacity-75 font-mono">({Math.round(m.emotionAnalysis.score * 100)}% Intensity)</span>
                                  </div>
                                  <p className="text-[10px] font-medium leading-relaxed mt-1 opacity-80">
                                    {m.emotionAnalysis.description}
                                  </p>
                                </div>
                              </motion.div>
                            )}

                            {m.sender === 'ai' ? (
                              typedMessageIds.has(m.id) ? (
                                <MarkdownRenderer content={m.text} />
                              ) : (
                                <TypewriterMarkdown 
                                  content={m.text} 
                                  onComplete={() => markMessageAsTyped(m.id)} 
                                  key={m.id}
                                />
                              )
                            ) : (
                              <div className="whitespace-pre-wrap break-words text-[15px] leading-relaxed select-text font-medium text-brand-primary/95">{m.text}</div>
                            )}

                            {m.sender === 'ai' && m.matchedChunks && m.matchedChunks.length > 0 && (
                              <div className="mt-4 pt-3.5 border-t border-brand-border/45 select-none space-y-2">
                                <div className="flex items-center gap-1.5 font-mono text-[10px] font-extrabold uppercase text-cyan-400">
                                  <Database className="w-3.5 h-3.5 animate-pulse shrink-0 text-[#45f3ff]" />
                                  <span>References Ingested (RAG)</span>
                                </div>
                                <div className="flex flex-col gap-2">
                                  {m.matchedChunks.map((chunk, cidx) => {
                                    const isBingSource = chunk.docTitle.toLowerCase().includes("bing") || chunk.docTitle.toLowerCase().includes("search");
                                    const isWikiSource = chunk.docTitle.toLowerCase().includes("wikipedia") || chunk.docTitle.toLowerCase().includes("wikibooks");
                                    
                                    if (isWikiSource) {
                                      return (
                                        <div key={cidx} className="p-2.5 rounded-xl border border-indigo-500/25 bg-[#0d0e14] hover:border-indigo-500/45 text-white text-[10px] font-mono leading-normal transition-all max-w-full">
                                          <div className="font-extrabold text-indigo-300 flex items-center gap-1 mb-1 justify-between select-none">
                                            <span className="truncate pr-1 flex items-center gap-1.5">
                                              <span className="bg-white text-black text-[8px] font-black px-1 rounded-sm select-none">W</span>
                                              <span className="text-neutral-200">Wikipedia Live Match</span>
                                            </span>
                                            <span className="text-neutral-500 font-bold shrink-0">Index {chunk.chunkIndex}/{chunk.totalChunks}</span>
                                          </div>
                                          <p className="text-neutral-300 font-mono text-[10.5px] leading-normal break-words select-text select-all mb-1.5">
                                            {chunk.content}
                                          </p>
                                          <a 
                                            href={`https://en.wikipedia.org/wiki/${encodeURIComponent(chunk.docTitle.replace(/Wikipedia:\s*/gi, "").replace(/\s+/g, "_"))}`}
                                            target="_blank" 
                                            rel="noopener noreferrer" 
                                            className="text-indigo-400 hover:text-indigo-300 hover:underline inline-flex items-center gap-1 font-semibold text-[9.5px] mt-1 select-none"
                                          >
                                            <span>📖 View article on en.wikipedia.org</span>
                                            <ArrowRight className="w-2.5 h-2.5" />
                                          </a>
                                        </div>
                                      );
                                    }

                                    return isBingSource ? (
                                      <div key={cidx} className="p-2.5 rounded-xl border border-teal-500/20 bg-[#0c1417] hover:border-teal-500/40 text-white text-[10px] font-mono leading-normal transition-all max-w-full">
                                        <div className="font-extrabold text-teal-400 flex items-center gap-1 mb-1 justify-between select-none">
                                          <span className="truncate pr-1 flex items-center gap-1">
                                            <span className="text-[#008080] font-black px-1.5 bg-teal-500/10 rounded-sm">B</span>
                                            <span className="ml-1 text-neutral-300">Bing India Live Search Match</span>
                                          </span>
                                          <span className="text-neutral-500 font-bold shrink-0">Index {chunk.chunkIndex}/{chunk.totalChunks}</span>
                                        </div>
                                        <p className="text-neutral-300 font-mono text-[10.5px] leading-normal break-words select-text select-all mb-1.5">
                                          {chunk.content}
                                        </p>
                                        <a 
                                          href={`https://www.bing.com/search?q=${encodeURIComponent(chunk.docTitle.replace(/Bing Search \(India\):\s*/gi, "").replace(/Google Search:\s*/gi, ""))}&cc=in`}
                                          target="_blank" 
                                          rel="noopener noreferrer" 
                                          className="text-teal-400 hover:text-teal-300 hover:underline inline-flex items-center gap-1 font-semibold text-[9.5px] mt-1 select-none"
                                        >
                                          <span>🌐 Click to search on Bing India</span>
                                          <ArrowRight className="w-2.5 h-2.5" />
                                        </a>
                                      </div>
                                    ) : (
                                      <div key={cidx} className="p-2.5 rounded-xl border border-cyan-500/10 bg-[#0e1013] hover:border-cyan-500/30 text-white text-[10px] font-mono leading-normal transition-all max-w-full">
                                        <div className="font-extrabold text-[#45f3ff] flex items-center gap-1 mb-1 justify-between">
                                          <span className="truncate pr-1">📑 {chunk.docTitle}</span>
                                          <span className="text-neutral-500 font-bold shrink-0">Chunk {chunk.chunkIndex}/{chunk.totalChunks}</span>
                                        </div>
                                        <p className="text-neutral-300 font-mono text-[10.5px] leading-normal break-words select-text select-all">
                                          {chunk.content}
                                        </p>
                                      </div>
                                    );
                                  })}
                                </div>
                              </div>
                            )}
                            
                            {/* Prominent hoverable timestamp block */}
                            <div className="text-[10px] mt-2 opacity-65 group-hover:opacity-100 group-hover:text-white transition-all duration-200 flex items-center justify-between gap-4 select-none text-brand-secondary">
                              <span className="flex items-center gap-1.5 font-mono font-bold tracking-wide">
                                <Clock className="w-3 h-3 text-[#45f3ff] animate-pulse hidden group-hover:block shrink-0" />
                                <span className="group-hover:text-[#45f3ff] transition-colors">{m.timestamp ? `Sent at ${m.timestamp}` : 'Sent just now'}</span>
                              </span>
                              {m.sender === 'ai' && (
                                <div className="flex items-center gap-1.5 bg-brand-bg/20 px-1 py-0.5 rounded-xl border border-brand-border/20">
                                  {/* Speak Button */}
                                  <button
                                    onClick={() => speakMessage(m.id, m.text)}
                                    className={`p-1.5 rounded-lg transition-all duration-200 cursor-pointer ${
                                      activeSpokenId === m.id
                                        ? 'bg-brand-accent/20 text-brand-accent hover:bg-brand-accent/30 ring-1 ring-brand-accent/30'
                                        : 'text-brand-secondary hover:text-brand-primary hover:bg-brand-sidebar/50'
                                    }`}
                                    title={activeSpokenId === m.id ? "Awaaz band karein" : "Awaaz me sunein (Read aloud)"}
                                  >
                                    {activeSpokenId === m.id ? (
                                      <VolumeX className="w-3.5 h-3.5 animate-pulse" />
                                    ) : (
                                      <Volume2 className="w-3.5 h-3.5 text-neutral-400 group-hover:text-brand-accent" />
                                    )}
                                  </button>

                                  {/* Reaction Emojis Row */}
                                  <div className="flex items-center gap-1 border-l border-brand-border/40 pl-1.5">
                                    {(['👍', '👎', '❤️', '🔥', '😂'] as const).map(emoji => {
                                      const isSelected = m.reaction === emoji;
                                      return (
                                        <button
                                          key={emoji}
                                          onClick={() => handleToggleReaction(m.id, emoji)}
                                          className={`p-1 rounded-md text-xs hover:scale-125 transition-all duration-150 cursor-pointer ${
                                            isSelected 
                                              ? 'bg-brand-accent/35 text-white border border-brand-accent/40 shadow-xs' 
                                              : 'text-brand-secondary hover:text-brand-primary hover:bg-brand-sidebar/30'
                                          }`}
                                          title={`${emoji} reaction`}
                                        >
                                          {emoji}
                                        </button>
                                      );
                                    })}
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                          {isUser && <User className="text-brand-accent mt-1.5 shrink-0" />}
                        </motion.div>
                      </div>
                    );
                  })}
                  
                  {loading && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }} 
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.25 }}
                      className="flex gap-3.5 select-none"
                    >
                      <div className="relative shrink-0 mt-1.5">
                        <div className="absolute inset-0 bg-brand-accent/30 rounded-full blur-xs animate-ping" />
                        <Bot className="text-brand-accent relative z-10 w-6 h-6 animate-pulse" />
                      </div>
                      
                      <div className="p-4 rounded-xl max-w-xl bg-[#2D2D2D]/40 border border-brand-accent/30 text-brand-primary shadow-xs flex flex-col gap-2.5">
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] font-bold tracking-wide uppercase text-brand-accent/90 animate-pulse">
                            {activeSession.mode === 'history' 
                              ? 'Bharat ka Itihaas explore kiya ja raha hai... 📜' 
                              : activeSession.mode === 'genz' 
                              ? "Bruh, wait kijiye... vibe-check ho raha hai! 💅✨" 
                              : 'Nexora AI soch raha hai... ⚡️'}
                          </span>
                        </div>
                        
                        <div className="flex items-center gap-1.5 py-1 px-1">
                          <motion.div 
                            className="w-2 h-2 rounded-full bg-brand-accent" 
                            animate={{ y: [0, -6, 0] }} 
                            transition={{ repeat: Infinity, duration: 0.8, ease: "easeInOut", delay: 0 }} 
                          />
                          <motion.div 
                            className="w-2 h-2 rounded-full bg-brand-accent/80" 
                            animate={{ y: [0, -6, 0] }} 
                            transition={{ repeat: Infinity, duration: 0.8, ease: "easeInOut", delay: 0.15 }} 
                          />
                          <motion.div 
                            className="w-2 h-2 rounded-full bg-brand-accent/60" 
                            animate={{ y: [0, -6, 0] }} 
                            transition={{ repeat: Infinity, duration: 0.8, ease: "easeInOut", delay: 0.3 }} 
                          />
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}

            <div ref={messagesEndRef} />
          </main>
        </div>

        {/* Right Empathy Insights Sliding Sidebar Panel */}
        <AnimatePresence>
          {showEmpathyInsights && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: isMobile ? '100%' : '340px', opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ type: "spring", damping: 26, stiffness: 220 }}
              onAnimationComplete={() => setPanelAnimationDone(true)}
              className="h-full border-l border-brand-border bg-brand-sidebar flex flex-col shrink-0 overflow-hidden relative z-30"
              id="empathy-insights-panel"
            >
              {/* Sidebar Header */}
              <div className="p-4 border-b border-brand-border flex items-center justify-between bg-brand-sidebar select-none">
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400">
                    <Activity className="w-4 h-4 animate-pulse text-rose-500" />
                  </div>
                  <div>
                    <h2 className="font-extrabold text-[13px] text-brand-primary tracking-tight">Nexora Senses</h2>
                    <p className="text-[9px] text-brand-secondary font-mono tracking-wider uppercase font-semibold">Active Empathy Tracker</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowEmpathyInsights(false)}
                  className="p-1.5 rounded-xl border border-brand-border text-brand-secondary hover:text-brand-primary hover:bg-brand-bg transition cursor-pointer text-xs font-bold leading-none"
                >
                  ✕
                </button>
              </div>

              {/* Scrollable Panel Area */}
              <div className="flex-1 overflow-y-auto p-4 space-y-5">
                {(() => {
                  const report = getEmpathyReport();
                  
                  // Calculate last 5 messages trajectory for line chart
                  const trajectoryData = messages
                    .filter(m => m.sender === 'ai' && m.emotionAnalysis)
                    .slice(-5)
                    .map((m, idx) => {
                      const analysis = m.emotionAnalysis!;
                      const score = analysis.score || 0.5;
                      let numericValue = 0;
                      
                      switch (analysis.emotion) {
                        case 'love': numericValue = 3 * score; break;
                        case 'excited': numericValue = 2 * score; break;
                        case 'happy': numericValue = 1 * score; break;
                        case 'neutral': numericValue = 0; break;
                        case 'stressed': numericValue = -1 * score; break;
                        case 'sad': numericValue = -2 * score; break;
                        case 'angry': numericValue = -3 * score; break;
                        default: numericValue = 0;
                      }

                      return {
                        name: `${idx + 1}`,
                        val: parseFloat(numericValue.toFixed(2)),
                        emoji: analysis.emoji || '😐',
                        label: analysis.label || 'Neutral',
                        time: m.timestamp
                      };
                    });

                  if (!report.hasData) {
                    return (
                      <div className="p-5 border border-brand-border/60 bg-brand-bg/40 rounded-2xl text-center space-y-4" id="empathy-empty-state">
                        <Heart className="w-8 h-8 text-rose-500/30 mx-auto stroke-1 animate-pulse" />
                        <div className="space-y-1.5">
                          <h4 className="font-bold text-xs text-brand-primary">Empathy Engine Idle</h4>
                          <p className="text-[11px] text-brand-secondary leading-relaxed px-1">
                            {report.tip}
                          </p>
                        </div>
                      </div>
                    );
                  }

                  return (
                    <>
                      {/* Dominant Sensed Emotion State */}
                      <div className="space-y-2" id="empathy-sentiment-metrics">
                        <span className="text-[9px] text-brand-secondary font-bold uppercase tracking-wider font-mono">Present State</span>
                        <div className="p-4 rounded-2xl bg-gradient-to-br from-rose-950/15 via-[#1a1a1a]/45 to-[#2d2d2d]/10 border border-rose-500/20 space-y-3 shadow-lg shadow-black/20">
                          <div className="flex items-center gap-3">
                            <span className="text-3xl animate-bounce" style={{ animationDuration: '2.5s' }}>{report.dominantEmoji}</span>
                            <div>
                              <span className="text-[9px] uppercase font-bold text-rose-400 tracking-wider block font-mono">Dominance Ratio</span>
                              <span className="text-[14px] font-extrabold text-brand-primary tracking-tight block capitalize">{report.dominantLabel} Vibes</span>
                            </div>
                          </div>

                          {/* Matching Bar */}
                          <div className="space-y-1">
                            <div className="flex justify-between text-[10px] font-bold text-brand-secondary font-mono">
                              <span>Match accuracy</span>
                              <span className="text-rose-400">92% Sensed</span>
                            </div>
                            <div className="h-1.5 w-full bg-brand-bg rounded-lg overflow-hidden border border-brand-border/40">
                              <motion.div 
                                initial={{ width: 0 }}
                                animate={{ width: "92%" }}
                                className="h-full bg-rose-500 rounded-full"
                                transition={{ duration: 0.8 }}
                              />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Emotional Trajectory Line Chart */}
                      <div className="space-y-2" id="empathy-chart-section">
                        <span className="text-[9px] text-brand-secondary font-bold uppercase tracking-wider font-mono">Mood Trajectory (last 5)</span>
                        <div className="p-3.5 rounded-2xl bg-[#1e1e1e]/60 border border-brand-border/60">
                          <div className="w-full aspect-[16/10] min-h-[135px] max-h-[175px] h-auto">
                            <ResponsiveContainer 
                              key={`empathy-chart-${sidebarOpen}-${showEmpathyInsights}-${panelAnimationDone}-${windowWidth}`}
                              width="100%" 
                              height="100%"
                            >
                              <LineChart data={trajectoryData} margin={{ top: 8, right: 10, left: -28, bottom: -4 }}>
                                <XAxis 
                                  dataKey="name" 
                                  stroke="#888888" 
                                  fontSize={9} 
                                  tickLine={false} 
                                  axisLine={false} 
                                />
                                <YAxis 
                                  domain={[-3.5, 3.5]} 
                                  stroke="#888888" 
                                  fontSize={9} 
                                  tickLine={false} 
                                  axisLine={false}
                                  ticks={[-3, -1.5, 0, 1.5, 3]}
                                />
                                <Tooltip content={<CustomTooltip />} cursor={{ stroke: '#333333', strokeWidth: 1 }} />
                                <ReferenceLine y={0} stroke="#333333" strokeDasharray="3 3" />
                                <Line 
                                  type="monotone" 
                                  dataKey="val" 
                                  stroke="#f43f5e" 
                                  strokeWidth={2.5} 
                                  dot={{ r: 4, strokeWidth: 1.5, fill: "#f43f5e", stroke: "#121212" }}
                                  activeDot={{ r: 6, strokeWidth: 1 }} 
                                />
                              </LineChart>
                            </ResponsiveContainer>
                          </div>
                          {/* Legend / Info */}
                          <div className="flex justify-between items-center mt-2 px-1 text-[8px] font-mono text-brand-secondary/80">
                            <span className="text-rose-400">🔥 Positive Vibes (+3)</span>
                            <span>Neutral (0)</span>
                            <span className="text-sky-400">😢 Low Vibes (-3)</span>
                          </div>
                        </div>
                      </div>

                      {/* Emotion Shift Trace logs */}
                      <div className="space-y-2" id="empathy-shift-logs">
                        <span className="text-[9px] text-brand-secondary font-bold uppercase tracking-wider font-mono">State Shift Log</span>
                        <div className="p-1 rounded-2xl bg-[#1e1e1e]/40 border border-brand-border/60 divide-y divide-brand-border/40 max-h-44 overflow-y-auto">
                          {messages.filter(m => m.sender === 'ai' && m.emotionAnalysis && m.emotionAnalysis.emotion !== 'neutral').slice(-4).map((m, idx) => (
                            <div key={m.id} className="p-3 space-y-1 text-xs">
                              <div className="flex justify-between items-center">
                                <span className="font-extrabold text-brand-primary flex items-center gap-1.5 text-[11px]">
                                  <span className="text-sm">{m.emotionAnalysis?.emoji}</span>
                                  {m.emotionAnalysis?.label} State
                                </span>
                                <span className="text-[8px] font-mono text-brand-secondary">{m.timestamp}</span>
                              </div>
                              <p className="text-[10px] leading-relaxed text-brand-secondary font-medium">
                                Nexora changed behavior to support you: <span className="text-brand-accent italic font-semibold">"{m.emotionAnalysis?.description.split(".")[1]?.trim() || m.emotionAnalysis?.description}"</span>
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Interactive Advice Card */}
                      <div className="space-y-2" id="empathy-advice-card">
                        <span className="text-[9px] text-brand-secondary font-bold uppercase tracking-wider font-mono">Caring Guidance</span>
                        <div className="p-4 rounded-2xl bg-brand-bg/40 border border-brand-border/85 text-xs text-brand-secondary leading-relaxed relative overflow-hidden group">
                          <div className="absolute top-0 right-0 h-10 w-10 bg-rose-500/5 rounded-bl-full pointer-events-none" />
                          <div className="flex gap-2">
                            <Smile className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                            <p className="text-brand-primary/90 leading-relaxed font-semibold">
                              {report.tip}
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* EQ Statistics */}
                      <div className="space-y-2" id="empathy-eq-metrics">
                        <span className="text-[9px] text-brand-secondary font-bold uppercase tracking-wider font-mono">Dosti quotients (EQ)</span>
                        <div className="grid grid-cols-2 gap-2">
                          <div className="p-3 bg-brand-bg/30 border border-brand-border/60 rounded-xl text-center">
                            <span className="text-[8px] font-mono text-brand-secondary block uppercase tracking-wider">Compassion</span>
                            <span className="text-[11px] font-extrabold text-rose-400">100% Locked</span>
                          </div>
                          <div className="p-3 bg-brand-bg/30 border border-brand-border/60 rounded-xl text-center">
                            <span className="text-[8px] font-mono text-brand-secondary block uppercase tracking-wider">Relationship</span>
                            <span className="text-[11px] font-extrabold text-brand-accent">Haq Se Bhai</span>
                          </div>
                        </div>
                      </div>
                    </>
                  );
                })()}
              </div>

              {/* Sidebar Footer */}
              <div className="p-3 border-t border-brand-border bg-brand-sidebar text-center text-[9px] text-brand-secondary/80 font-mono select-none">
                Made with ❤️ by Raja Choudhary & Co. • Nexora AI India AI
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Speech Error Banner alert */}
      {speechError && (
        <div className="mx-6 my-2 p-3 bg-red-950/85 border border-red-800 text-red-200 text-xs rounded-xl flex justify-between items-center animate-fade-in gap-2 self-center max-w-xl w-[calc(100%-3rem)] shrink-0">
          <span>{speechError}</span>
          <button onClick={() => setSpeechError(null)} className="text-red-400 hover:text-red-200 font-bold cursor-pointer">✕</button>
        </div>
      )}

      {/* BOTTOM FOOTER: Message Input Box + Send extends full width beneath both Sidebar and Chat Panel */}
      {messages.length > 1 && viewMode === 'chat' && (
        <footer className="relative p-2.5 md:p-3 border-t border-brand-border/40 bg-brand-bg/65 backdrop-blur-md flex flex-col items-center justify-center shrink-0 gap-2 z-10">


          {/* Render our beautifully unified Premium input when messages exist */}
          {renderPremiumInput(false)}

          {/* Dynamic Descriptive Tooltip */}
          <AnimatePresence>
            {hoveredPrompt && (
              <motion.div
                initial={{ opacity: 0, y: 6, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 6, scale: 0.95 }}
                transition={{ duration: 0.12 }}
                style={{
                  left: `${hoveredPrompt.x}px`,
                  top: `${hoveredPrompt.y - 12}px`,
                }}
                className="absolute pointer-events-none -translate-x-1/2 -translate-y-full z-50 bg-[#161a23] border border-brand-border/95 px-3 py-1.5 rounded-lg shadow-[0_12px_24px_-8px_rgba(0,0,0,0.8)] max-w-[210px] text-center backdrop-blur-md"
              >
                <p className="text-[10px] font-semibold text-brand-primary leading-relaxed">
                  {hoveredPrompt.tooltip}
                </p>
                <div className="absolute left-1/2 -bottom-[5px] -translate-x-1/2 w-2 h-2 rotate-45 bg-[#161a23] border-r border-b border-brand-border/95" />
              </motion.div>
            )}
          </AnimatePresence>
        </footer>
      )}
    </div>
  );
}
