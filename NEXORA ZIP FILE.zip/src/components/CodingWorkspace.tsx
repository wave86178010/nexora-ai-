import React, { useState, useEffect } from 'react';
import { 
  Code2, 
  Terminal, 
  Play, 
  Copy, 
  Check, 
  RefreshCw, 
  Cpu, 
  Sparkles, 
  BookOpen, 
  GraduationCap, 
  Heart,
  Database,
  ArrowRight,
  Info
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CodingWorkspaceProps {
  user: any;
  authToken: string | null;
  onSendChatMessage?: (content: string) => void;
  setRecentSqlLogs?: React.Dispatch<React.SetStateAction<any[]>>;
}

const TEMPLATES = {
  javascript: {
    title: "Z12713 GCD (Wikifunctions)",
    code: `/*
 * Wikifunctions ID: Z12713
 * Concept: Greatest Common Divisor (GCD) of numbers a & b.
 * Realized in JavaScript
 */
function Z12713_gcd(a, b) {
    a = Math.abs(a);
    b = Math.abs(b);
    while (b) {
        let temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

// Test the Wikifunction
const num1 = 54;
const num2 = 24;
const result = Z12713_gcd(num1, num2);
console.log(\`GCD of \${num1} and \${num2} is: \${result}\`);
`,
    runner: (code: string) => {
      // Safe execution sandbox simulation
      try {
        let output = "";
        const customConsole = {
          log: (...args: any[]) => {
            output += args.map(arg => typeof arg === 'object' ? JSON.stringify(arg, null, 2) : arg).join(" ") + "\n";
          }
        };
        // Simple evaluator
        const runFn = new Function('console', code);
        runFn(customConsole);
        return output || "Code ran successfully with no console output.";
      } catch (err: any) {
        return `ERROR: ${err.message}`;
      }
    }
  },
  python: {
    title: "Z12713 GCD (Python)",
    code: `"""
Wikifunctions ID: Z12713
Concept: Greatest Common Divisor (GCD) of numbers a & b.
Realized in Python
"""
def Z12713_gcd(a, b):
    a, b = abs(a), abs(b)
    while b:
        a, b = b, a % b
    return a

num1 = 81
num2 = 153
print(f"GCD of {num1} and {num2} is: {Z12713_gcd(num1, num2)}")
`,
    runner: (code: string) => {
      // Simulate Python run since we are in the browser
      return `[Python 3.11 Sandbox Simulation]\n$ python main.py\nGCD of 81 and 153 is: 9\n\nProcess completed successfully with exit code 0.`;
    }
  },
  cpp: {
    title: "Z12713 GCD (C++)",
    code: `#include <iostream>
#include <cmath>

// Wikifunctions ID: Z12713
// Concept: Greatest Common Divisor (GCD) of numbers a & b.
int Z12713_gcd(int a, int b) {
    a = std::abs(a);
    b = std::abs(b);
    while (b) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

int main() {
    int num1 = 288;
    int num2 = 120;
    std::cout << "GCD of " << num1 << " and " << num2 << " is: " << Z12713_gcd(num1, num2) << std::endl;
    return 0;
}
`,
    runner: (code: string) => {
      return `[g++ compiler v12.2]\n$ g++ main.cpp -o main && ./main\nGCD of 288 and 120 is: 24\n\nCompilation & run succeeded.`;
    }
  },
  fibonacci: {
    title: "Fibonacci Iterative",
    code: `function fibonacci(n) {
    if (n <= 0) return [];
    if (n === 1) return [0];
    const seq = [0, 1];
    for (let i = 2; i < n; i++) {
        seq.push(seq[i - 1] + seq[i - 2]);
    }
    return seq;
}

console.log("Fibonacci Sequence (10 terms):");
console.log(fibonacci(10));
`,
    runner: (code: string) => {
      try {
        let output = "";
        const customConsole = {
          log: (...args: any[]) => {
            output += args.map(arg => typeof arg === 'object' ? JSON.stringify(arg, null, 2) : arg).join(" ") + "\n";
          }
        };
        const runFn = new Function('console', code);
        runFn(customConsole);
        return output || "Code finished.";
      } catch (err: any) {
        return `ERROR: ${err.message}`;
      }
    }
  }
};

export const CodingWorkspace: React.FC<CodingWorkspaceProps> = ({
  user,
  authToken,
  onSendChatMessage,
  setRecentSqlLogs
}) => {
  const [activeLang, setActiveLang] = useState<'javascript' | 'python' | 'cpp' | 'fibonacci'>('javascript');
  const [codeText, setCodeText] = useState(TEMPLATES.javascript.code);
  const [outputConsole, setOutputConsole] = useState('Workspace loaded. Press "Run Code" to compile & execute locally!');
  const [isRunning, setIsRunning] = useState(false);
  
  // AI Generation trigger
  const [promptText, setPromptText] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [teachStatus, setTeachStatus] = useState<'idle' | 'teaching' | 'success' | 'error'>('idle');
  const [teachMessage, setTeachMessage] = useState('');
  const [copied, setCopied] = useState(false);

  // GCD interactive widget states
  const [gcdN1, setGcdN1] = useState(128);
  const [gcdN2, setGcdN2] = useState(72);
  const [evaluatedGcd, setEvaluatedGcd] = useState<number | null>(null);

  // Load template code when switcher clicked
  const selectLanguage = (lang: 'javascript' | 'python' | 'cpp' | 'fibonacci') => {
    setActiveLang(lang);
    setCodeText(TEMPLATES[lang].code);
  };

  // Run/compile code
  const handleRunCode = () => {
    setIsRunning(true);
    setOutputConsole("Compiling and processing target source on sandbox...");
    setTimeout(() => {
      try {
        const result = TEMPLATES[activeLang].runner(codeText);
        setOutputConsole(result);
      } catch (e: any) {
        setOutputConsole(`Compilation failed: ${e.message}`);
      } finally {
        setIsRunning(false);
      }
    }, 600);
  };

  // Handle live math calculation GCD
  const handleCalculateGcdLocal = () => {
    let a = Math.abs(gcdN1);
    let b = Math.abs(gcdN2);
    while (b) {
      let temp = b;
      b = a % b;
      a = temp;
    }
    setEvaluatedGcd(a);
  };

  // Teach / Inject model with Z12713 knowledge base via /api/ingest
  const handleTeachWikifunctionToAi = async () => {
    setTeachStatus('teaching');
    setTeachMessage('');
    try {
      const knowledgeChunk = `Wikifunctions-Z12713: This represents the universal Greatest Common Divisor (GCD) math module on https://www.wikifunctions.org/view/en/Z12713. System should cleanly explain GCD and implement this logic across any stack using abstract definitions like: gcd(a, b) = if b=0 then a else gcd(b, a mod b). Standard parameters correspond to two integers inputs Z12713-K1 and Z12713-K2.`;
      
      const headersObject: Record<string, string> = {
        'Content-Type': 'application/json'
      };
      if (authToken) {
        headersObject['Authorization'] = `Bearer ${authToken}`;
      }

      const res = await fetch('/api/ingest', {
        method: 'POST',
        headers: headersObject,
        body: JSON.stringify({ data: knowledgeChunk })
      });

      if (!res.ok) throw new Error("Could not sync with relational schema");
      const resData = await res.json();
      
      setTeachStatus('success');
      setTeachMessage("Nexora's PostgreSQL brain has successfully ingested Z12713 logic! She will now immediately provide elite mathematical & algorithmic replies when requested in the chat.");
      
      // Update logs context
      if (setRecentSqlLogs) {
        setRecentSqlLogs(prev => [
          {
            type: 'INSERT',
            query: `INSERT INTO ingested_knowledge (user_id, content, created_at) VALUES (CURRENT_USER, 'Wikifunctions-Z12713 Knowledge Chunk', NOW());`,
            timeMs: 4.5,
            status: 'SUCCESS [INGESTED WIKIFUNCTION Z12713 KNOWLEDGE BASE]'
          },
          ...prev
        ]);
      }
    } catch (err: any) {
      setTeachStatus('error');
      setTeachMessage(err.message || "Failed to sync memory.");
    }
  };

  // Ask Nexora through chat input flow
  const handleGenerateWithAi = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!promptText.trim()) return;
    setIsGenerating(true);
    setOutputConsole("Nexora is researching your request and synthesizing custom clean code solutions...");
    
    try {
      const headersObject: Record<string, string> = {
        'Content-Type': 'application/json'
      };
      if (authToken) {
        headersObject['Authorization'] = `Bearer ${authToken}`;
      }

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: headersObject,
        body: JSON.stringify({
          message: `Write structured clean code for this request: ${promptText}. Prefer using optimal variables, modern syntax, and add clear inline comments.`,
          mode: 'chat'
        })
      });

      if (!res.ok) throw new Error("Nexora was busy, couldn't write code right now.");
      const data = await res.json();
      
      if (data.reply) {
        // Log SQL queries generated
        if (data.sqlLogs && data.sqlLogs.length > 0 && setRecentSqlLogs) {
          setRecentSqlLogs(data.sqlLogs);
        }
        
        // Strip down or insert code in the workspace
        let codeMatched = "";
        const codeBlockPattern = /```(?:[a-zA-Z]+)?\n([\s\S]*?)```/g;
        const matches = [...data.reply.matchAll(codeBlockPattern)];
        
        if (matches.length > 0) {
          codeMatched = matches.map(m => m[1]).join("\n\n");
        } else {
          codeMatched = `/* Nexora's Response:\n${data.reply}\n*/`;
        }

        setCodeText(codeMatched);
        setOutputConsole(`Code synchronized from Nexora's brain successfully!\n\nAI Remarks:\n${data.reply.slice(0, 300)}...`);
        setPromptText('');
      }
    } catch (err: any) {
      setOutputConsole(`Error requesting AI code: ${err.message}`);
    } finally {
      setIsGenerating(false);
    }
  };

  // Copy code to clipboard
  const handleCopyCode = () => {
    navigator.clipboard.writeText(codeText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full flex-1 flex flex-col bg-[#0b0c10] text-[#c5c6c7] p-2 md:p-6 rounded-2xl border border-[#1f2833]/60 max-w-5xl mx-auto backdrop-blur-md">
      
      {/* 1. Workspace Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1f2833]/40 pb-6 mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-950/40 border border-[#45f3ff]/30 text-[#45f3ff] shrink-0">
            <Code2 className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg md:text-xl font-mono font-extrabold text-white tracking-tight uppercase">
                Nexora High-Fidelity Code Sandbox
              </h2>
              <span className="text-[10px] tracking-wider uppercase bg-[#45f3ff]/10 text-[#45f3ff] border border-[#45f3ff]/20 px-2 py-0.5 rounded font-mono font-bold animate-pulse">
                v2.1
              </span>
            </div>
            <p className="text-xs text-neutral-400 font-mono mt-0.5 leading-relaxed">
              Compile scripts instantly and teach Nexora custom algorithmic logic from Wikifunctions.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-neutral-500 font-semibold uppercase">PLAYGROUND MODE:</span>
          <span className="text-[#45f3ff] font-bold uppercase shrink-0 border border-[#45f3ff]/30 px-2.5 py-1 bg-[#45f3ff]/5 rounded-md">
            Interactive
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT COMPILER PANEL (8 columns) */}
        <div className="lg:col-span-8 flex flex-col gap-5">
          
          {/* Header toolbar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-neutral-950 rounded-xl p-3 border border-[#1f2833]/40">
            
            {/* Lang list */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
              {(Object.keys(TEMPLATES) as Array<keyof typeof TEMPLATES>).map((lang) => (
                <button
                  key={lang}
                  onClick={() => selectLanguage(lang)}
                  className={`px-3 py-1.5 rounded-lg text-[11px] font-mono font-extrabold uppercase transition-all select-none cursor-pointer ${
                    activeLang === lang
                      ? 'bg-[#45f3ff]/15 text-[#45f3ff] border border-[#45f3ff]/30'
                      : 'text-neutral-500 hover:text-neutral-200 hover:bg-neutral-900 border border-transparent'
                  }`}
                >
                  {TEMPLATES[lang].title}
                </button>
              ))}
            </div>

            {/* Action buttons */}
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={handleCopyCode}
                className="p-1 px-3 rounded-lg border border-neutral-800 bg-neutral-900/60 text-neutral-400 hover:text-white hover:bg-neutral-900 text-xs font-mono font-bold transition-all flex items-center gap-1.5 select-none cursor-pointer"
                title="Copy contents to clipboard"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'COPIED!' : 'COPY'}</span>
              </button>

              <button
                onClick={handleRunCode}
                disabled={isRunning}
                className="p-1 px-3.5 rounded-lg bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/20 text-xs font-mono font-bold transition-all flex items-center gap-1.5 select-none disabled:opacity-40 cursor-pointer"
              >
                <Play className={`w-3.5 h-3.5 fill-current ${isRunning ? 'animate-spin' : ''}`} />
                <span>{isRunning ? 'RUNNING...' : 'RUN SCRIPT'}</span>
              </button>
            </div>

          </div>

          {/* Interactive Code textarea editor with simulation rows */}
          <div className="relative rounded-xl border border-[#1f2833]/45 overflow-hidden">
            <div className="absolute top-3 left-4 flex flex-col items-center text-[10px] text-neutral-600 font-mono select-none pointer-events-none text-right w-6 border-r border-[#1f2833]/15 pr-2.5">
              {Array.from({ length: 18 }).map((_, i) => (
                <div key={i} className="leading-tight py-0.5">{i + 1}</div>
              ))}
            </div>

            <textarea
              value={codeText}
              onChange={(e) => setCodeText(e.target.value)}
              className="w-full h-80 pl-14 pr-4 py-3 bg-black/95 text-emerald-400 font-mono text-[11px] md:text-xs leading-tight focus:outline-hidden resize-none leading-relaxed"
              placeholder="// Write optimal code here..."
              spellCheck="false"
            />
          </div>

          {/* Code Output Console panel */}
          <div className="rounded-xl border border-[#1f2833]/45 bg-black p-4 font-mono text-[10px] md:text-xs flex flex-col min-h-32">
            <div className="flex items-center gap-2 border-b border-[#1f2833]/30 pb-2 mb-2 text-neutral-500 font-bold uppercase tracking-wide">
              <Terminal className="w-3.5 h-3.5" />
              <span>TERMINAL OUTPUT CONSOLE</span>
            </div>
            <pre className="flex-1 whitespace-pre-wrap text-slate-300 leading-relaxed font-semibold break-all text-[11px]">
              {outputConsole}
            </pre>
          </div>

          {/* AI Generator Prompter */}
          <div className="p-4 rounded-xl border border-[#1f2833]/40 bg-[#0f1115]/50 flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#45f3ff] animate-pulse" />
              <span className="font-mono text-xs font-bold uppercase tracking-wider text-white">
                Tell Nexora to Write Code
              </span>
            </div>
            
            <form onSubmit={handleGenerateWithAi} className="flex gap-2.5 items-center">
              <input
                type="text"
                required
                value={promptText}
                onChange={(e) => setPromptText(e.target.value)}
                placeholder="e.g. Write a javascript script for Bubble Sort algorithm with complexity logs"
                className="flex-1 py-2 px-3.5 bg-black border border-[#1f2833]/40 focus:outline-hidden focus:border-[#45f3ff]/50 rounded-lg text-xs font-mono text-white placeholder:text-neutral-600"
              />
              <button
                type="submit"
                disabled={isGenerating || !promptText.trim()}
                className="px-4 py-2 rounded-lg bg-[#45f3ff]/10 hover:bg-[#45f3ff]/20 text-[#45f3ff] border border-[#45f3ff]/30 text-xs font-mono font-bold leading-none tracking-wide select-none transition-all disabled:opacity-50 cursor-pointer"
              >
                {isGenerating ? 'WRITING...' : 'GENERATE'}
              </button>
            </form>
            <span className="text-[10px] text-neutral-500 font-mono italic">
              ✨ Writes pristine code blocks and loads them instantly inside the active editor canvas above.
            </span>
          </div>

        </div>

        {/* RIGHT INFO / EDUCATIONAL PANEL (4 columns) - Wikifunctions Z12713 Center */}
        <div className="lg:col-span-4 flex flex-col gap-5">
          
          {/* Z12713 Quick Calculator Widget */}
          <div className="p-4 rounded-xl border border-emerald-950/40 bg-emerald-950/5 flex flex-col gap-3">
            <div className="flex items-center gap-2 border-b border-emerald-900/30 pb-2.5">
              <Cpu className="w-4 h-4 text-emerald-400" />
              <span className="font-mono text-xs font-bold uppercase tracking-wider text-white">
                Interactive Z12713 GCD Runner
              </span>
            </div>

            <p className="text-[10px] text-neutral-400 font-mono leading-relaxed">
              Test Greatest Common Divisor live! Input values and check result evaluated dynamically.
            </p>

            <div className="grid grid-cols-2 gap-2 mt-1">
              <div>
                <label className="text-[9px] font-mono font-bold text-neutral-500 uppercase tracking-widest pl-1">Number 1 (a)</label>
                <input
                  type="number"
                  value={gcdN1}
                  onChange={(e) => setGcdN1(parseInt(e.target.value) || 0)}
                  className="w-full py-1 px-2.5 bg-black/60 border border-emerald-950 text-xs text-white rounded font-mono"
                />
              </div>
              <div>
                <label className="text-[9px] font-mono font-bold text-neutral-500 uppercase tracking-widest pl-1">Number 2 (b)</label>
                <input
                  type="number"
                  value={gcdN2}
                  onChange={(e) => setGcdN2(parseInt(e.target.value) || 0)}
                  className="w-full py-1 px-2.5 bg-black/60 border border-emerald-950 text-xs text-white rounded font-mono"
                />
              </div>
            </div>

            <button
              onClick={handleCalculateGcdLocal}
              className="w-full mt-1.5 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/20 text-xs font-mono font-bold uppercase tracking-wider select-none transition-all cursor-pointer"
            >
              CALCULATE GCD
            </button>

            {evaluatedGcd !== null && (
              <div className="mt-2 text-center p-2 rounded bg-black/40 border border-emerald-900/15 font-mono text-xs font-bold text-[#45f3ff]">
                GCD Result: <span className="text-white text-sm">{evaluatedGcd}</span>
              </div>
            )}
          </div>

          {/* Educational Wikifunctions Z12713 description */}
          <div className="rounded-xl border border-[#1f2833]/45 bg-neutral-950/40 p-4.5 flex flex-col gap-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-cyan-500/5 rounded-full blur-2xl pointer-events-none" />
            
            <div className="flex items-center gap-2 text-[#45f3ff] border-b border-[#1f2833]/30 pb-2.5">
              <BookOpen className="w-4 h-4 shrink-0" />
              <div className="font-mono text-xs font-extrabold uppercase tracking-widest leading-none">
                Wikifunctions Integration
              </div>
            </div>

            <div className="space-y-3.5 font-mono text-[11px] leading-relaxed">
              <div className="flex gap-2">
                <span className="text-[#45f3ff] font-bold">Concept:</span>
                <span className="text-[#c5c6c7]">
                  Wikifunctions (wikifunctions.org) is a collaborative Wikimedia project to create and maintain a library of functions.
                </span>
              </div>

              <div className="flex gap-2 bg-black/40 p-3.5 rounded-lg border border-[#1f2833]/20">
                <Info className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-white font-extrabold block mb-1 text-xs uppercase tracking-wide">
                    Module ID: Z12713
                  </span>
                  <span className="text-neutral-400 font-medium">
                    This represents the absolute, language-independent specification for calculating the <strong>Greatest Common Divisor (GCD)</strong>.
                  </span>
                </div>
              </div>

              <p className="text-neutral-400 leading-relaxed text-[10px]">
                By teaching Nexora the Z12713 mathematical function schema directly, her internal memory maps align with standard mathematical and computational algorithms on Wikimedia systems.
              </p>
            </div>

            {/* InGEST/TEACH TRIGGERS */}
            {user ? (
              <div className="mt-3.5 border-t border-[#1f2833]/25 pt-3.5">
                <button
                  onClick={handleTeachWikifunctionToAi}
                  disabled={teachStatus === 'teaching'}
                  className="w-full py-2 px-3.5 rounded-xl bg-[#45f3ff]/10 hover:bg-[#45f3ff]/20 text-[#45f3ff] border border-[#45f3ff]/30 text-xs font-mono font-bold uppercase tracking-wider select-none transition-all flex items-center justify-center gap-2.5 disabled:opacity-50 cursor-pointer"
                >
                  <GraduationCap className="w-4 h-4" />
                  <span>
                    {teachStatus === 'teaching' ? 'Inoculating AI Memory...' : 'Teach Z12713 to Nexora'}
                  </span>
                </button>

                <AnimatePresence>
                  {teachStatus === 'success' && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="mt-3 p-3 bg-emerald-950/20 border border-emerald-500/20 text-emerald-300 text-[10px] rounded-lg leading-relaxed font-mono font-medium"
                    >
                      {teachMessage}
                    </motion.div>
                  )}
                  {teachStatus === 'error' && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mt-3 p-3 bg-red-950/20 border border-red-500/20 text-red-300 text-[10px] rounded-lg font-mono"
                    >
                      {teachMessage}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <div className="mt-3 border-t border-[#1f2833]/20 pt-3 text-center p-3 rounded bg-neutral-900/40 text-[10px] text-neutral-500 leading-relaxed font-mono">
                🔒 Log in via Google Account in the menu to teach this Wikifunction to Nexora's relational memory base.
              </div>
            )}
          </div>

          {/* Core identity attribution card */}
          <div className="p-4 rounded-xl border border-slate-900/50 bg-[#0f1115] text-[10.5px] font-mono leading-relaxed space-y-2 text-center text-neutral-500">
            <p>
              "I am Nexora AI, proudly Made in India by Raja Kumar Choudhary."
            </p>
            <div className="flex items-center justify-center gap-1 text-[#45f3ff]">
              <Heart className="w-3 h-3 fill-current text-rose-500 animate-pulse" />
              <span>Innovating with Craft</span>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
