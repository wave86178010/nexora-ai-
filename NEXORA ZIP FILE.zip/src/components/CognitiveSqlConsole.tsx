import React, { useState, useEffect } from 'react';
import { 
  Database, 
  Terminal, 
  Trash2, 
  RefreshCw, 
  ShieldAlert, 
  CheckCircle2, 
  Clock, 
  ChevronRight, 
  Cpu, 
  Key,
  Flame,
  Search,
  BookOpen
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface MemoryItem {
  id: number;
  userId: number;
  content: string;
  createdAt: string;
}

interface SqlLog {
  type: 'SELECT' | 'INSERT' | 'UPDATE' | 'DELETE';
  query: string;
  timeMs: number;
  status: string;
  rows?: number;
  contextInjected?: string;
}

interface CognitiveSqlConsoleProps {
  user: any;
  authToken: string | null;
  recentLogs: SqlLog[];
  onClearLogs?: () => void;
}

export const CognitiveSqlConsole: React.FC<CognitiveSqlConsoleProps> = ({
  user,
  authToken,
  recentLogs,
  onClearLogs
}) => {
  const [memories, setMemories] = useState<MemoryItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Custom manual INSERT statement composer
  const [manualText, setManualText] = useState('');
  const [insertingManual, setInsertingManual] = useState(false);
  const [searchFilter, setSearchFilter] = useState('');

  // Terminal simulated feed
  const [historyLogs, setHistoryLogs] = useState<SqlLog[]>([
    {
      type: 'SELECT',
      query: 'SELECT current_database();',
      timeMs: 0.12,
      status: 'ai-studio-2545b08f-a0e6-4966-a9dd-f80f0f6f84ee connected successfully.'
    },
    {
      type: 'SELECT',
      query: 'SELECT * FROM pg_tables WHERE schemaname = \'public\';',
      timeMs: 1.1,
      status: 'Loaded tables: users, sessions, messages, ingested_knowledge.'
    }
  ]);

  useEffect(() => {
    if (recentLogs && recentLogs.length > 0) {
      setHistoryLogs(prev => [...recentLogs, ...prev].slice(0, 30));
    }
  }, [recentLogs]);

  // Fetch memories on load
  const loadMemories = async () => {
    if (!user) {
      setError("Aapka profile check nahi kiya gaya h. Please log in first to sync and organize threads securely!");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const headersObject: Record<string, string> = {
        'Content-Type': 'application/json'
      };
      if (authToken) {
        headersObject['Authorization'] = `Bearer ${authToken}`;
      }
      
      const res = await fetch('/api/ingest', { headers: headersObject });
      if (!res.ok) throw new Error("Could not retrieve memory relational data.");
      const data = await res.json();
      if (data.memories) {
        setMemories(data.memories);
      }
    } catch (err: any) {
      setError(err.message || "Failed to load cognitive records.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      loadMemories();
    }
  }, [user, authToken]);

  // Handle manual insert
  const handleInsertMemory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualText.trim()) return;
    setInsertingManual(true);
    
    try {
      const headersObject: Record<string, string> = {
        'Content-Type': 'application/json'
      };
      if (authToken) {
        headersObject['Authorization'] = `Bearer ${authToken}`;
      }

      // Add to terminal live feed
      const simulatedQuery = `INSERT INTO ingested_knowledge (user_id, content, created_at) VALUES (${user ? 'CURRENT_USER' : 'ANON'}, '${manualText.replace(/'/g, "''")}', NOW());`;
      
      const res = await fetch('/api/ingest', {
        method: 'POST',
        headers: headersObject,
        body: JSON.stringify({ data: manualText.trim() })
      });

      if (!res.ok) throw new Error("SQL Insert rejected.");
      
      setHistoryLogs(prev => [
        {
          type: 'INSERT',
          query: simulatedQuery,
          timeMs: 4.8,
          status: 'SUCCESS [LEARNED VIA RELATIONAL CONSOLE]'
        },
        ...prev
      ]);

      setManualText('');
      loadMemories();
    } catch (err: any) {
      setError(err.message || "Manual ingestion failed.");
    } finally {
      setInsertingManual(false);
    }
  };

  // Delete a specific row
  const handleDeleteRow = async (id: number) => {
    try {
      const headersObject: Record<string, string> = {
        'Content-Type': 'application/json'
      };
      if (authToken) {
        headersObject['Authorization'] = `Bearer ${authToken}`;
      }

      const res = await fetch(`/api/ingest/${id}`, {
        method: 'DELETE',
        headers: headersObject
      });

      if (!res.ok) throw new Error("SQL Row Deletion failed.");
      
      setHistoryLogs(prev => [
        {
          type: 'DELETE',
          query: `DELETE FROM ingested_knowledge WHERE id = ${id};`,
          timeMs: 3.2,
          status: 'ROW DELETED SUCCESSFULLY'
        },
        ...prev
      ]);

      loadMemories();
    } catch (err: any) {
      setError(err.message || "Failed to clear recollection row.");
    }
  };

  const filteredMemories = memories.filter(m => 
    m.content.toLowerCase().includes(searchFilter.toLowerCase())
  );

  return (
    <div className="w-full flex-1 flex flex-col bg-[#0b0c10] text-[#c5c6c7] p-2 md:p-6 rounded-2xl border border-[#1f2833]/60 max-w-5xl mx-auto backdrop-blur-md">
      {/* Header section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1f2833]/40 pb-6 mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-950/40 border border-[#45f3ff]/30 text-[#45f3ff] animate-pulse">
            <Database className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg md:text-xl font-mono font-extrabold text-white tracking-tight uppercase">
                Nexora PG DB Control Center
              </h2>
              <span className="text-[10px] tracking-wider uppercase bg-[#45f3ff]/10 text-[#45f3ff] border border-[#45f3ff]/20 px-2 py-0.5 rounded font-mono font-bold">
                Online
              </span>
            </div>
            <p className="text-xs text-neutral-400 font-mono mt-0.5 leading-relaxed">
              Cognitive relational tracking of user traits & past memory recall states.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadMemories}
            disabled={loading}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-[#1f2833] bg-neutral-900/40 text-neutral-300 hover:text-white hover:bg-neutral-900 text-xs font-mono font-bold transition-all disabled:opacity-50 cursor-pointer select-none"
            title="Reload SQL rows"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-cyan-400' : ''}`} />
            <span>SYNC TABLE</span>
          </button>
          
          {onClearLogs && (
            <button
              onClick={() => {
                onClearLogs();
                setHistoryLogs([
                  {
                    type: 'SELECT',
                    query: 'TRUNCATE sql_logs_cache;',
                    timeMs: 0.1,
                    status: 'Logs Cache Truncated successfully.'
                  }
                ]);
              }}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-red-950/40 bg-red-950/10 hover:bg-red-950/30 text-rose-300 text-xs font-mono font-bold transition-all cursor-pointer select-none"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>CLEAR LOGS</span>
            </button>
          )}
        </div>
      </div>

      {user ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* LEFT PANEL: PG RELATIONAL SCHEMA & DATA STREAM (8 cols) */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            
            {/* Table layout visualization represent public.ingested_knowledge */}
            <div className="rounded-xl border border-[#1f2833]/40 bg-neutral-950/40 p-4 relative overflow-hidden">
              <div className="p-3 bg-neutral-950 border-b border-[#1f2833]/30 flex flex-col md:flex-row md:items-center justify-between gap-3 rounded-t-lg -mx-4 -mt-4 mb-4">
                <div className="flex items-center gap-2 text-[#45f3ff]">
                  <Cpu className="w-4 h-4" />
                  <span className="font-mono text-xs font-bold leading-none uppercase tracking-wider">
                    Table: ingested_knowledge
                  </span>
                </div>
                
                {/* Micro search */}
                <div className="relative">
                  <Search className="absolute left-2.5 top-1.5 h-3.5 w-3.5 text-neutral-500" />
                  <input
                    type="text"
                    placeholder="Search memory records..."
                    value={searchFilter}
                    onChange={(e) => setSearchFilter(e.target.value)}
                    className="pl-8 pr-3 py-1 bg-black/60 border border-[#1f2833]/30 focus:outline-hidden focus:border-[#45f3ff]/40 text-xs rounded-lg text-white font-mono placeholder:text-neutral-600"
                  />
                </div>
              </div>

              {loading && memories.length === 0 ? (
                <div className="py-12 flex flex-col items-center justify-center gap-3">
                  <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin" />
                  <span className="font-mono text-xs text-neutral-500 animate-pulse">Running SELECT query...</span>
                </div>
              ) : filteredMemories.length === 0 ? (
                <div className="py-12 border border-dashed border-[#1f2833]/30 rounded-xl text-center flex flex-col items-center justify-center p-6 bg-black/20">
                  <ShieldAlert className="w-8 h-8 text-neutral-600 mb-2" />
                  <p className="font-mono text-xs font-bold text-neutral-300">
                    {searchFilter ? 'No matching database records found.' : 'No memory records ingested yet!'}
                  </p>
                  <p className="text-[10px] text-neutral-500 font-mono mt-1 max-w-sm mx-auto leading-relaxed">
                    {searchFilter 
                      ? 'Try expanding your keywords.' 
                      : 'Nexora automatically records your preferences during chats (e.g. telling her your favorite songs, location, hobbies). Share details in the chat and watch this table grow!'}
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full font-mono text-left text-xs min-w-[500px]">
                    <thead>
                      <tr className="border-b border-[#1f2833]/30 text-neutral-500 uppercase tracking-widest text-[9px] font-bold">
                        <th className="py-2.5 px-3">id (PK)</th>
                        <th className="py-2.5 px-3">user_id (FK)</th>
                        <th className="py-2.5 px-3">content</th>
                        <th className="py-2.5 px-3">created_at</th>
                        <th className="py-2.5 px-3 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#1f2833]/20">
                      <AnimatePresence>
                        {filteredMemories.map((m) => (
                          <motion.tr 
                            key={m.id}
                            initial={{ opacity: 0, scale: 0.98 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, x: -10 }}
                            className="hover:bg-[#1a1c23]/35 transition-colors"
                          >
                            <td className="py-3 px-3 text-cyan-400 font-bold">{m.id}</td>
                            <td className="py-3 px-3 text-neutral-400 font-medium">{m.userId}</td>
                            <td className="py-3 px-3 text-white max-w-[220px] truncate leading-relaxed" title={m.content}>
                              {m.content}
                            </td>
                            <td className="py-3 px-3 text-neutral-500 text-[10px]">
                              {new Date(m.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                            </td>
                            <td className="py-3 px-3 text-right">
                              <button
                                onClick={() => handleDeleteRow(m.id)}
                                className="p-1 px-2 rounded bg-rose-500/10 border border-rose-500/20 text-rose-300 hover:bg-rose-500 hover:text-white transition-all text-[9px] font-bold cursor-pointer"
                                title="Run DELETE FROM query"
                              >
                                DELETE ROW
                              </button>
                            </td>
                          </motion.tr>
                        ))}
                      </AnimatePresence>
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Manual insertion compose console */}
            <div className="p-4 rounded-xl border border-[#1f2833]/40 bg-[#0f1115]/50 flex flex-col gap-3">
              <div className="flex items-center gap-2 border-b border-[#1f2833]/30 pb-2.5">
                <Terminal className="w-4 h-4 text-cyan-400" />
                <span className="font-mono text-xs font-bold uppercase tracking-wider text-white">
                  Add Relational Memory Manually
                </span>
              </div>
              
              <form onSubmit={handleInsertMemory} className="flex gap-2.5 items-center">
                <input
                  type="text"
                  required
                  value={manualText}
                  onChange={(e) => setManualText(e.target.value)}
                  placeholder="e.g. Loves listening to A.R. Rahman music late at night"
                  className="flex-1 py-1.5 px-3.5 bg-black border border-[#1f2833]/40 focus:outline-hidden focus:border-[#45f3ff]/50 rounded-lg text-xs font-mono text-white placeholder:text-neutral-600"
                />
                <button
                  type="submit"
                  disabled={insertingManual || !manualText.trim()}
                  className="px-4 py-1.5 rounded-lg bg-[#45f3ff]/10 hover:bg-[#45f3ff]/20 text-[#45f3ff] border border-[#45f3ff]/30 text-xs font-mono font-bold leading-none tracking-wide select-none transition-all disabled:opacity-50 select-none cursor-pointer"
                >
                  {insertingManual ? 'INSERTING...' : 'RUN INSERT'}
                </button>
              </form>
              <span className="text-[10px] text-neutral-500 font-mono italic">
                💡 Custom SQL Insert inputs are synced with active model contexts, updating future chat generations instantly.
              </span>
            </div>

          </div>

          {/* RIGHT PANEL: TERMINAL COMPOSE LOG FEED (5 cols) */}
          <div className="lg:col-span-12 xl:col-span-5 flex flex-col gap-4">
            <div className="rounded-xl border border-[#1f2833]/55 bg-black/98 p-4 font-mono text-[10px] flex flex-col flex-1 h-[450px]">
              <div className="flex items-center justify-between border-b border-[#1f2833]/40 pb-3 mb-3 bg-black">
                <div className="flex items-center gap-2 text-cyan-400">
                  <Terminal className="w-3.5 h-3.5" />
                  <span className="font-bold uppercase tracking-wide">POSTGRESQL LOG STREAM</span>
                </div>
                
                <span className="text-[9px] uppercase tracking-wider text-neutral-500 animate-pulse">
                  ● Real-Time
                </span>
              </div>

              {/* Logs Stream body */}
              <div className="flex-1 overflow-y-auto space-y-4 pr-1 text-xs select-text">
                {historyLogs.map((log, i) => (
                  <div key={i} className="border-l-2 border-cyan-500/30 pl-3 py-0.5 space-y-1">
                    <div className="flex items-center justify-between text-[10px]">
                      <span className={`px-1 rounded font-bold uppercase ${
                        log.type === 'SELECT' ? 'bg-sky-500/10 text-sky-300' :
                        log.type === 'INSERT' ? 'bg-emerald-500/10 text-emerald-300' :
                        log.type === 'DELETE' ? 'bg-rose-500/10 text-rose-300' :
                        'bg-amber-500/10 text-amber-300'
                      }`}>
                        {log.type}
                      </span>
                      <span className="text-neutral-500 text-[9px]">{log.timeMs}ms</span>
                    </div>
                    
                    <p className="text-[#a0aec0] font-mono break-all font-bold tracking-tight text-[11px] leading-relaxed">
                      {log.query}
                    </p>
                    
                    <div className="flex items-start gap-1 pb-1">
                      <ChevronRight className="w-3 h-3 text-cyan-400 shrink-0 mt-0.5" />
                      <p className="text-[#c5c6c7] text-[10px] font-mono opacity-80 leading-relaxed break-words">
                        {log.status}
                      </p>
                    </div>

                    {log.contextInjected && (
                      <div className="bg-[#1f2833]/12 border border-[#1f2833]/30 rounded-md p-2 my-1 text-[9px] text-[#45f3ff]">
                        <div className="font-bold flex items-center gap-1.5 mb-1 text-neutral-400 font-mono text-[8px] uppercase tracking-wider">
                          <BookOpen className="w-2.5 h-2.5" /> Injected System Context Rows
                        </div>
                        <p className="italic leading-relaxed">{log.contextInjected}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <div className="border-t border-[#1f2833]/30 pt-3 mt-3 flex items-center justify-between bg-black">
                <span className="text-[10px] text-neutral-600 font-bold tracking-wide">
                  DATABASE HOST: 127.0.0.1 (LOCAL_PG_SOCKET)
                </span>
                <span className="text-[10px] text-[#45f3ff] animate-pulse">
                  SYSTEM READY
                </span>
              </div>
            </div>
          </div>

        </div>
      ) : (
        <div className="py-16 text-center border border-[#1f2833]/30 rounded-2xl bg-neutral-950/20 max-w-xl mx-auto flex flex-col items-center justify-center p-6">
          <Key className="w-12 h-12 text-[#45f3ff] mb-4 animate-bounce" />
          <h3 className="font-mono text-base font-extrabold text-white uppercase tracking-tight">
            Database Security Validation Failed
          </h3>
          <p className="text-xs text-neutral-400 font-mono leading-relaxed mt-2 p-2">
            Please login with your Google Account using the button in the sidebar or menu to connect to your personal relational PG schema.
          </p>
          
          <p className="text-[10px] text-neutral-500 italic font-mono mt-6 leading-relaxed max-w-md">
            🔒 Authenticated Firestore profiles automatically configure individual secure PostgreSQL schemas. anonymous tables are restricted to prevent crosstalk.
          </p>
        </div>
      )}
    </div>
  );
};
