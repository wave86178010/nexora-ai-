import React, { useState, useEffect, useRef } from 'react';
import { 
  Upload, 
  FileText, 
  CheckCircle2, 
  Trash2, 
  Search, 
  HelpCircle, 
  HardDrive, 
  Sparkles, 
  BookOpen, 
  Clock, 
  AlertTriangle, 
  Play, 
  Sliders,
  Maximize2,
  FileCode,
  FileSpreadsheet,
  Layers,
  Database
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface RagChunk {
  id: number;
  docTitle: string;
  chunkIndex: number;
  totalChunks: number;
  content: string;
  originalId: number;
  createdAt: string;
}

interface IngestedItem {
  id: number;
  userId: number;
  content: string;
  createdAt: string;
}

interface GeminiRagDashboardProps {
  user: any;
  authToken: string | null;
  onAddedLogs: (log: any) => void;
}

export const GeminiRagDashboard: React.FC<GeminiRagDashboardProps> = ({
  user,
  authToken,
  onAddedLogs
}) => {
  const [ingestedItems, setIngestedItems] = useState<IngestedItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Paste text parameters
  const [pastedTitle, setPastedTitle] = useState('');
  const [pastedContent, setPastedContent] = useState('');
  
  // File upload state
  const [dragActive, setDragActive] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileContentPreview, setFileContentPreview] = useState<string>('');
  
  // Chunking parameters
  const [chunkSize, setChunkSize] = useState(500); // characters
  const [chunkOverlap, setChunkOverlap] = useState(100); // characters
  
  // Playground state
  const [playgroundQuery, setPlaygroundQuery] = useState('');
  const [searchResults, setSearchResults] = useState<{ chunk: RagChunk; score: number }[]>([]);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load knowledge base
  const fetchKnowledgeBase = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const headersObject: Record<string, string> = {
        'Content-Type': 'application/json'
      };
      if (authToken) {
        headersObject['Authorization'] = `Bearer ${authToken}`;
      }
      const res = await fetch('/api/ingest', { headers: headersObject });
      if (!res.ok) throw new Error("Failed to load documents.");
      const data = await res.json();
      if (data.memories) {
        setIngestedItems(data.memories);
      }
    } catch (err: any) {
      setError(err.message || "Failed to load database.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchKnowledgeBase();
  }, [user, authToken]);

  // Read file data
  const handleFileChange = (file: File) => {
    setSelectedFile(file);
    if (!pastedTitle) {
      // Auto fill title with file name
      setPastedTitle(file.name);
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      setFileContentPreview(text);
    };
    reader.readAsText(file);
  };

  // Drag over handlers
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileChange(e.dataTransfer.files[0]);
    }
  };

  // Break text into logical chunks with overlaps
  const performChunking = (text: string, size: number, overlap: number): string[] => {
    const chunks: string[] = [];
    if (!text) return chunks;
    
    let index = 0;
    while (index < text.length) {
      const chunk = text.substring(index, index + size);
      chunks.push(chunk);
      index += (size - overlap);
      
      // Safety condition to avoid infinite loops
      if (size <= overlap) {
        index += size;
      }
    }
    return chunks;
  };

  // Raw ingested items parsed into formatted RagChunks
  const getRagChunks = (): RagChunk[] => {
    const ragChunks: RagChunk[] = [];
    ingestedItems.forEach(item => {
      // Format: [DOC: filename | Part X of Y] Content
      const docMatch = item.content.match(/^\[DOC:\s*(.*?)\s*\|\s*Part\s+(\d+)\s+of\s+(\d+)\]\s*([\s\S]*)$/);
      if (docMatch) {
        ragChunks.push({
          id: item.id,
          docTitle: docMatch[1],
          chunkIndex: parseInt(docMatch[2], 10),
          totalChunks: parseInt(docMatch[3], 10),
          content: docMatch[4],
          originalId: item.id,
          createdAt: item.createdAt
        });
      } else {
        // Fallback for non-documented manual inputs
        ragChunks.push({
          id: item.id,
          docTitle: "Personal/Manual Intel",
          chunkIndex: 1,
          totalChunks: 1,
          content: item.content,
          originalId: item.id,
          createdAt: item.createdAt
        });
      }
    });
    return ragChunks;
  };

  // Group chunks by doc title to show Document lists
  const groupedDocsList = () => {
    const chunks = getRagChunks();
    const map: Record<string, { title: string; chunkCount: number; lastUpdated: string; chunks: RagChunk[] }> = {};
    
    chunks.forEach(c => {
      if (!map[c.docTitle]) {
        map[c.docTitle] = {
          title: c.docTitle,
          chunkCount: 0,
          lastUpdated: c.createdAt,
          chunks: []
        };
      }
      map[c.docTitle].chunkCount += 1;
      map[c.docTitle].chunks.push(c);
    });
    
    return Object.values(map);
  };

  // Ingest Document Handler
  const handleIngestDocument = async () => {
    const contentToIngest = fileContentPreview || pastedContent;
    const titleToUse = pastedTitle || "Uploaded_Doc_" + Date.now();
    
    if (!contentToIngest.trim()) {
      setError("Document/pasted context khali nahi ho sakta yaara!");
      return;
    }

    setUploadProgress(10);
    setError(null);
    
    const chunks = performChunking(contentToIngest, chunkSize, chunkOverlap);
    const total = chunks.length;
    
    try {
      const headersObject: Record<string, string> = {
        'Content-Type': 'application/json'
      };
      if (authToken) {
        headersObject['Authorization'] = `Bearer ${authToken}`;
      }

      onAddedLogs({
        type: "INSERT",
        query: `BEGIN TRANSACTION -- RAG Ingest of "${titleToUse}" for user`,
        timeMs: 0.1,
        status: "PROCESSING [INGESTING DOCUMENT CHUNKS]"
      });

      // Segmented ingestion in loops
      for (let i = 0; i < chunks.length; i++) {
        const chunkText = chunks[i];
        const formattedPayload = `[DOC: ${titleToUse} | Part ${i + 1} of ${total}] ${chunkText}`;
        
        const res = await fetch('/api/ingest', {
          method: 'POST',
          headers: headersObject,
          body: JSON.stringify({ data: formattedPayload })
        });

        if (!res.ok) throw new Error(`Chunk ${i+1} insertion failed!`);
        
        // Progress bar simulation
        setUploadProgress(Math.min(15 + Math.floor((i / chunks.length) * 80), 99));
      }

      setUploadProgress(100);
      
      onAddedLogs({
        type: "INSERT",
        query: `COMMIT TRANSACTION -- Successfully ingested ${total} chunks for user.`,
        timeMs: parseFloat((Math.random() * 8 + 1).toFixed(2)),
        status: "SUCCESS [DOCUMENT PERSISTED IN POSTGRESQL]"
      });

      // Clear inputs
      setPastedTitle('');
      setPastedContent('');
      setFileContentPreview('');
      setSelectedFile(null);
      
      // Refresh list
      await fetchKnowledgeBase();
      
      setTimeout(() => setUploadProgress(null), 2000);
    } catch (err: any) {
      setError(err.message || "Failed to ingest chunks.");
      setUploadProgress(null);
    }
  };

  // Delete all document chunks by document title
  const handleDeleteDocument = async (title: string, chunks: RagChunk[]) => {
    if (!confirm(`Are you sure you want to delete "${title}" file and its ${chunks.length} chunks?`)) return;
    
    setLoading(true);
    try {
      const headersObject: Record<string, string> = {
        'Content-Type': 'application/json'
      };
      if (authToken) {
        headersObject['Authorization'] = `Bearer ${authToken}`;
      }

      onAddedLogs({
        type: "DELETE",
        query: `DELETE FROM ingested_knowledge WHERE content LIKE '[DOC: ${title.replace(/'/g, "''")}%';`,
        timeMs: 1.1,
        status: `REMOVING ${chunks.length} CHUNKS FOR FILE: ${title}...`
      });

      for (const c of chunks) {
        const res = await fetch(`/api/ingest/${c.originalId}`, {
          method: 'DELETE',
          headers: headersObject
        });
        if (!res.ok) throw new Error("Failed to delete chunk index: " + c.originalId);
      }

      onAddedLogs({
        type: "DELETE",
        query: `TRUNCATE -- Completed document deletion of "${title}"`,
        timeMs: 0.9,
        status: `SUCCESS`
      });

      await fetchKnowledgeBase();
    } catch (err: any) {
      setError(err.message || "Failed to clean up files.");
    } finally {
      setLoading(false);
    }
  };

  // Native tf-idf/cosine-approximation matching playground test
  const runSearchTest = () => {
    if (!playgroundQuery.trim()) {
      setSearchResults([]);
      return;
    }
    
    const chunks = getRagChunks();
    const searchTerms = playgroundQuery.toLowerCase().split(/\s+/).filter(t => t.length > 1);
    
    if (searchTerms.length === 0) {
      setSearchResults([]);
      return;
    }

    const matches = chunks.map(chunk => {
      let score = 0;
      const loweredContent = chunk.content.toLowerCase();
      const titleLower = chunk.docTitle.toLowerCase();
      
      searchTerms.forEach(term => {
        // Keyword frequency matching
        const regex = new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
        const count = (loweredContent.match(regex) || []).length;
        
        score += count * 1.5;
        
        // Exact keyword search boost
        if (loweredContent.includes(term)) score += 5;
        // Document name match boost
        if (titleLower.includes(term)) score += 10;
      });
      
      return { chunk, score };
    })
    .filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5); // top 5 results

    setSearchResults(matches);
    
    onAddedLogs({
      type: "SELECT",
      query: `SELECT * FROM ingested_knowledge WHERE MATCH(content) AGAINST('${playgroundQuery.replace(/'/g, "''")}') LIMIT 5;`,
      timeMs: 2.1,
      status: `RETRIEVED ${matches.length} DOCUMENT CHUNKS FOR SIMILARITY SCORE`
    });
  };

  useEffect(() => {
    runSearchTest();
  }, [playgroundQuery, ingestedItems]);

  const docs = groupedDocsList();

  return (
    <div className="w-full flex-1 flex flex-col bg-[#0b0c10] text-[#c5c6c7] p-2 md:p-6 rounded-2xl border border-[#1f2833]/60 max-w-5xl mx-auto backdrop-blur-md">
      
      {/* Header Panel */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#1f2833]/40 pb-6 mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-950/40 border border-[#45f3ff]/30 text-[#45f3ff] animate-pulse">
            <Layers className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg md:text-xl font-mono font-extrabold text-white tracking-tight uppercase">
                Gemini Multi-Doc RAG Console
              </h2>
              <span className="text-[10px] tracking-wider uppercase bg-[#45f3ff]/10 text-[#45f3ff] border border-[#45f3ff]/20 px-2 py-0.5 rounded font-mono font-bold">
                PRO ACTIVE RAG
              </span>
            </div>
            <p className="text-xs text-neutral-400 font-mono mt-0.5 leading-relaxed">
              Upload study books, syllabus context, text-corpus, or manuals to auto-chunk & inject semantic search inside Nexora AI.
            </p>
          </div>
        </div>
        
        <button
          onClick={fetchKnowledgeBase}
          disabled={loading}
          className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-[#1f2833] bg-neutral-900/40 text-neutral-300 hover:text-white hover:bg-neutral-900 text-xs font-mono font-bold transition-all disabled:opacity-50 cursor-pointer select-none"
        >
          <Clock className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-cyan-400' : ''}`} />
          <span>RELOAD RAG STORAGE</span>
        </button>
      </div>

      {error && (
        <div className="mb-6 p-4 rounded-xl bg-red-950/20 border border-red-500/30 text-rose-300 text-xs font-mono flex items-center gap-3">
          <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Grid Layout structure */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT COMPILER: Upload files, past data & parameter adjust (7 columns) */}
        <div className="lg:col-span-7 flex flex-col gap-6">
          
          {/* Document Ingestion Card */}
          <div className="rounded-xl border border-[#1f2833]/40 bg-neutral-950/50 p-5 relative">
            <h3 className="font-mono text-sm font-extrabold text-white mb-4 uppercase flex items-center gap-2">
              <Upload className="w-4 h-4 text-[#45f3ff]" />
              Step 1: Document Upload & Ingestion
            </h3>

            {/* Custom file dropzone */}
            <div 
              onDragEnter={handleDrag}
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all duration-200 flex flex-col items-center justify-center gap-2 ${
                dragActive 
                  ? 'border-[#45f3ff] bg-[#45f3ff]/5 scale-98' 
                  : selectedFile 
                    ? 'border-emerald-500/40 bg-emerald-950/10' 
                    : 'border-[#1f2833] hover:border-cyan-500/40 bg-zinc-950/30'
              }`}
            >
              <input 
                type="file" 
                ref={fileInputRef}
                onChange={(e) => e.target.files?.[0] && handleFileChange(e.target.files[0])}
                className="hidden" 
                accept=".txt,.md,.json,.csv,.js,.py,.cpp,.html"
              />
              {selectedFile ? (
                <>
                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400 mb-1">
                    <FileText className="w-6 h-6 animate-pulse" />
                  </div>
                  <span className="font-mono text-xs font-bold text-white max-w-xs truncate">{selectedFile.name}</span>
                  <span className="font-mono text-[10px] text-emerald-400 font-medium">Selected successfully ({(selectedFile.size / 1024).toFixed(1)} KB)</span>
                </>
              ) : (
                <>
                  <div className="p-3 bg-cyan-950/20 border border-[#1f2833] rounded-xl text-brand-secondary mb-1">
                    <Upload className="w-6 h-6 text-[#45f3ff]" />
                  </div>
                  <span className="font-mono text-xs font-bold text-neutral-300">Drag & Drop or Click to Browse</span>
                  <span className="font-mono text-[10px] text-neutral-500">Supports (.txt, .md, .csv, .json, software code libraries)</span>
                </>
              )}
            </div>

            {/* Separator / Manual Entry */}
            <div className="my-5 flex items-center justify-between text-neutral-600 font-mono text-[10px]">
              <span className="h-px bg-[#1f2833]/40 flex-1"></span>
              <span className="px-3 uppercase font-extrabold tracking-widest text-[#45f3ff]/60">OR PASTE DIRECTLY</span>
              <span className="h-px bg-[#1f2833]/40 flex-1"></span>
            </div>

            {/* Ingestion naming and paste areas */}
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-mono font-extrabold uppercase text-neutral-400 mb-1">Document File Name / Title</label>
                <input
                  type="text"
                  placeholder="e.g. quantum_physics_syllabus.txt"
                  value={pastedTitle}
                  onChange={(e) => setPastedTitle(e.target.value)}
                  className="w-full px-4 py-2 bg-black/60 border border-[#1f2833]/50 focus:outline-hidden focus:border-[#45f3ff]/50 rounded-xl font-mono text-xs text-white placeholder:text-neutral-700"
                />
              </div>

              {!selectedFile && (
                <div>
                  <label className="block text-[10px] font-mono font-extrabold uppercase text-neutral-400 mb-1">Text Corpus Content</label>
                  <textarea
                    rows={4}
                    placeholder="Paste massive text content directly here for chunking..."
                    value={pastedContent}
                    onChange={(e) => setPastedContent(e.target.value)}
                    className="w-full px-4 py-3 bg-black/60 border border-[#1f2833]/50 focus:outline-hidden focus:border-[#45f3ff]/50 rounded-xl font-mono text-xs text-white placeholder:text-neutral-700 resize-none"
                  />
                </div>
              )}
            </div>

            {/* Chunk Strategy sliders */}
            <div className="mt-5 pt-5 border-t border-[#1f2833]/40">
              <h4 className="font-mono text-[11px] font-extrabold text-[#45f3ff] mb-3 uppercase flex items-center gap-1.5 leading-none">
                <Sliders className="w-3.5 h-3.5" />
                Chunking Strategy Settings
              </h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="flex items-center justify-between font-mono text-[10px] mb-1">
                    <span className="text-neutral-400">CHUNK SIZE</span>
                    <span className="text-white font-bold">{chunkSize} chars</span>
                  </div>
                  <input
                    type="range"
                    min="100"
                    max="1500"
                    step="50"
                    value={chunkSize}
                    onChange={(e) => setChunkSize(parseInt(e.target.value))}
                    className="w-full accent-[#45f3ff] bg-neutral-900 h-1.5 rounded-lg appearance-none cursor-pointer"
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between font-mono text-[10px] mb-1">
                    <span className="text-neutral-400">CHUNK OVERLAP</span>
                    <span className="text-white font-bold">{chunkOverlap} chars</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="400"
                    step="20"
                    value={chunkOverlap}
                    onChange={(e) => setChunkOverlap(parseInt(e.target.value))}
                    className="w-full accent-[#45f3ff] bg-neutral-900 h-1.5 rounded-lg appearance-none cursor-pointer"
                  />
                </div>
              </div>
            </div>

            {/* Trigger Button */}
            <div className="mt-6">
              {uploadProgress !== null ? (
                <div className="w-full bg-zinc-900 border border-cyan-500/20 rounded-xl p-3">
                  <div className="flex justify-between font-mono text-xs mb-1.5">
                    <span className="text-cyan-400 font-bold animate-pulse">INGESTING CHUNKS INTO POSTGRESQL BRAIN...</span>
                    <span className="text-white">{uploadProgress}%</span>
                  </div>
                  <div className="w-full h-2 bg-black rounded-lg overflow-hidden border border-[#1f2833]/40">
                    <div 
                      className="bg-cyan-400 h-full transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                </div>
              ) : (
                <button
                  onClick={handleIngestDocument}
                  disabled={selectedFile ? !fileContentPreview : !pastedContent.trim()}
                  className="w-full py-3.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-black font-mono font-bold text-xs uppercase tracking-wider transition-all shadow-lg hover:shadow-cyan-400/10 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer select-none"
                >
                  <Sparkles className="w-4 h-4 text-black animate-pulse" />
                  <span>PROCESS & SAVE CHUNKS TO POSTGRESQL</span>
                </button>
              )}
            </div>
          </div>

          {/* Search Testing playground */}
          <div className="rounded-xl border border-[#1f2833]/40 bg-neutral-950/50 p-5">
            <h3 className="font-mono text-sm font-extrabold text-white mb-3 uppercase flex items-center gap-2">
              <Search className="w-4 h-4 text-[#45f3ff]" />
              RAG Similarity Match Playground
            </h3>
            <p className="font-mono text-[10px] text-neutral-500 mb-4 leading-relaxed">
              Query search keywords in real-time below! Nexora simulates cosine alignment to showcase retrieved context index scores.
            </p>

            <div className="relative mb-4">
              <Search className="absolute left-3 top-3 h-4 w-4 text-neutral-500" />
              <input
                type="text"
                placeholder="Query query to see retrieved contexts..."
                value={playgroundQuery}
                onChange={(e) => setPlaygroundQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-black/60 border border-[#1f2833]/50 focus:outline-hidden focus:border-[#45f3ff]/50 rounded-xl font-mono text-xs text-white placeholder:text-neutral-700"
              />
            </div>

            <div className="space-y-3">
              {playgroundQuery ? (
                searchResults.length === 0 ? (
                  <div className="py-8 text-center text-xs font-mono text-neutral-600 border border-dashed border-[#1f2833]/30 rounded-lg">
                    No similarity chunks loaded. Try indexing references above!
                  </div>
                ) : (
                  <div className="space-y-2">
                    <div className="font-mono text-[10px] text-cyan-400 font-extrabold uppercase tracking-widest pl-1 mb-2">Top Chunks Retrieved:</div>
                    {searchResults.map((item, index) => (
                      <motion.div 
                        initial={{ opacity: 0, x: -5 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                        key={item.chunk.id} 
                        className="p-3 rounded-lg border border-cyan-950/40 bg-zinc-950/80 hover:border-cyan-500/20 transition-all flex flex-col gap-1 w-full"
                      >
                        <div className="flex items-center justify-between font-mono text-[10px] pb-1.5 border-b border-zinc-900">
                          <span className="text-[#45f3ff] font-extrabold truncate max-w-[200px]">📑 {item.chunk.docTitle}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-neutral-500">Chunk {item.chunk.chunkIndex}/{item.chunk.totalChunks}</span>
                            <span className="px-1.5 py-0.5 rounded-md bg-emerald-500/10 text-emerald-400 font-bold border border-emerald-500/20">Relevance: {Math.min(item.score * 12, 99).toFixed(0)}%</span>
                          </div>
                        </div>
                        <p className="text-neutral-300 font-mono text-[11px] leading-relaxed mt-1 whitespace-pre-wrap">
                          {item.chunk.content.substring(0, 200)}...
                        </p>
                      </motion.div>
                    ))}
                  </div>
                )
              ) : (
                <div className="py-12 text-center text-xs font-mono text-neutral-600 border border-dashed border-[#1f2833]/30 rounded-lg bg-zinc-950/20">
                  ⚡️ Type keywords/queries above to verify real-time SQL / Cognitive matches before typing in chat panels!
                </div>
              )}
            </div>
          </div>
        </div>

        {/* RIGHT PANEL: Files, current Document index lists (5 columns) */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          
          {/* Document Inventory */}
          <div className="rounded-xl border border-[#1f2833]/40 bg-neutral-950/50 p-5 w-full">
            <h3 className="font-mono text-sm font-extrabold text-white mb-3 uppercase flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Database className="w-4 h-4 text-[#45f3ff]" />
                Active Knowledge Base
              </span>
              <span className="text-[10px] tracking-widest font-extrabold px-2 py-0.5 rounded-md bg-neutral-900 border border-[#1f2833]/50 text-neutral-400">
                {docs.length} FILES
              </span>
            </h3>

            {loading && docs.length === 0 ? (
              <div className="py-16 flex flex-col items-center justify-center gap-3">
                <Clock className="w-8 h-8 text-cyan-400 animate-spin" />
                <span className="font-mono text-[11px] text-neutral-500 uppercase">Synchronizing files...</span>
              </div>
            ) : docs.length === 0 ? (
              <div className="py-16 text-center border border-dashed border-[#1f2833]/30 rounded-xl bg-black/10">
                <AlertTriangle className="w-8 h-8 text-neutral-600 mx-auto mb-2" />
                <p className="font-mono text-xs font-bold text-neutral-400">Library Empty Yaara!</p>
                <p className="text-[10px] text-neutral-600 font-mono mt-1 leading-relaxed max-w-xs mx-auto">
                  Drag & Drop a TXT or MD note above to train Nexora with custom instructions.
                </p>
              </div>
            ) : (
              <div className="space-y-4 max-h-[700px] overflow-y-auto pr-1">
                {docs.map(doc => (
                  <div 
                    key={doc.title} 
                    className="p-4 rounded-xl border border-[#1f2833]/40 bg-zinc-950/70 hover:border-zinc-800 transition-all flex flex-col gap-2.5 w-full relative group"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="p-2 bg-cyan-950/30 border border-[#45f3ff]/20 text-[#45f3ff] rounded-lg shrink-0">
                          <FileText className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <h4 className="font-mono text-xs font-bold text-white truncate break-all leading-tight pr-1" title={doc.title}>
                            {doc.title}
                          </h4>
                          <span className="text-[9px] text-[#45f3ff] uppercase font-mono font-extrabold tracking-widest mt-1 block">
                            {doc.chunkCount} SQL Chunks Injected
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => handleDeleteDocument(doc.title, doc.chunks)}
                        className="p-1.5 rounded-lg border border-red-950/20 bg-red-950/10 hover:bg-red-950 hover:text-white text-rose-400 cursor-pointer transition-all shrink-0"
                        title="Delete Document"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Progress tracking representation of chunks */}
                    <div className="pt-2 border-t border-[#1f2833]/20 flex items-center justify-between font-mono text-[9px] text-neutral-500 w-full select-none">
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3 h-3 text-[#45f3ff] opacity-70" />
                        <span>{new Date(doc.lastUpdated).toLocaleDateString()} at {new Date(doc.lastUpdated).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                      </div>
                      <span className="px-1.5 py-0.5 rounded bg-[#45f3ff]/5 text-neutral-400 border border-[#45f3ff]/10 font-bold uppercase">SECURED SQL</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          {/* Quick instructions guide */}
          <div className="rounded-xl border border-cyan-950 bg-cyan-950/10 p-5 font-mono text-xs text-neutral-300 space-y-3.5 max-w-full">
            <h4 className="font-extrabold text-[#45f3ff] uppercase flex items-center gap-1.5 leading-none">
              <Sparkles className="w-4 h-4" />
              How Nexora RAG Works
            </h4>
            <ul className="space-y-2.5 text-neutral-400 text-[11px] leading-relaxed list-none pl-0">
              <li className="flex items-start gap-2">
                <span className="text-[#45f3ff] font-extrabold">1.</span>
                <span>Each PDF or text upload is segmented using overlap preservation to avoid trailing breaks inside terms.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#45f3ff] font-extrabold">2.</span>
                <span>The system pushes segments into the PostgreSQL DB linked to your UID, protecting data leakage.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-[#45f3ff] font-extrabold">3.</span>
                <span>In chat, if **RAG SEARCH** is toggled Active, Nexora scans these chunks and serves references directly.</span>
              </li>
            </ul>
          </div>
        </div>

      </div>

    </div>
  );
};
