import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  Plus, 
  Trash2, 
  Search, 
  Sparkles, 
  RefreshCw, 
  AlertCircle, 
  CheckCircle2, 
  MapPin, 
  Users,
  ChevronRight,
  Info,
  CalendarDays,
  Flame,
  ArrowRight,
  Lock
} from 'lucide-react';

interface GoogleCalendarDashboardProps {
  user: any;
  googleAccessToken: string | null;
  onConnect: () => Promise<void>;
  isConnecting: boolean;
}

interface CalendarEvent {
  id: string;
  summary: string;
  description?: string;
  location?: string;
  htmlLink?: string;
  start: {
    dateTime?: string;
    date?: string;
  };
  end: {
    dateTime?: string;
    date?: string;
  };
  attendees?: Array<{ email: string; responseStatus: string }>;
}

export function GoogleCalendarDashboard({ 
  user, 
  googleAccessToken, 
  onConnect, 
  isConnecting 
}: GoogleCalendarDashboardProps) {
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [loadingEvents, setLoadingEvents] = useState(false);
  const [errorStatus, setErrorStatus] = useState<string | null>(null);
  
  // Event Form State
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [summary, setSummary] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [startDate, setStartDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endDate, setEndDate] = useState('');
  const [endTime, setEndTime] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Search Filter
  const [searchQuery, setSearchQuery] = useState('');

  // Fetch Events from Google Calendar API
  const fetchCalendarEvents = async () => {
    if (!googleAccessToken) return;
    setLoadingEvents(true);
    setErrorStatus(null);
    try {
      // Fetch upcoming events for next 30 days
      const now = new Date();
      const timeMin = now.toISOString();
      const url = `https://www.googleapis.com/calendar/v3/calendars/primary/events?orderBy=startTime&singleEvents=true&timeMin=${encodeURIComponent(timeMin)}&maxResults=25`;
      
      const res = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${googleAccessToken}`,
          'Accept': 'application/json'
        }
      });
      
      if (!res.ok) {
        throw new Error(`Google Calendar API responded with status ${res.status}`);
      }

      const data = await res.json();
      setEvents(data.items || []);
    } catch (err: any) {
      console.error("Error fetching google calendar events:", err);
      setErrorStatus(err.message || "Failed to load events. Your connection might be expired.");
    } finally {
      setLoadingEvents(false);
    }
  };

  useEffect(() => {
    if (googleAccessToken) {
      fetchCalendarEvents();
    }
  }, [googleAccessToken]);

  // Clean form
  const resetFormFields = () => {
    setSummary('');
    setDescription('');
    setLocation('');
    
    const today = new Date();
    const formattedDate = today.toISOString().split('T')[0];
    const currentHour = String((today.getHours() + 1) % 24).padStart(2, '0');
    const nextHour = String((today.getHours() + 2) % 24).padStart(2, '0');
    
    setStartDate(formattedDate);
    setStartTime(`${currentHour}:00`);
    setEndDate(formattedDate);
    setEndTime(`${nextHour}:00`);
    setAiPrompt('');
  };

  // Client side natural language quick scheduler parser
  const handleAiPromptParse = () => {
    if (!aiPrompt.trim()) return;
    
    const prompt = aiPrompt.toLowerCase();
    let parsedTitle = '';
    let parsedDate = new Date();
    let parsedHour = 12;
    let parsedMinute = 0;

    // Title extraction guesses (everything before 'at' or 'on' or 'tomorrow')
    const stopWords = ['tomorrow', 'at', 'on', 'today', 'next', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
    const words = aiPrompt.split(' ');
    const titleWords: string[] = [];
    
    for (const word of words) {
      if (stopWords.includes(word.toLowerCase())) break;
      titleWords.push(word);
    }
    parsedTitle = titleWords.join(' ') || "Awesome Event with Nexora AI";

    // Date parsing
    if (prompt.includes('tomorrow')) {
      parsedDate.setDate(parsedDate.getDate() + 1);
    } else if (prompt.includes('today')) {
      // Remains today
    } else if (prompt.includes('next monday')) {
      const day = parsedDate.getDay();
      const distance = (1 + 7 - day) % 7 || 7;
      parsedDate.setDate(parsedDate.getDate() + distance);
    } else if (prompt.includes('next friday')) {
      const day = parsedDate.getDay();
      const distance = (5 + 7 - day) % 7 || 7;
      parsedDate.setDate(parsedDate.getDate() + distance);
    }

    // Time extraction (e.g. at 5pm, 10am, 15:30)
    const timeMatch = prompt.match(/at\s+(\d+)(?::(\d+))?\s*(am|pm)?/i) || prompt.match(/(\d+)(?::(\d+))?\s*(am|pm)/i);
    if (timeMatch) {
      let hr = parseInt(timeMatch[1], 10);
      const min = timeMatch[2] ? parseInt(timeMatch[2], 10) : 0;
      const ampm = timeMatch[3] ? timeMatch[3].toLowerCase() : null;
      
      if (ampm === 'pm' && hr < 12) hr += 12;
      if (ampm === 'am' && hr === 12) hr = 0;
      
      parsedHour = hr;
      parsedMinute = min;
    }

    // Update States
    setSummary(parsedTitle);
    const dateFormatted = parsedDate.toISOString().split('T')[0];
    setStartDate(dateFormatted);
    setEndDate(dateFormatted);
    
    const timeFormatted = `${String(parsedHour).padStart(2, '0')}:${String(parsedMinute).padStart(2, '0')}`;
    setStartTime(timeFormatted);
    
    const endHr = (parsedHour + 1) % 24;
    const endTimeFormatted = `${String(endHr).padStart(2, '0')}:${String(parsedMinute).padStart(2, '0')}`;
    setEndTime(endTimeFormatted);
    
    setDescription(`Scheduled using Nexora Natural Language AI Parser:\n"${aiPrompt}"`);
  };

  // Create Event Handler
  const handleCreateEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!googleAccessToken) return;
    if (!summary.trim()) {
      alert("Bhai, event topic / summary empty nahi ho sakta!");
      return;
    }

    setSubmitting(true);
    setErrorStatus(null);
    setSuccessMsg(null);

    try {
      const startDateTime = new Date(`${startDate}T${startTime}:00`).toISOString();
      const endDateTime = new Date(`${endDate}T${endTime}:00`).toISOString();

      const eventBody = {
        summary: summary,
        description: description,
        location: location,
        start: {
          dateTime: startDateTime,
          timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Kolkata'
        },
        end: {
          dateTime: endDateTime,
          timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Kolkata'
        }
      };

      const res = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${googleAccessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(eventBody)
      });

      if (!res.ok) {
        throw new Error(`Failed to create calendar event with code ${res.status}`);
      }

      setSuccessMsg("Balle Balle! 🎉 Event successfully scheduled on your Google Calendar!");
      setShowCreateForm(false);
      resetFormFields();
      
      // Refresh list
      fetchCalendarEvents();

      // Clear success notification automatically after 4 seconds
      setTimeout(() => setSuccessMsg(null), 4000);
    } catch (err: any) {
      console.error("Error creating Google Calendar event:", err);
      setErrorStatus(err.message || "Apology, calendar event save collapsed. Please retry!");
    } finally {
      setSubmitting(false);
    }
  };

  // Safe Delete Event with Mandatory user confirmation (required by guidelines)
  const handleDeleteEvent = async (eventId: string, eventTitle: string) => {
    if (!googleAccessToken) return;
    
    const confirmed = window.confirm(
      `Hey buddy! Are you sure you want to delete the event: "${eventTitle}"? This cannot be undone.`
    );
    if (!confirmed) return;

    setLoadingEvents(true);
    try {
      const res = await fetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events/${eventId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${googleAccessToken}`
        }
      });

      if (!res.ok) {
        throw new Error(`Delete request collapsed with status ${res.status}`);
      }

      setSuccessMsg(`Event "${eventTitle}" removed successfully! 🧹`);
      setTimeout(() => setSuccessMsg(null), 3000);
      
      // Update list locally
      setEvents(prev => prev.filter(e => e.id !== eventId));
    } catch (err: any) {
      console.error("Error deleting event:", err);
      alert(`Bhai, delete fail ho gaya: ${err.message || err}`);
    } finally {
      setLoadingEvents(false);
    }
  };

  // Filter events based on search query
  const filteredEvents = events.filter(e => {
    if (!searchQuery.trim()) return true;
    const lower = searchQuery.toLowerCase();
    const matchesSummary = e.summary ? e.summary.toLowerCase().includes(lower) : false;
    const matchesDesc = e.description ? e.description.toLowerCase().includes(lower) : false;
    const matchesLoc = e.location ? e.location.toLowerCase().includes(lower) : false;
    return matchesSummary || matchesDesc || matchesLoc;
  });

  return (
    <div className="w-full max-w-4xl mx-auto py-4 px-3 md:px-5 space-y-6">
      
      {/* 1. Dashboard Ribbon / Header */}
      <div className="bg-[#121214] border border-brand-border/60 rounded-3xl p-6 relative overflow-hidden backdrop-blur-md shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="absolute top-0 right-0 w-44 h-44 bg-brand-accent/5 rounded-full blur-[40px] pointer-events-none" />
        
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-brand-accent/10 to-amber-500/10 border border-brand-accent/20 flex items-center justify-center text-brand-accent select-none shrink-0 shadow-md">
            <CalendarDays className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
              Google Calendar Workspace
              <span className="text-[10px] uppercase tracking-widest px-2 py-0.5 rounded-full bg-brand-accent/20 text-brand-accent font-extrabold border border-brand-accent/20">
                PRO
              </span>
            </h1>
            <p className="text-xs text-brand-secondary/80 mt-1 font-medium">
              Plan, schedule, and clean up your events seamlessly in Hindlish/English like a boss!
            </p>
          </div>
        </div>

        {/* Action Button Strip */}
        <div className="flex items-center gap-2.5">
          {googleAccessToken ? (
            <>
              <button
                onClick={fetchCalendarEvents}
                disabled={loadingEvents}
                className="p-2.5 rounded-xl border border-brand-border hover:bg-neutral-900 text-brand-secondary hover:text-brand-primary active:scale-95 transition-all cursor-pointer disabled:opacity-50"
                title="Refresh agenda list"
              >
                <RefreshCw className={`w-4 h-4 ${loadingEvents ? 'animate-spin' : ''}`} />
              </button>
              
              <button
                onClick={() => {
                  resetFormFields();
                  setShowCreateForm(!showCreateForm);
                }}
                className="px-4 py-2.5 rounded-xl bg-brand-accent text-zinc-950 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-brand-accent/10 hover:brightness-110 active:scale-95 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                <span>Naya Event</span>
              </button>
            </>
          ) : (
            <button
              onClick={onConnect}
              disabled={isConnecting}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#4285F4] to-[#34A853] text-white font-bold text-xs flex items-center gap-2 shadow-lg hover:brightness-110 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isConnecting ? "Setting up..." : "Connect Google Calendar"}</span>
            </button>
          )}
        </div>
      </div>

      {/* 2. Success and Error indicators */}
      <AnimatePresence mode="wait">
        {successMsg && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center gap-3 text-emerald-300 text-xs"
          >
            <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-400" />
            <span className="font-semibold">{successMsg}</span>
          </motion.div>
        )}

        {errorStatus && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-4 bg-red-500/10 border border-red-500/30 rounded-2xl flex items-center gap-3 text-red-350 text-xs"
          >
            <AlertCircle className="w-5 h-5 shrink-0 text-red-400" />
            <div className="font-semibold flex-1">
              {errorStatus}
            </div>
            {errorStatus.includes("expired") && (
              <button 
                onClick={onConnect}
                className="px-3 py-1.5 rounded-lg bg-red-500/20 text-red-300 font-bold hover:bg-red-500/30 text-[10px] uppercase tracking-wider transition duration-150 cursor-pointer"
              >
                Reconnect
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* 3. Event Create Form Toggle Layer */}
      <AnimatePresence>
        {showCreateForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <form 
              onSubmit={handleCreateEvent}
              className="bg-[#121214] border border-brand-border/60 rounded-3xl p-6 space-y-5 shadow-2xl relative"
            >
              <h2 className="text-sm font-bold text-white flex items-center gap-1.5 select-none uppercase tracking-wider text-brand-accent">
                <Plus className="w-4 h-4 text-brand-accent shrink-0" />
                Schedule New Agenda
              </h2>

              {/* A. AI Autopilot parse assistance row */}
              <div className="bg-[#18181c]/50 border border-zinc-800 rounded-2xl p-4 space-y-2.5">
                <div className="flex items-center gap-1.5 text-zinc-400 text-[10px] font-bold uppercase tracking-wider select-none">
                  <Sparkles className="w-3.5 h-3.5 text-brand-accent shrink-0" />
                  <span>Nexora AI-Autoprefill Assistant (Hinglish/English friendly)</span>
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    placeholder="e.g., Code Review with Raja tomorrow at 4:30 pm"
                    className="flex-1 bg-zinc-900 border border-zinc-800 text-xs px-3.5 py-2.5 rounded-xl text-white placeholder:text-zinc-600 focus:border-brand-accent/40 focus:outline-hidden transition"
                  />
                  <button
                    type="button"
                    onClick={handleAiPromptParse}
                    className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                  >
                    <span>Autofill</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
                <p className="text-[10px] text-zinc-500">
                  Type what's on your agenda, click <b>Autofill</b>, and we'll translate it to title, date, & time!
                </p>
              </div>

              {/* B. Manual Fields */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Summary */}
                <div className="space-y-1.5 md:col-span-2">
                  <label className="text-[11px] text-zinc-400 font-bold uppercase select-none">Event Title / Summary *</label>
                  <input
                    type="text"
                    required
                    value={summary}
                    onChange={(e) => setSummary(e.target.value)}
                    placeholder="Event title (e.g. Sync meeting)"
                    className="w-full bg-zinc-900 border border-brand-border/65 text-xs px-3.5 py-2.5 rounded-xl text-white placeholder:text-zinc-600 focus:border-brand-accent/40 focus:outline-hidden transition"
                  />
                </div>

                {/* Start Date & Time */}
                <div className="space-y-1.5">
                  <label className="text-[11px] text-zinc-400 font-bold uppercase select-none">Start Date & Time</label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="date"
                      required
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="bg-zinc-900 border border-brand-border/65 text-xs px-2.5 py-2 rounded-xl text-white focus:border-brand-accent/40 focus:outline-hidden transition"
                    />
                    <input
                      type="time"
                      required
                      value={startTime}
                      onChange={(e) => setStartTime(e.target.value)}
                      className="bg-zinc-900 border border-brand-border/65 text-xs px-2.5 py-2 rounded-xl text-white focus:border-brand-accent/40 focus:outline-hidden transition"
                    />
                  </div>
                </div>

                {/* End Date & Time */}
                <div className="space-y-1.5">
                  <label className="text-[11px] text-zinc-400 font-bold uppercase select-none">End Date & Time</label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="date"
                      required
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      className="bg-zinc-900 border border-brand-border/65 text-xs px-2.5 py-2 rounded-xl text-white focus:border-brand-accent/40 focus:outline-hidden transition"
                    />
                    <input
                      type="time"
                      required
                      value={endTime}
                      onChange={(e) => setEndTime(e.target.value)}
                      className="bg-zinc-900 border border-brand-border/65 text-xs px-2.5 py-2 rounded-xl text-white focus:border-brand-accent/40 focus:outline-hidden transition"
                    />
                  </div>
                </div>

                {/* Location */}
                <div className="space-y-1.5">
                  <label className="text-[11px] text-zinc-400 font-bold uppercase select-none">Location (Physical or Virtual)</label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="e.g. Google Meet, India, Mumbai Room"
                    className="w-full bg-zinc-900 border border-brand-border/65 text-xs px-3.5 py-2.5 rounded-xl text-white placeholder:text-zinc-650 focus:border-brand-accent/40 focus:outline-hidden"
                  />
                </div>

                {/* Description */}
                <div className="space-y-1.5 md:col-span-2">
                  <label className="text-[11px] text-zinc-400 font-bold uppercase select-none">Description / Agenda details</label>
                  <textarea
                    rows={2}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Brief description about what's cooking in the sync..."
                    className="w-full bg-zinc-900 border border-brand-border/65 text-xs px-3.5 py-2.5 rounded-xl text-white placeholder:text-zinc-650 focus:border-brand-accent/40 focus:outline-hidden"
                  />
                </div>

              </div>

              {/* Form Actions */}
              <div className="flex justify-end gap-2.5 pt-2 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setShowCreateForm(false)}
                  className="px-4 py-2 rounded-xl border border-brand-border hover:bg-neutral-900 text-brand-secondary text-xs font-semibold cursor-pointer transition active:scale-95"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-2 rounded-xl bg-brand-accent text-zinc-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer hover:brightness-110 disabled:opacity-50 transition active:scale-95"
                >
                  {submitting && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                  <span>Save on Calendar</span>
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 4. Active Connections / Event List Grid */}
      {!googleAccessToken ? (
        <div className="bg-[#121214] border border-brand-border/60 rounded-3xl p-8 text-center flex flex-col items-center justify-center space-y-4">
          <div className="w-14 h-14 bg-zinc-900 text-zinc-500 rounded-2xl flex items-center justify-center border border-zinc-800">
            <Lock className="w-7 h-7" />
          </div>
          <div className="max-w-md">
            <h3 className="text-md font-bold text-white mb-2">Google Account Required</h3>
            <p className="text-xs text-brand-secondary/80 leading-relaxed">
              Google Calendar use karne ke liye aapko pehle Google Sign-In with calendar access permission connect karna hoga.
            </p>
          </div>
          <button
            onClick={onConnect}
            disabled={isConnecting}
            className="px-6 py-3 rounded-xl bg-brand-accent text-zinc-950 font-extrabold text-xs tracking-wide transition duration-155 hover:scale-[1.02] active:scale-[0.98] cursor-pointer shadow-lg shadow-brand-accent/10"
          >
            {isConnecting ? "Authorization details checking..." : "Unlock Google Calendar Sync"}
          </button>
        </div>
      ) : (
        <div className="bg-[#121214] border border-brand-border/60 rounded-3xl p-5 md:p-6 space-y-5">
          
          {/* List Toolbar search bar & counts */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-850 pb-4">
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-white select-none">Upcoming Agenda</span>
              <span className="text-[10px] font-bold bg-[#18181c] border border-zinc-800 text-brand-accent px-2 py-0.5 rounded-full">
                {filteredEvents.length} list items
              </span>
            </div>

            {/* Filter */}
            <div className="relative max-w-xs w-full">
              <span className="absolute left-2.5 top-2.5 flex items-center justify-center">
                <Search className="w-3.5 h-3.5 text-brand-secondary/70" />
              </span>
              <input
                type="text"
                placeholder="Search matching events..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-zinc-900 border border-brand-border/55 text-[11px] pl-8 pr-3 py-2 rounded-xl text-white placeholder:text-zinc-650 focus:border-brand-accent/40 focus:outline-hidden transition-all duration-150"
              />
            </div>
          </div>

          {/* List display */}
          {loadingEvents ? (
            <div className="py-12 flex flex-col items-center justify-center space-y-3">
              <RefreshCw className="w-8 h-8 text-brand-accent animate-spin" />
              <p className="text-xs text-brand-secondary font-medium">Fetching sync data from Google servers...</p>
            </div>
          ) : filteredEvents.length === 0 ? (
            <div className="py-12 border-2 border-dashed border-zinc-800/60 rounded-2xl flex flex-col items-center justify-center text-center p-6 bg-zinc-950/20">
              <div className="w-12 h-12 bg-zinc-900 rounded-xl flex items-center justify-center text-zinc-500 mb-3 border border-zinc-800">
                <CalendarDays className="w-6 h-6" />
              </div>
              <h4 className="text-xs font-bold text-white tracking-wide">No upcoming events are booked</h4>
              <p className="text-[10px] text-brand-secondary/80 max-w-xs leading-relaxed mt-1.5">
                {searchQuery ? "Bhai is title ya description ke satha koi event nahi mila!" : "Aaj ya aage ke dino me koi event scheduled nahi hai. Click 'Naya Event' above to create one!"}
              </p>
            </div>
          ) : (
            <div className="divide-y divide-zinc-850">
              {filteredEvents.map(e => {
                const startStr = e.start.dateTime || e.start.date || '';
                const endStr = e.end.dateTime || e.end.date || '';
                
                const hasTime = !!e.start.dateTime;
                
                let dateLabel = "All Day";
                let timeRange = "";
                let weekday = "";
                
                if (startStr) {
                  const startDateObj = new Date(startStr);
                  weekday = startDateObj.toLocaleDateString(undefined, { weekday: 'short' });
                  dateLabel = startDateObj.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
                  
                  if (hasTime) {
                    const startT = startDateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                    const endT = new Date(endStr).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                    timeRange = `${startT} - ${endT}`;
                  }
                }

                return (
                  <motion.div 
                    key={e.id}
                    layoutId={`val-event-${e.id}`}
                    className="py-4 hover:bg-zinc-900/40 px-2.5 rounded-xl transition duration-150 flex items-start justify-between gap-4 group"
                  >
                    <div className="flex items-start gap-4 flex-1">
                      {/* Date Block badge */}
                      <div className="w-11 h-11 shrink-0 rounded-xl bg-[#18181b] border border-zinc-800 flex flex-col items-center justify-center select-none shadow-inner">
                        <span className="text-[9px] font-black tracking-widest text-[#e4e4e7] uppercase">{weekday}</span>
                        <span className="text-[13px] font-extrabold text-brand-accent -mt-0.5">{startStr ? new Date(startStr).getDate() : '-'}</span>
                      </div>

                      <div className="space-y-1 flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold text-[#f4f4f5] group-hover:text-brand-accent transition">
                            {e.summary || "Untitled Sync Event"}
                          </h4>
                          {e.htmlLink && (
                            <a 
                              href={e.htmlLink}
                              target="_blank"
                              rel="noreferrer"
                              className="text-zinc-650 hover:text-zinc-400 transition"
                              title="Open on official Google Calendar web client"
                            >
                              <ChevronRight className="w-3.5 h-3.5" />
                            </a>
                          )}
                        </div>

                        {/* Timing Block */}
                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[10px] text-zinc-400 font-semibold font-mono">
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3 text-zinc-500" />
                            {dateLabel} {timeRange && `(${timeRange})`}
                          </span>

                          {e.location && (
                            <span className="flex items-center gap-1 text-zinc-505 truncate max-w-xs">
                              <MapPin className="w-3 h-3 text-zinc-500" />
                              {e.location}
                            </span>
                          )}
                        </div>

                        {e.description && (
                          <p className="text-[10px] text-brand-secondary/80 leading-normal max-w-xl">
                            {e.description}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Delete action */}
                    <button
                      onClick={() => handleDeleteEvent(e.id, e.summary || "Untitled Event")}
                      className="p-2 ml-2 rounded-lg bg-transparent text-zinc-500 hover:text-rose-405 hover:bg-rose-500/10 opacity-0 group-hover:opacity-100 transition duration-150 cursor-pointer"
                      title="Delete event from calendar"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </motion.div>
                );
              })}
            </div>
          )}

          {/* Safe Privacy notice */}
          <div className="bg-[#18181c]/40 border border-zinc-800/60 p-4 rounded-2xl flex items-start gap-2.5">
            <Info className="w-4.5 h-4.5 text-zinc-400 shrink-0 mt-0.5" />
            <p className="text-[10px] text-zinc-400 leading-relaxed">
              Google Calendar access is protected. All edits and sync coordinates are performed directly against your Google account via secure client-side API requests. We do not store or track any of your database meetings.
            </p>
          </div>

        </div>
      )}

    </div>
  );
}
