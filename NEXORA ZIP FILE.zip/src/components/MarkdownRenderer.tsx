import React from 'react';
import Markdown from 'react-markdown';

interface Props {
  content: string;
}

export const MarkdownRenderer: React.FC<Props> = ({ content }) => {
  return (
    <div className="markdown-body">
      <Markdown
        components={{
          h1: ({ children, ...props }) => (
            <h1 className="text-[22px] font-bold mt-4 mb-2 text-brand-primary tracking-tight" {...props}>
              {children}
            </h1>
          ),
          h2: ({ children, ...props }) => (
            <h2 className="text-[19px] font-semibold mt-3.5 mb-1.5 text-brand-primary tracking-tight" {...props}>
              {children}
            </h2>
          ),
          h3: ({ children, ...props }) => (
            <h3 className="text-[17px] font-semibold mt-3 mb-1 text-brand-primary" {...props}>
              {children}
            </h3>
          ),
          p: ({ children, ...props }) => (
            <p className="mb-2 w-full last:mb-0 leading-relaxed text-[15px] md:text-base text-brand-primary/95" {...props}>
              {children}
            </p>
          ),
          ul: ({ children, ...props }) => (
            <ul className="list-disc pl-5 mb-2.5 mt-1 space-y-1 text-[15px] md:text-base text-brand-primary/95" {...props}>
              {children}
            </ul>
          ),
          ol: ({ children, ...props }) => (
            <ol className="list-decimal pl-5 mb-2.5 mt-1 space-y-1 text-[15px] md:text-base text-brand-primary/95" {...props}>
              {children}
            </ol>
          ),
          li: ({ children, ...props }) => (
            <li className="mb-1" {...props}>
              {children}
            </li>
          ),
          strong: ({ children, ...props }) => (
            <strong className="font-bold text-brand-accent" {...props}>
              {children}
            </strong>
          ),
          em: ({ children, ...props }) => (
            <em className="italic text-brand-primary/80" {...props}>
              {children}
            </em>
          ),
          blockquote: ({ children, ...props }) => (
            <blockquote className="border-l-4 border-brand-accent bg-brand-sidebar/60 pl-3.5 py-1.5 my-3 rounded-r-lg italic text-brand-secondary text-[14px]" {...props}>
              {children}
            </blockquote>
          ),
          a: ({ children, href, ...props }) => (
            <a
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              className="text-brand-accent hover:underline hover:text-brand-accent-hover font-medium whitespace-normal break-all"
              {...props}
            >
              {children}
            </a>
          ),
          code: ({ children, ...props }) => {
            return (
              <code className="bg-brand-sidebar px-1.5 py-0.5 rounded-md font-mono text-xs text-brand-accent border border-brand-border font-semibold" {...props}>
                {children}
              </code>
            );
          },
          pre: ({ children, ...props }) => {
            return (
              <pre className="bg-brand-sidebar p-3.5 rounded-xl overflow-x-auto my-3 border border-brand-border font-mono text-xs md:text-sm max-w-full text-brand-primary/90" {...props}>
                {children}
              </pre>
            );
          }
        }}
      >
        {content}
      </Markdown>
    </div>
  );
};
