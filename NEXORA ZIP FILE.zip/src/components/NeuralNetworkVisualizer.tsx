import React, { useState, useEffect, useRef } from "react";
import { 
  Network, Cpu, Layers, Sliders, Activity, Play, RefreshCw, 
  HelpCircle, ArrowRight, BookOpen, Globe, CheckCircle2, 
  Sparkles, BrainCircuit, Info, MessageSquare, Flame
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface Node {
  id: string;
  label: string;
  layer: "input" | "hidden1" | "hidden2" | "output";
  val: number;
  bias: number;
  desc: string;
}

interface Connection {
  from: string;
  to: string;
  weight: number;
}

interface NeuralNetworkVisualizerProps {
  user: any;
  authToken: string | null;
  onAddedLogs?: (log: any) => void;
}

export default function NeuralNetworkVisualizer({ user, authToken, onAddedLogs }: NeuralNetworkVisualizerProps) {
  // Hyperparameters
  const [learningRate, setLearningRate] = useState<number>(0.05);
  const [activationFn, setActivationFn] = useState<"relu" | "sigmoid" | "tanh" | "leaky">("sigmoid");
  const [noiseLevel, setNoiseLevel] = useState<number>(0.1);
  const [isTraining, setIsTraining] = useState<boolean>(false);
  const [epoch, setEpoch] = useState<number>(42);
  const [loss, setLoss] = useState<number>(0.184);
  const [lossHistory, setLossHistory] = useState<number[]>([0.85, 0.62, 0.48, 0.39, 0.31, 0.26, 0.22, 0.19, 0.184]);

  // Network State
  const [nodes, setNodes] = useState<Node[]>([
    // Input layer
    { id: "x1", label: "Query Intent (x1)", layer: "input", val: 0.85, bias: 0, desc: "Keyword semantic intensity" },
    { id: "x2", label: "Google Crawler (x2)", layer: "input", val: 0.92, bias: 0, desc: "Google Live Search signals" },
    { id: "x3", label: "Wikipedia Gateway (x3)", layer: "input", val: 0.74, bias: 0, desc: "Wikipedia Main Page retrieval weight" },
    { id: "x4", label: "Emotion / Sentiment (x4)", layer: "input", val: 0.68, bias: 0, desc: "User conversation sentiment tone" },

    // Hidden Layer 1 (Feature extractions)
    { id: "h1_1", label: "Attention Focus (h1.1)", layer: "hidden1", val: 0.62, bias: -0.12, desc: "Weighs query term match focus" },
    { id: "h1_2", label: "Context Weaver (h1.2)", layer: "hidden1", val: 0.78, bias: 0.25, desc: "Connects separate search results" },
    { id: "h1_3", label: "Fact Filter (h1.3)", layer: "hidden1", val: 0.45, bias: -0.34, desc: "Discards noise and duplicate content" },

    // Hidden Layer 2 (Synthesis)
    { id: "h2_1", label: "Linguistic Mixer (h2.1)", layer: "hidden2", val: 0.71, bias: 0.05, desc: "Fuses RAG context and grammar templates" },
    { id: "h2_2", label: "Indian Flare Synthesizer (h2.2)", layer: "hidden2", val: 0.88, bias: 0.18, desc: "Injects Nexora's cool Hinglish personality" },

    // Output Layer
    { id: "y1", label: "Response Stream (y1)", layer: "output", val: 0.82, bias: 0.1, desc: "Generates natural assistant answer" },
    { id: "y2", label: "SQL Memory Link (y2)", layer: "output", val: 0.76, bias: -0.05, desc: "Determines memory logging threshold" },
  ]);

  const [connections, setConnections] = useState<Connection[]>([
    // x1 -> h1
    { from: "x1", to: "h1_1", weight: 0.45 },
    { from: "x1", to: "h1_2", weight: -0.25 },
    { from: "x1", to: "h1_3", weight: 0.62 },
    // x2 -> h1
    { from: "x2", to: "h1_1", weight: 0.72 },
    { from: "x2", to: "h1_2", weight: 0.58 },
    { from: "x2", to: "h1_3", weight: -0.15 },
    // x3 -> h1
    { from: "x3", to: "h1_1", weight: 0.18 },
    { from: "x3", to: "h1_2", weight: 0.64 },
    { from: "x3", to: "h1_3", weight: 0.81 },
    // x4 -> h1
    { from: "x4", to: "h1_1", weight: -0.52 },
    { from: "x4", to: "h1_2", weight: 0.33 },
    { from: "x4", to: "h1_3", weight: 0.41 },

    // h1 -> h2
    { from: "h1_1", to: "h2_1", weight: 0.55 },
    { from: "h1_1", to: "h2_2", weight: -0.38 },
    { from: "h1_2", to: "h2_1", weight: 0.67 },
    { from: "h1_2", to: "h2_2", weight: 0.84 },
    { from: "h1_3", to: "h2_1", weight: -0.42 },
    { from: "h1_3", to: "h2_2", weight: 0.61 },

    // h2 -> output
    { from: "h2_1", to: "y1", weight: 0.88 },
    { from: "h2_1", to: "y2", weight: 0.24 },
    { from: "h2_2", to: "y1", weight: 0.79 },
    { from: "h2_2", to: "y2", weight: 0.91 },
  ]);

  // UI Interactive Elements
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [hoveredConn, setHoveredConn] = useState<Connection | null>(null);
  const [queryInput, setQueryInput] = useState<string>("");
  const [isSynthesizing, setIsSynthesizing] = useState<boolean>(false);
  const [synthesisLogs, setSynthesisLogs] = useState<string[]>([]);
  const [synthesisResult, setSynthesisResult] = useState<string>("");
  const [pulses, setPulses] = useState<{ id: number; from: string; to: string; delay: number }[]>([]);

  // Refs for tracking animation frames
  const pulseIdCounter = useRef(0);

  // Math Helpers
  const activate = (z: number) => {
    switch (activationFn) {
      case "relu": return Math.max(0, z);
      case "sigmoid": return 1 / (1 + Math.exp(-z));
      case "tanh": return Math.tanh(z);
      case "leaky": return z > 0 ? z : 0.05 * z;
    }
  };

  // Run backpropagation training simulation
  useEffect(() => {
    let interval: any;
    if (isTraining) {
      interval = setInterval(() => {
        setEpoch(prev => prev + 1);
        
        // Randomly tweak weights based on learning rate to simulate SGD / Adam optimization
        setConnections(prev => prev.map(c => {
          const delta = (Math.random() - 0.5) * learningRate * 0.4;
          return { ...c, weight: Math.max(-2, Math.min(2, c.weight + delta)) };
        }));

        // Adjust Biases slightly
        setNodes(prev => prev.map(n => {
          if (n.layer !== "input") {
            const delta = (Math.random() - 0.5) * learningRate * 0.2;
            return { ...n, bias: Math.max(-1, Math.min(1, n.bias + delta)) };
          }
          return n;
        }));

        // Dynamically compute feed-forward step values
        recalculateNetworkValues();

        // Push new Loss (gradually decreasing but with training noise)
        setLoss(prev => {
          const nextLoss = Math.max(0.015, prev - (0.002 * (1 - noiseLevel)) + (Math.random() - 0.5) * 0.005 * noiseLevel);
          setLossHistory(hist => [...hist.slice(-15), nextLoss]);
          return nextLoss;
        });

        // Add visual signaling pulses
        triggerSignalFlow();

      }, 350);
    }
    return () => clearInterval(interval);
  }, [isTraining, learningRate, activationFn, noiseLevel]);

  // Manually run a single epoch / backprop step
  const handleSingleStep = () => {
    setEpoch(prev => prev + 1);
    setConnections(prev => prev.map(c => {
      const delta = (Math.random() - 0.5) * learningRate * 0.3;
      return { ...c, weight: Math.max(-2, Math.min(2, c.weight + delta)) };
    }));
    recalculateNetworkValues();
    setLoss(prev => {
      const nextLoss = Math.max(0.015, prev - 0.003 + (Math.random() - 0.5) * 0.004 * noiseLevel);
      setLossHistory(hist => [...hist.slice(-15), nextLoss]);
      return nextLoss;
    });
    triggerSignalFlow();
  };

  const triggerSignalFlow = () => {
    const newPulses: { id: number; from: string; to: string; delay: number }[] = [];
    
    // Step 1: Input to Hidden 1
    connections.filter(c => c.from.startsWith("x")).forEach((c, idx) => {
      newPulses.push({
        id: pulseIdCounter.current++,
        from: c.from,
        to: c.to,
        delay: idx * 50
      });
    });

    // Step 2: Hidden 1 to Hidden 2
    connections.filter(c => c.from.startsWith("h1_")).forEach((c, idx) => {
      newPulses.push({
        id: pulseIdCounter.current++,
        from: c.from,
        to: c.to,
        delay: 250 + (idx * 50)
      });
    });

    // Step 3: Hidden 2 to Output
    connections.filter(c => c.from.startsWith("h2_")).forEach((c, idx) => {
      newPulses.push({
        id: pulseIdCounter.current++,
        from: c.from,
        to: c.to,
        delay: 500 + (idx * 50)
      });
    });

    setPulses(newPulses);

    // Clean up pulses after animation completes (1s total)
    setTimeout(() => {
      setPulses(prev => prev.filter(p => !newPulses.find(np => np.id === p.id)));
    }, 1500);
  };

  // Recalculates Feed-Forward Activations
  const recalculateNetworkValues = () => {
    setNodes(prev => {
      const updated = [...prev];
      
      // Compute Hidden Layer 1
      const h1_nodes = updated.filter(n => n.layer === "hidden1");
      h1_nodes.forEach(hn => {
        const incoming = connections.filter(c => c.to === hn.id);
        const weightedSum = incoming.reduce((sum, c) => {
          const sourceNode = updated.find(un => un.id === c.from);
          return sum + (sourceNode ? sourceNode.val * c.weight : 0);
        }, hn.bias);
        hn.val = Number(activate(weightedSum).toFixed(3));
      });

      // Compute Hidden Layer 2
      const h2_nodes = updated.filter(n => n.layer === "hidden2");
      h2_nodes.forEach(hn => {
        const incoming = connections.filter(c => c.to === hn.id);
        const weightedSum = incoming.reduce((sum, c) => {
          const sourceNode = updated.find(un => un.id === c.from);
          return sum + (sourceNode ? sourceNode.val * c.weight : 0);
        }, hn.bias);
        hn.val = Number(activate(weightedSum).toFixed(3));
      });

      // Compute Output Layer
      const output_nodes = updated.filter(n => n.layer === "output");
      output_nodes.forEach(on => {
        const incoming = connections.filter(c => c.to === on.id);
        const weightedSum = incoming.reduce((sum, c) => {
          const sourceNode = updated.find(un => un.id === c.from);
          return sum + (sourceNode ? sourceNode.val * c.weight : 0);
        }, on.bias);
        on.val = Number(activate(weightedSum).toFixed(3));
      });

      return updated;
    });
  };

  const resetWeights = () => {
    setEpoch(0);
    setLoss(0.92);
    setLossHistory([0.92]);
    setConnections(prev => prev.map(c => ({
      ...c,
      weight: Number(((Math.random() - 0.5) * 1.8).toFixed(2))
    })));
    setTimeout(recalculateNetworkValues, 50);
  };

  // Triggers real-time synthesis pipeline
  const handleFeedForwardAndSynthesize = async () => {
    if (!queryInput.trim()) return;
    setIsSynthesizing(true);
    setSynthesisLogs([]);
    setSynthesisResult("");

    const addLog = (msg: string) => {
      setSynthesisLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${msg}`]);
    };

    try {
      // Step 1: Input Analysis and feature extraction
      addLog("Initializing Neural Feed-Forward Input Vector...");
      addLog(`User Query: "${queryInput}"`);
      
      // Calculate real intensity characteristics of query input
      const queryLen = queryInput.length;
      const numWords = queryInput.split(/\s+/).length;
      
      // Boost Input Node activations
      setNodes(prev => prev.map(n => {
        if (n.id === "x1") return { ...n, val: Math.min(1.0, 0.4 + (queryLen * 0.005)) };
        if (n.id === "x4") return { ...n, val: Math.min(1.0, 0.5 + (numWords * 0.04)) };
        return n;
      }));
      triggerSignalFlow();
      await new Promise(r => setTimeout(r, 600));

      // Step 2: Contact Search Gateways
      addLog("Activating Wikipedia & Google Search Gateways (Layer 0 Input weights)...");
      addLog("Connecting to: https://en.wikipedia.org/wiki/Main_Page");
      addLog("Connecting to: https://www.google.com/?zx=1782233824255");
      
      // Update gateway activation nodes to full throttle
      setNodes(prev => prev.map(n => {
        if (n.id === "x2") return { ...n, val: 0.98 };
        if (n.id === "x3") return { ...n, val: 0.95 };
        return n;
      }));
      triggerSignalFlow();
      await new Promise(r => setTimeout(r, 800));

      // Step 3: Trigger real server API search & chat synthesis
      addLog("Fetching live network crawler results & piping to Gemini Neural Transformer...");
      
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(authToken ? { "Authorization": `Bearer ${authToken}` } : {})
        },
        body: JSON.stringify({
          message: queryInput,
          mode: "chat",
          ragEnabled: true,
          advancedSearch: true
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error ${response.status}`);
      }

      const data = await response.json();
      addLog("Raw HTML crawler & RAG context successfully parsed.");
      addLog(`Acquired payload matching: Wikipedia details & Google Top Results.`);
      
      // Step 4: Fire multiple fast visual neural waves representing synthesis calculations
      addLog("Performing Weighted Backprop Minimization step to align weights with fact tokens...");
      triggerSignalFlow();
      await new Promise(r => setTimeout(r, 300));
      triggerSignalFlow();
      await new Promise(r => setTimeout(r, 300));
      triggerSignalFlow();

      // Recalculate output nodes with top values
      setNodes(prev => prev.map(n => {
        if (n.id === "y1") return { ...n, val: 0.99 };
        if (n.id === "y2") return { ...n, val: 0.88 };
        return n;
      }));

      addLog("Synthesizing final output text vector (y1 node active). Result delivered:");
      setSynthesisResult(data.reply || "Error parsing response payload.");

      // Add RAG SQL logs if returned
      if (data.sqlLogs && onAddedLogs) {
        data.sqlLogs.forEach((log: any) => onAddedLogs(log));
      }

    } catch (err: any) {
      addLog(`Error during neural pipeline execution: ${err.message || err}`);
      setSynthesisResult(`Error: ${err.message || err}`);
    } finally {
      setIsSynthesizing(false);
    }
  };

  // Setup visual coordinates for SVG rendering
  // Coordinates are designed to look amazing inside responsive flex layouts
  const nodeCoordinates: Record<string, { x: number; y: number }> = {
    x1: { x: 10, y: 15 },
    x2: { x: 10, y: 38 },
    x3: { x: 10, y: 62 },
    x4: { x: 10, y: 85 },

    h1_1: { x: 40, y: 25 },
    h1_2: { x: 40, y: 50 },
    h1_3: { x: 40, y: 75 },

    h2_1: { x: 70, y: 35 },
    h2_2: { x: 70, y: 65 },

    y1: { x: 95, y: 35 },
    y2: { x: 95, y: 65 },
  };

  const getWeightColor = (weight: number) => {
    if (weight > 0) {
      return `rgba(69, 243, 255, ${Math.min(1.0, 0.2 + weight * 0.5)})`; // Glow Cyan
    } else {
      return `rgba(244, 63, 94, ${Math.min(1.0, 0.2 + Math.abs(weight) * 0.5)})`; // Rose Pink
    }
  };

  return (
    <div className="flex-1 flex flex-col xl:flex-row gap-6 p-1 min-h-0 text-white" id="neural-playground-root">
      
      {/* Left side: Interactive Network Diagram Canvas and settings */}
      <div className="flex-1 bg-[#09090b] border border-brand-border/40 rounded-2xl flex flex-col min-h-[450px] xl:min-h-0 relative overflow-hidden shadow-2xl">
        {/* Background Cyber Grid lines */}
        <div className="absolute inset-0 bg-[radial-gradient(#27272a_1px,transparent_1px)] [background-size:16px_16px] opacity-20 pointer-events-none" />
        
        {/* Header toolbar */}
        <div className="px-5 py-4 border-b border-brand-border/40 bg-[#0d0d12]/80 backdrop-blur-md flex items-center justify-between z-10">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-[#45f3ff]/10 text-[#45f3ff] rounded-xl border border-[#45f3ff]/20 animate-pulse">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-black tracking-tight flex items-center gap-2 uppercase">
                Interactive Neural Net Engine
                <span className="bg-[#45f3ff]/10 text-[#45f3ff] text-[8px] font-mono border border-[#45f3ff]/20 px-1.5 py-0.5 rounded-sm tracking-widest uppercase">
                  Active Feedforward
                </span>
              </h2>
              <p className="text-[10px] text-brand-secondary">
                Piping en.wikipedia.org & Live Google Search through a mathematical weight-graph simulation
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setIsTraining(!isTraining)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                isTraining 
                  ? "bg-rose-500/20 text-rose-400 border border-rose-500/30" 
                  : "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20"
              }`}
            >
              <Play className={`w-3 h-3 ${isTraining ? "animate-spin" : ""}`} />
              {isTraining ? "Pause Training" : "Simulate SGD Backpropagation"}
            </button>

            <button
              onClick={handleSingleStep}
              disabled={isTraining}
              className="p-1.5 rounded-lg bg-neutral-900 border border-brand-border/40 text-brand-secondary hover:text-white hover:border-brand-border disabled:opacity-40 transition-all"
              title="One optimization epoch step"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Cyber Network SVG Stage */}
        <div className="flex-1 relative min-h-[300px]" id="neural-svg-container">
          <svg className="w-full h-full absolute inset-0 select-none pointer-events-auto" viewBox="0 0 100 100" preserveAspectRatio="none">
            {/* Draw connections with their real weight values */}
            {connections.map((c, i) => {
              const fromCoord = nodeCoordinates[c.from];
              const toCoord = nodeCoordinates[c.to];
              if (!fromCoord || !toCoord) return null;

              const isHovered = hoveredConn === c;
              
              return (
                <g key={`conn-${i}`}>
                  <line
                    x1={fromCoord.x}
                    y1={fromCoord.y}
                    x2={toCoord.x}
                    y2={toCoord.y}
                    stroke={getWeightColor(c.weight)}
                    strokeWidth={isHovered ? 0.8 : 0.25 + Math.abs(c.weight) * 0.15}
                    className="transition-all duration-300 cursor-pointer"
                    onMouseEnter={() => setHoveredConn(c)}
                    onMouseLeave={() => setHoveredConn(null)}
                  />
                  {/* Subtle directional arrows */}
                  <circle
                    cx={fromCoord.x + (toCoord.x - fromCoord.x) * 0.5}
                    cy={fromCoord.y + (toCoord.y - fromCoord.y) * 0.5}
                    r={0.4}
                    fill={c.weight > 0 ? "#45f3ff" : "#f43f5e"}
                    opacity={0.3}
                  />
                </g>
              );
            })}

            {/* Dynamic Signal Pulses flying down the connections when activated */}
            {pulses.map((p) => {
              const fromCoord = nodeCoordinates[p.from];
              const toCoord = nodeCoordinates[p.to];
              if (!fromCoord || !toCoord) return null;

              return (
                <motion.circle
                  key={p.id}
                  r="0.5"
                  fill="#45f3ff"
                  initial={{ cx: fromCoord.x, cy: fromCoord.y }}
                  animate={{ cx: toCoord.x, cy: toCoord.y }}
                  transition={{ 
                    duration: 0.6, 
                    delay: p.delay / 1000,
                    ease: "easeInOut"
                  }}
                  style={{ filter: "drop-shadow(0 0 4px #45f3ff)" }}
                />
              );
            })}

            {/* Draw nodes */}
            {nodes.map((node) => {
              const coord = nodeCoordinates[node.id];
              if (!coord) return null;

              const isSelected = selectedNode?.id === node.id;
              
              // Map colors to layers
              let color = "#45f3ff"; // Input - cyan
              if (node.layer === "hidden1") color = "#c084fc"; // Purple
              if (node.layer === "hidden2") color = "#f472b6"; // Pink
              if (node.layer === "output") color = "#f97316"; // Orange

              return (
                <g key={node.id}>
                  {/* Outer activation pulsing ring */}
                  <circle
                    cx={coord.x}
                    cy={coord.y}
                    r={1.8 + (node.val * 0.8)}
                    fill="none"
                    stroke={color}
                    strokeWidth={isSelected ? 0.4 : 0.12}
                    opacity={0.15 + (node.val * 0.3)}
                    className="animate-pulse"
                  />
                  {/* Main solid node */}
                  <circle
                    cx={coord.x}
                    cy={coord.y}
                    r={1.2 + (node.val * 0.4)}
                    fill="#0c0a0f"
                    stroke={color}
                    strokeWidth={isSelected ? 0.6 : 0.25}
                    className="cursor-pointer hover:scale-125 transition-transform"
                    onClick={() => setSelectedNode(node)}
                  />
                  {/* Glow dot if activation is high */}
                  {node.val > 0.5 && (
                    <circle
                      cx={coord.x}
                      cy={coord.y}
                      r={0.4}
                      fill={color}
                      opacity={node.val}
                      style={{ filter: "drop-shadow(0 0 2px " + color + ")" }}
                    />
                  )}
                </g>
              );
            })}
          </svg>

          {/* Layer Overlay Titles */}
          <div className="absolute top-3 inset-x-0 flex justify-between px-6 text-[9px] uppercase tracking-widest font-mono text-brand-secondary/60 pointer-events-none">
            <span>Inputs (x)</span>
            <span className="mr-8">Hidden Layer 1 (h1)</span>
            <span className="mr-1">Hidden Layer 2 (h2)</span>
            <span>Outputs (y)</span>
          </div>

          {/* Dynamic Node Details Card (Bottom overlay) */}
          <AnimatePresence>
            {selectedNode && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className="absolute bottom-4 left-4 right-4 bg-[#0d0d12]/95 border border-[#45f3ff]/20 rounded-xl p-3.5 backdrop-blur-md flex items-start justify-between z-20 shadow-lg"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#45f3ff]" />
                    <h4 className="text-xs font-black uppercase text-white">{selectedNode.label}</h4>
                    <span className="text-[9px] font-mono px-1.5 py-0.2 bg-white/10 rounded text-neutral-400 capitalize">
                      {selectedNode.layer} Layer
                    </span>
                  </div>
                  <p className="text-[10px] text-brand-secondary mt-1">{selectedNode.desc}</p>
                </div>

                <div className="flex items-center gap-5 text-right font-mono">
                  <div>
                    <div className="text-[8px] text-brand-secondary uppercase tracking-wider">Activation (a)</div>
                    <div className="text-xs font-bold text-[#45f3ff]">{selectedNode.val}</div>
                  </div>
                  {selectedNode.layer !== "input" && (
                    <div>
                      <div className="text-[8px] text-brand-secondary uppercase tracking-wider">Bias (b)</div>
                      <div className="text-xs font-bold text-neutral-300">{selectedNode.bias}</div>
                    </div>
                  )}
                  <button 
                    onClick={() => setSelectedNode(null)} 
                    className="text-neutral-500 hover:text-white font-bold text-xs pl-2"
                  >
                    ×
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Connection Weight popover */}
          {hoveredConn && (
            <div className="absolute top-12 left-1/2 transform -translate-x-1/2 bg-[#12121a] border border-[#f472b6]/20 px-3 py-1 rounded-md text-[10px] font-mono text-center z-10 select-none shadow-md">
              <span className="text-neutral-400">{hoveredConn.from} → {hoveredConn.to}</span>
              <span className="mx-1.5 text-neutral-500 font-black">|</span>
              <span className="text-indigo-300">Weight:</span>{" "}
              <span className={hoveredConn.weight > 0 ? "text-[#45f3ff] font-bold" : "text-rose-400 font-bold"}>
                {hoveredConn.weight.toFixed(3)}
              </span>
            </div>
          )}
        </div>

        {/* Manual weights tweak drawer */}
        <div className="p-4 bg-[#08080c] border-t border-brand-border/40 grid grid-cols-2 sm:grid-cols-4 gap-4 z-10">
          <div>
            <label className="text-[10px] font-bold text-brand-secondary uppercase block mb-1">
              Learning Rate (η)
            </label>
            <div className="flex items-center gap-2">
              <input
                type="range"
                min="0.001"
                max="0.5"
                step="0.005"
                value={learningRate}
                onChange={(e) => setLearningRate(Number(e.target.value))}
                className="w-full h-1 bg-neutral-900 rounded-lg appearance-none cursor-pointer accent-[#45f3ff]"
              />
              <span className="text-xs font-mono text-[#45f3ff]">{learningRate}</span>
            </div>
          </div>

          <div>
            <label className="text-[10px] font-bold text-brand-secondary uppercase block mb-1">
              Activation Formula
            </label>
            <select
              value={activationFn}
              onChange={(e) => setActivationFn(e.target.value as any)}
              className="w-full bg-[#0d0d12] border border-brand-border/40 text-xs text-neutral-200 px-2 py-1 rounded focus:outline-hidden focus:border-[#45f3ff]"
            >
              <option value="sigmoid">Sigmoid 1/(1+e^-z)</option>
              <option value="relu">ReLU max(0, z)</option>
              <option value="tanh">Tanh (hyperbolic)</option>
              <option value="leaky">Leaky ReLU</option>
            </select>
          </div>

          <div>
            <label className="text-[10px] font-bold text-brand-secondary uppercase block mb-1">
              Weight Variance (Noise)
            </label>
            <div className="flex items-center gap-2">
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={noiseLevel}
                onChange={(e) => setNoiseLevel(Number(e.target.value))}
                className="w-full h-1 bg-neutral-900 rounded-lg appearance-none cursor-pointer accent-[#45f3ff]"
              />
              <span className="text-xs font-mono text-neutral-300">{noiseLevel}</span>
            </div>
          </div>

          <div className="flex items-end justify-end">
            <button
              onClick={resetWeights}
              className="w-full py-1 bg-neutral-900 border border-brand-border/40 hover:border-rose-500/40 text-rose-400 rounded hover:bg-rose-500/5 text-xs font-bold font-mono transition-all flex items-center justify-center gap-1.5"
            >
              <RefreshCw className="w-3 h-3" />
              Reset All Weights
            </button>
          </div>
        </div>
      </div>

      {/* Right Side: Neural Pipeline execution gateway + wikipedia / google info stream */}
      <div className="w-full xl:w-[420px] shrink-0 flex flex-col gap-6">
        
        {/* Top box: Live Ask Gateway connecting to wiki & google */}
        <div className="bg-[#09090b] border border-brand-border/40 rounded-2xl p-5 shadow-xl relative overflow-hidden flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-emerald-400 animate-spin" />
              <h3 className="text-xs font-black uppercase tracking-wider">Global Search Gateways</h3>
            </div>
            <span className="px-1.5 py-0.5 rounded text-[8.5px] bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-mono">
              ONLINE
            </span>
          </div>

          <div className="space-y-2">
            {/* Wikipedia Main Page hook */}
            <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-900 flex items-center justify-between">
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="w-6 h-6 bg-white text-black font-black text-xs flex items-center justify-center rounded select-none shrink-0">W</span>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-white leading-tight">en.wikipedia.org</div>
                  <div className="text-[9px] text-brand-secondary truncate">https://en.wikipedia.org/wiki/Main_Page</div>
                </div>
              </div>
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            </div>

            {/* Google Search URL hook */}
            <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-900 flex items-center justify-between">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-6 h-6 bg-blue-600 font-extrabold text-xs text-white flex items-center justify-center rounded select-none shrink-0">G</div>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-white leading-tight">Google Search Engine</div>
                  <div className="text-[9px] text-brand-secondary truncate">https://www.google.com/?zx=1782233824255</div>
                </div>
              </div>
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            </div>
          </div>

          <div className="border-t border-brand-border/30 pt-3">
            <label className="text-[10px] font-bold text-brand-secondary uppercase block mb-1.5">
              Ask Query (Neural Activation Test)
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={queryInput}
                onChange={(e) => setQueryInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleFeedForwardAndSynthesize()}
                placeholder="Ask anything about historic facts or live news..."
                className="flex-1 bg-neutral-950 border border-brand-border/40 px-3 py-2 text-xs rounded-xl focus:outline-hidden focus:border-[#45f3ff] text-white"
              />
              <button
                onClick={handleFeedForwardAndSynthesize}
                disabled={isSynthesizing || !queryInput.trim()}
                className="bg-brand-accent hover:bg-brand-accent-hover text-white px-3 py-2 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1 disabled:opacity-40"
              >
                {isSynthesizing ? (
                  <BrainCircuit className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Flame className="w-3.5 h-3.5" />
                )}
                Run
              </button>
            </div>
          </div>
        </div>

        {/* Middle/Bottom Box: Neural Synthesis Logs & Output Text */}
        <div className="flex-1 min-h-[250px] bg-[#09090b] border border-brand-border/40 rounded-2xl p-5 shadow-xl flex flex-col gap-4 overflow-hidden">
          <div className="flex items-center justify-between border-b border-brand-border/20 pb-2">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-[#45f3ff] animate-pulse" />
              <h3 className="text-xs font-black uppercase tracking-wider">Feed Forward Output Stream</h3>
            </div>
            {isSynthesizing && (
              <span className="text-[9px] text-[#45f3ff] font-mono animate-pulse font-extrabold">PROPAGATING...</span>
            )}
          </div>

          {/* Logs panel */}
          <div className="bg-neutral-950 border border-neutral-900 rounded-xl p-3 h-28 overflow-y-auto font-mono text-[9px] text-emerald-400 space-y-1.5">
            {synthesisLogs.length === 0 ? (
              <div className="text-neutral-500 italic flex items-center gap-1.5 h-full justify-center">
                <Info className="w-3.5 h-3.5 shrink-0" />
                Enter query to trace neuron calculation logs
              </div>
            ) : (
              synthesisLogs.map((log, idx) => (
                <div key={idx} className="leading-relaxed break-words border-l-2 border-emerald-500/25 pl-1.5">{log}</div>
              ))
            )}
          </div>

          {/* Generated Synthesized output text block */}
          <div className="flex-1 flex flex-col min-h-0 bg-neutral-950/45 border border-brand-border/20 rounded-xl p-3.5 overflow-y-auto">
            <span className="text-[8.5px] uppercase tracking-widest text-[#f97316] font-mono font-black mb-1.5 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#f97316] shrink-0" />
              y1.val Output Vector (Nexora AI Answer)
            </span>
            <div className="text-xs text-neutral-200 leading-relaxed font-mono flex-1 select-text select-all overflow-y-auto pr-1">
              {synthesisResult ? (
                <p className="whitespace-pre-wrap">{synthesisResult}</p>
              ) : (
                <div className="text-neutral-600 italic h-full flex items-center justify-center text-center p-3 text-[11px]">
                  No output vector loaded yet. Enter a query and run feed-forward to see Nexora AI fetch live information and synthesize!
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Bottom stats box: Loss Chart & Training Data */}
        <div className="bg-[#09090b] border border-brand-border/40 rounded-2xl p-4 shadow-xl flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-brand-secondary font-bold uppercase tracking-wider">Neuron Network Performance</span>
            <span className="text-xs font-mono text-indigo-400 font-extrabold">Epoch {epoch}</span>
          </div>

          <div className="flex items-center justify-between bg-neutral-950 px-3 py-2 rounded-xl border border-neutral-900">
            <div>
              <span className="text-[8px] text-brand-secondary uppercase font-mono block">MSE Loss Error</span>
              <span className="text-sm font-black text-rose-400 font-mono">{loss.toFixed(5)}</span>
            </div>
            <div className="h-6 w-32 relative">
              {/* Micro loss mini-sparkline SVG */}
              <svg className="w-full h-full" viewBox="0 0 100 24">
                <path
                  d={`M ${lossHistory.map((l, i) => `${(i / (lossHistory.length - 1)) * 100} ${22 - (l * 20)}`).join(" L ")}`}
                  fill="none"
                  stroke="#f43f5e"
                  strokeWidth="1.5"
                />
              </svg>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
