import React, { useState, useEffect, useRef } from 'react';
import { MarkdownRenderer } from './MarkdownRenderer';

interface TypewriterMarkdownProps {
  content: string;
  speed?: number; // base ms per character or chunk
  onComplete?: () => void;
}

export const TypewriterMarkdown: React.FC<TypewriterMarkdownProps> = ({
  content,
  speed = 8,
  onComplete
}) => {
  const [displayedText, setDisplayedText] = useState('');
  const [isDone, setIsDone] = useState(false);
  const contentRef = useRef(content);
  contentRef.current = content;
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  useEffect(() => {
    const text = contentRef.current;
    let currentIndex = 0;
    
    // Dynamic step sizing based on the length of the string to avoid slow output
    const totalLength = text.length;
    let charsPerStep = 1;
    let intervalMs = speed;

    if (totalLength > 1500) {
      charsPerStep = 8;
      intervalMs = 3;
    } else if (totalLength > 800) {
      charsPerStep = 5;
      intervalMs = 4;
    } else if (totalLength > 400) {
      charsPerStep = 3;
      intervalMs = 5;
    } else if (totalLength > 150) {
      charsPerStep = 2;
      intervalMs = 6;
    }

    const timer = setInterval(() => {
      currentIndex += charsPerStep;
      if (currentIndex >= totalLength) {
        setDisplayedText(text);
        setIsDone(true);
        clearInterval(timer);
        onCompleteRef.current?.();
      } else {
        setDisplayedText(text.substring(0, currentIndex));
      }
    }, intervalMs);

    return () => {
      clearInterval(timer);
    };
  }, [content, speed]);

  const handleSkip = (e: React.MouseEvent) => {
    // Prevent interfering with selection or voice speaker buttons
    e.stopPropagation();
    if (!isDone) {
      setDisplayedText(content);
      setIsDone(true);
      onCompleteRef.current?.();
    }
  };

  return (
    <div 
      onClick={handleSkip} 
      className="cursor-pointer group relative active:opacity-95 transition-opacity" 
      title="Click to skip typing effect"
    >
      <MarkdownRenderer content={displayedText} />
      {!isDone && (
        <span className="inline-flex items-center gap-1.5 mt-2 text-[11px] font-semibold text-brand-accent/70 select-none animate-pulse">
          <span className="w-1.5 h-1.5 rounded-full bg-brand-accent" />
          Typing... Click anywhere in bubble to skip
        </span>
      )}
    </div>
  );
};
