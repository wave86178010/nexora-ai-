// src/db/index.ts
import { drizzle } from 'drizzle-orm/node-postgres';
import pkg from 'pg';
const { Pool } = pkg;
import * as schema from './schema.ts';

let database: any = null;
let poolInstance: any = null;

export const getPool = () => {
  if (!poolInstance) {
    poolInstance = new Pool({
      host: process.env.SQL_HOST,
      user: process.env.SQL_USER,
      password: process.env.SQL_PASSWORD,
      database: process.env.SQL_DB_NAME,
      connectionTimeoutMillis: 15000,
    });
    
    poolInstance.on('error', (err: any) => {
      console.error('Unexpected error on idle SQL pool client:', err);
    });
  }
  return poolInstance;
};

export const getDb = () => {
  if (!database) {
    const pool = getPool();
    database = drizzle(pool, { schema });
  }
  return database;
};

// Export active db instance initialized lazily or on package load
export const db = getDb();
