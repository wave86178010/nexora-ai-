import { relations } from 'drizzle-orm';
import { integer, pgTable, serial, text, timestamp } from 'drizzle-orm/pg-core';

// Define the 'users' table
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(), // Firebase Auth UID
  email: text('email').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// Define the 'sessions' table, referencing the users table
export const sessions = pgTable('sessions', {
  id: text('id').primaryKey(), // Using string-based UUID or unique ID
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull(),
  title: text('title').notNull(),
  mode: text('mode').default('chat').notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Define the 'messages' table, referencing the sessions table
export const messages = pgTable('messages', {
  id: serial('id').primaryKey(),
  sessionId: text('session_id')
    .references(() => sessions.id, { onDelete: 'cascade' })
    .notNull(),
  sender: text('sender').notNull(), // 'user' or 'ai'
  text: text('text').notNull(),
  timestamp: text('timestamp').notNull(),
  reaction: text('reaction'), // Save feedback emojis e.g. 👍, 👎, ❤️, 😂
  emotionAnalysis: text('emotion_analysis'), // JSON stringified emotion analysis
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Define the 'ingested_knowledge' table
export const ingestedKnowledge = pgTable('ingested_knowledge', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull(),
  content: text('content').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Define relationships for the 'users' table
export const usersRelations = relations(users, ({ many }) => ({
  sessions: many(sessions),
  ingestedKnowledge: many(ingestedKnowledge),
}));

// Define relationships for the 'sessions' table
export const sessionsRelations = relations(sessions, ({ one, many }) => ({
  user: one(users, {
    fields: [sessions.userId],
    references: [users.id],
  }),
  messages: many(messages),
}));

// Define relationships for the 'messages' table
export const messagesRelations = relations(messages, ({ one }) => ({
  session: one(sessions, {
    fields: [messages.sessionId],
    references: [sessions.id],
  }),
}));

// Define relationships for the 'ingested_knowledge' table
export const ingestedKnowledgeRelations = relations(ingestedKnowledge, ({ one }) => ({
  user: one(users, {
    fields: [ingestedKnowledge.userId],
    references: [users.id],
  }),
}));
