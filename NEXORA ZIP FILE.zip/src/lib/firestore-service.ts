import { doc, getDoc, setDoc, getDocFromServer } from 'firebase/firestore';
import { db, auth } from './firebase';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error Info: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

/**
 * Validates connection to Firestore on application startup.
 * (Critical Verification requirement from Firebase constraints)
 */
export async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log("Firestore connection test: Successfully queried metadata from server.");
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error("Please check your Firebase configuration. Client is currently offline.");
    } else {
      console.log("Connection verified (Server test ran).");
    }
  }
}

/**
 * Syncs user profiles to firestore securely conforming to rules & metadata schema.
 */
export async function syncUserProfileFirestore(uid: string, email: string, displayName: string) {
  const profilePath = `userProfiles/${uid}`;
  try {
    // Check if profile already exists to preserve old properties if needed
    const docRef = doc(db, 'userProfiles', uid);
    let existingData = {};
    try {
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        existingData = snap.data();
      }
    } catch (getErr) {
      // If permission error happens on get, we handle it or ignore and proceed to write
      console.warn("Could not retrieve existing profile: ", getErr);
    }

    const payload = {
      ...existingData,
      uid,
      email,
      displayName: displayName || email.split('@')[0],
      createdAt: (existingData as any).createdAt || new Date().toISOString()
    };

    await setDoc(docRef, payload);
    console.log(`Successfully persisted user profile for ${email} in Firestore!`);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, profilePath);
  }
}
